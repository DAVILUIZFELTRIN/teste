import { db } from "../server/legacy/db.js";

const nomesMasculinos = [
  "Miguel", "Arthur", "Heitor", "Ravi", "Theo", "Bernardo", "Davi", "Gabriel", "Samuel", "Pedro",
  "Rafael", "Lucas", "Matheus", "Gustavo", "Henrique", "Felipe", "Eduardo", "Bruno", "João", "Caio",
  "Enzo", "Nicolas", "Leonardo", "Murilo", "Vicente", "Guilherme", "Lorenzo", "Bento", "Antônio", "Daniel",
  "André", "Vitor", "Diego", "Rodrigo", "Vinícius", "Thiago", "Fernando", "Lucca", "Yuri", "Otávio",
  "Pietro", "Joaquim", "Isaac", "Emanuel", "Cauã", "Alexandre", "Marcos", "Guilherme", "Levi", "Tomás",
];
const nomesFemininos = [
  "Alice", "Helena", "Laura", "Valentina", "Heloísa", "Sophia", "Isabela", "Manuela", "Júlia", "Maria",
  "Cecília", "Liz", "Eloá", "Antonella", "Lorena", "Lívia", "Mariana", "Beatriz", "Luiza", "Ana",
  "Clara", "Yasmin", "Gabriela", "Sofia", "Melissa", "Amanda", "Letícia", "Aline", "Bianca", "Camila",
  "Carolina", "Fernanda", "Larissa", "Natália", "Manuella", "Rafaela", "Esther", "Maitê", "Vitória", "Bruna",
  "Isadora", "Marina", "Emilly", "Eduarda", "Giovanna", "Nicole", "Sarah", "Lara", "Pietra", "Elisa",
];
const sobrenomes = [
  "Alves", "Pereira", "Oliveira", "Costa", "Ribeiro", "Martins", "Souza", "Lima", "Silva", "Santos",
  "Ferreira", "Rodrigues", "Gomes", "Carvalho", "Mendes", "Barbosa", "Teixeira", "Moreira", "Cardoso", "Vieira",
  "Nunes", "Moura", "Dias", "Freitas", "Rocha", "Azevedo", "Monteiro", "Correia", "Cavalcante", "Farias",
  "Batista", "Duarte", "Macedo", "Moraes", "Ramos", "Tavares", "Borges", "Pinto", "Araújo", "Campos",
];

const nomesUsados = new Set();
function nomeUnico(sexo, index) {
  const lista = sexo === "feminino" ? nomesFemininos : nomesMasculinos;
  const primeiro = lista[index % lista.length];
  const sobrenomeA = sobrenomes[Math.floor(index / lista.length) % sobrenomes.length];
  const sobrenomeB = sobrenomes[Math.floor(index / (lista.length * 2)) % sobrenomes.length];
  let nome = `${primeiro} ${sobrenomeA}${sobrenomeA === sobrenomeB ? "" : ` ${sobrenomeB}`}`;
  let extra = 0;
  while (nomesUsados.has(nome)) {
    extra += 1;
    nome = `${primeiro} ${sobrenomeA} ${sobrenomes[(Math.floor(index / sobrenomes.length) + extra) % sobrenomes.length]}`;
  }
  nomesUsados.add(nome);
  return nome;
}

function sexoElegivel(esporte, sexo) {
  return esporte.genero === "misto" || !esporte.genero || esporte.genero === sexo;
}

const result = { alunosAtualizados: 0, vinculosCriados: 0, provasVinculadas: 0, porEsporte: {} };
const inscricoes = await db.prepare("SELECT i.*, t.categoria_id FROM inscricoes i JOIN turmas t ON t.id = i.turma_id ORDER BY i.id").all();
const esportes = await db.prepare("SELECT * FROM esportes WHERE ativo = 1 ORDER BY id").all();
const categoriasEsportes = await db.prepare("SELECT categoria_id, esporte_id FROM categoria_esportes").all();
const provas = await db.prepare("SELECT * FROM provas_atletismo WHERE ativo = 1 ORDER BY categoria_id, ordem, id").all();
const allowed = new Set(categoriasEsportes.map((row) => `${row.categoria_id}:${row.esporte_id}`));
const athletic = esportes.find((esporte) => /atletismo/i.test(esporte.nome));
const links = await db.prepare("SELECT inscricao_id, esporte_id FROM inscricao_esportes").all();
const linksByInscricao = new Set(links.map((row) => `${row.inscricao_id}:${row.esporte_id}`));

const counters = { masculino: 0, feminino: 0 };
await db.transaction(async (tx) => {
  await tx.prepare("DELETE FROM inscricao_provas_atletismo").run();
  await tx.prepare("DELETE FROM inscricao_esportes").run();
  const updateName = tx.prepare("UPDATE inscricoes SET nome = ? WHERE id = ?");
  const linkSport = tx.prepare("INSERT INTO inscricao_esportes (inscricao_id, esporte_id) VALUES (?, ?)");
  const linkProof = tx.prepare("INSERT IGNORE INTO inscricao_provas_atletismo (inscricao_id, prova_id) VALUES (?, ?)");

  for (const inscricao of inscricoes) {
    const sexo = inscricao.sexo === "feminino" ? "feminino" : "masculino";
    const index = counters[sexo]++;
    await updateName.run(nomeUnico(sexo, index), inscricao.id);

    const elegiveis = esportes.filter((esporte) => allowed.has(`${inscricao.categoria_id}:${esporte.id}`) && sexoElegivel(esporte, sexo));
    const quantidade = Math.min(6, elegiveis.length);
    const inicio = elegiveis.length ? (inscricao.id * 3 + index) % elegiveis.length : 0;
    const escolhidos = Array.from({ length: quantidade }, (_, offset) => elegiveis[(inicio + offset) % elegiveis.length]);

    for (const esporte of escolhidos) {
      await linkSport.run(inscricao.id, esporte.id);
      result.vinculosCriados += 1;
      result.porEsporte[esporte.nome] = (result.porEsporte[esporte.nome] || 0) + 1;
      if (athletic && esporte.id === athletic.id) {
        const provasCategoria = provas.filter((prova) => Number(prova.categoria_id) === Number(inscricao.categoria_id));
        if (provasCategoria.length) {
          const prova = provasCategoria[(inscricao.id + index) % provasCategoria.length];
          await linkProof.run(inscricao.id, prova.id);
          result.provasVinculadas += 1;
        }
      }
    }
    result.alunosAtualizados += 1;
  }
});

console.log(JSON.stringify({ ...result, totalEsportes: esportes.length, totalInscricoes: inscricoes.length }, null, 2));
await db.close();
