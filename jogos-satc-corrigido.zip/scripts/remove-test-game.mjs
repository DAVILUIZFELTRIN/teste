import Database from "better-sqlite3";
const db = new Database("server/data/campeonato.db");
const result = db.prepare("DELETE FROM jogos WHERE local = ? AND data = ?").run("Teste visual", "2099-03-01");
console.log(JSON.stringify({ removidos: result.changes }));
db.close();
