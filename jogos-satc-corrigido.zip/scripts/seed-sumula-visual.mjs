import Database from "better-sqlite3";
const db = new Database("server/data/campeonato.db");
const created = [];
for (const nome of ["Futsal Masculino", "Xadrez Masculino"]) {
  const esporte = db.prepare("SELECT id FROM esportes WHERE nome = ?").get(nome);
  const a = db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
  const b = db.prepare("SELECT id FROM turmas WHERE label = '7º Ano C'").get();
  db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, a.id);
  db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, b.id);
  const ta = db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, a.id);
  const tb = db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, b.id);
  const jogo = db.prepare("INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status) VALUES (?, ?, ?, '2099-03-01', '12:00', 'Teste visual', 'Teste', 'agendado')").run(esporte.id, ta.id, tb.id);
  created.push({ nome, id: jogo.lastInsertRowid });
}
console.log(JSON.stringify(created));
db.close();
