import { db } from "../server/legacy/db.js";

const atletismo = await db.prepare("SELECT id FROM esportes WHERE nome = 'Atletismo'").get();
if (!atletismo) throw new Error("Esporte Atletismo não encontrado.");

const provas = await db.prepare(`
  SELECT p.id, p.categoria_id, p.nome, c.nome AS categoria_nome
  FROM provas_atletismo p
  JOIN categorias c ON c.id = p.categoria_id
  WHERE p.ativo = 1
  ORDER BY p.categoria_id, p.ordem, p.id
`).all();
const alunos = await db.prepare(`
  SELECT i.id, i.sexo, i.turma_id, t.label, t.categoria_id
  FROM inscricoes i
  JOIN inscricao_esportes ie ON ie.inscricao_id = i.id AND ie.esporte_id = ?
  JOIN turmas t ON t.id = i.turma_id
  WHERE i.matricula LIKE 'DEMO%' AND i.status_pagamento <> 'cancelado'
  ORDER BY t.label, i.id
`).all(atletismo.id);
const insert = db.prepare("INSERT IGNORE INTO inscricao_provas_atletismo (inscricao_id, prova_id) VALUES (?, ?)");
const normalize = value => String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const isRelay = name => /revezamento|4x/i.test(normalize(name));
const added = [];

for (const prova of provas) {
  const candidates = alunos.filter(aluno => Number(aluno.categoria_id) === Number(prova.categoria_id));
  if (isRelay(prova.nome)) {
    for (const sexo of ["masculino", "feminino"]) {
      const groups = new Map();
      candidates.filter(aluno => aluno.sexo === sexo).forEach(aluno => {
        const key = `${aluno.turma_id}`;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(aluno);
      });
      const teams = [...groups.values()].filter(group => group.length >= 4).slice(0, 2);
      for (const team of teams) {
        for (const aluno of team.slice(0, 4)) {
          await insert.run(aluno.id, prova.id);
          added.push({ prova: prova.nome, categoria: prova.categoria_nome, sexo, turma: team[0].label, aluno: aluno.id });
        }
      }
    }
  } else {
    for (const sexo of ["masculino", "feminino"]) {
      const selected = candidates.filter(aluno => aluno.sexo === sexo).slice(0, 18);
      for (const aluno of selected) {
        await insert.run(aluno.id, prova.id);
        added.push({ prova: prova.nome, categoria: prova.categoria_nome, sexo, turma: aluno.label, aluno: aluno.id });
      }
    }
  }
}

const resumo = [];
for (const prova of provas) {
  const count = await db.prepare("SELECT COUNT(*) AS total FROM inscricao_provas_atletismo WHERE prova_id = ?").get(prova.id);
  resumo.push({ prova: prova.nome, categoria: prova.categoria_nome, inscritos: Number(count.total) });
}
console.log(JSON.stringify({ adicionados: added.length, resumo }, null, 2));
await db.close();
