import crypto from "node:crypto";
import Database from "better-sqlite3";

const db = new Database("server/data/campeonato.db");
const turmas = db.prepare("SELECT * FROM turmas WHERE ativo = 1 AND (label LIKE '6º Ano %' OR label LIKE '7º Ano %') ORDER BY label").all();
const esportes = db.prepare("SELECT * FROM esportes WHERE ativo = 1 ORDER BY id").all();
const insert = db.prepare(`INSERT INTO inscricoes (codigo, nome, matricula, sexo, turma_id, status_pagamento, valor, pix_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
const linkEsporte = db.prepare("INSERT INTO inscricao_esportes (inscricao_id, esporte_id) VALUES (?, ?)");
const linkProva = db.prepare("INSERT OR IGNORE INTO inscricao_provas_atletismo (inscricao_id, prova_id) VALUES (?, ?)");
const findExisting = db.prepare("SELECT id FROM inscricoes WHERE matricula = ?");
const allowed = db.prepare(`SELECT 1 FROM categoria_esportes WHERE categoria_id = ? AND esporte_id = ?`);
const findProof = db.prepare("SELECT id FROM provas_atletismo WHERE categoria_id = ? AND ativo = 1 ORDER BY ordem, id LIMIT 1");
const findCount = db.prepare("SELECT COUNT(*) AS total FROM inscricoes WHERE turma_id = ? AND status_pagamento != 'cancelado'");
const nomesMasculinos = ["Miguel", "Heitor", "Joao", "Rafael", "Felipe", "Samuel", "Eduardo", "Bruno", "Arthur", "Gabriel", "Lucas", "Matheus", "Pedro", "Enzo", "Bernardo", "Caio", "Davi", "Gustavo", "Henrique", "Leonardo", "Murilo", "Nicolas", "Thiago", "Vinicius"];
const nomesFemininos = ["Isabela", "Yasmin", "Ester", "Alice", "Amanda", "Manuela", "Maria", "Cecilia", "Ana", "Aline", "Beatriz", "Bianca", "Camila", "Clara", "Gabriela", "Helena", "Julia", "Laura", "Leticia", "Luana", "Mariana", "Melissa", "Natalia", "Sofia"];
const sobrenomes = ["Alves", "Pereira", "Oliveira", "Costa", "Ribeiro", "Martins", "Souza", "Lima", "Silva", "Santos", "Ferreira", "Rodrigues", "Gomes", "Carvalho"];
const counters = { masculino: 0, feminino: 0 };
const result = { criadas: 0, existentes: 0, ignoradas: 0, porEsporte: {} };

function sexoPara(esporte, indice) {
  if (esporte.genero === "feminino") return "feminino";
  if (esporte.genero === "masculino") return "masculino";
  return indice % 2 === 0 ? "masculino" : "feminino";
}
function nomePara(sexo) {
  const index = counters[sexo]++;
  const nomes = sexo === "masculino" ? nomesMasculinos : nomesFemininos;
  return `${nomes[index % nomes.length]} ${sobrenomes[Math.floor(index / nomes.length) % sobrenomes.length]}`;
}

const run = db.transaction(() => {
  for (const turma of turmas) {
    for (const [indice, esporte] of esportes.entries()) {
      if (!allowed.get(turma.categoria_id, esporte.id)) { result.ignoradas += 1; continue; }
      const matricula = `DEMO-S${esporte.id}-T${turma.id}`;
      if (findExisting.get(matricula)) { result.existentes += 1; continue; }
      if (findCount.get(turma.id).total >= turma.vagas) throw new Error(`A turma ${turma.label} atingiu o limite de ${turma.vagas} vagas.`);
      const sexo = sexoPara(esporte, indice);
      const codigo = `SATC-DEMO-${esporte.id}-${turma.id}-${crypto.randomInt(100, 999)}`;
      const status = indice % 3 === 0 ? "pendente" : "confirmado";
      const info = insert.run(codigo, nomePara(sexo), matricula, sexo, turma.id, status, turma.taxa, `DEMO PIX | ${codigo}`);
      linkEsporte.run(info.lastInsertRowid, esporte.id);
      if (esporte.nome === "Atletismo") {
        const prova = findProof.get(turma.categoria_id);
        if (!prova) throw new Error(`Nenhuma prova de Atletismo cadastrada para ${turma.label}.`);
        linkProva.run(info.lastInsertRowid, prova.id);
      }
      result.criadas += 1;
      result.porEsporte[esporte.nome] = (result.porEsporte[esporte.nome] || 0) + 1;
    }
  }
});

run();
console.log(JSON.stringify({ turmas: turmas.map(t => t.label), esportes: esportes.length, ...result }, null, 2));
db.close();
