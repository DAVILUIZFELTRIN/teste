const base = "http://127.0.0.1:3001";
const matriculas = ["API-VALIDA-6A", "API-VALIDA-7C", "API-INVALIDA-6A"];
const cleanup = async () => {
  const { default: Database } = await import("better-sqlite3");
  const db = new Database("server/data/campeonato.db");
  db.prepare(`DELETE FROM inscricoes WHERE matricula IN (${matriculas.map(() => "?").join(",")})`).run(...matriculas);
  db.close();
};

try {
  const turmas = await (await fetch(`${base}/api/turmas`)).json();
  const esportes = await (await fetch(`${base}/api/esportes?turmaId=${turmas.find((t) => t.label === "6º Ano A").id}&sexo=masculino`)).json();
  const atletismo = esportes.find((e) => e.nome === "Atletismo");
  const prova = atletismo.provas[0].id;
  const turma6 = turmas.find((t) => t.label === "6º Ano A");
  const turma7 = turmas.find((t) => t.label === "7º Ano C");
  for (const [matricula, turma, sexo] of [[matriculas[0], turma6, "masculino"], [matriculas[1], turma7, "feminino"]]) {
    const response = await fetch(`${base}/api/inscricoes`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ nome: `Teste API ${matricula}`, matricula, sexo, turmaId: turma.id, esportes: [atletismo.id], provasAtletismo: [prova] }) });
    if (response.status !== 201) throw new Error(`Inscrição válida rejeitada para ${turma.label}: ${response.status}`);
  }
  const invalid = await fetch(`${base}/api/inscricoes`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ nome: "Teste API inválido", matricula: matriculas[2], sexo: "masculino", turmaId: turma6.id, esportes: [atletismo.id], provasAtletismo: [] }) });
  if (invalid.status !== 400) throw new Error(`Inscrição sem prova não foi rejeitada: ${invalid.status}`);
  console.log(JSON.stringify({ validas: 2, invalidas_rejeitadas: 1, prova: atletismo.provas[0].nome }, null, 2));
} finally {
  await cleanup();
}
