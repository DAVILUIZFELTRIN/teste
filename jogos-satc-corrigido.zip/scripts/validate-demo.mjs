import Database from "better-sqlite3";

const db = new Database("server/data/campeonato.db", { readonly: true });
const demos = db.prepare(`
  SELECT i.id, i.nome, i.matricula, i.sexo, t.label, t.categoria_id,
         e.id AS esporte_id, e.nome AS esporte_nome,
         COUNT(ipa.prova_id) AS provas
  FROM inscricoes i
  JOIN turmas t ON t.id = i.turma_id
  JOIN inscricao_esportes ie ON ie.inscricao_id = i.id
  JOIN esportes e ON e.id = ie.esporte_id
  LEFT JOIN inscricao_provas_atletismo ipa ON ipa.inscricao_id = i.id
  WHERE i.matricula LIKE 'DEMO-%'
  GROUP BY i.id, e.id
  ORDER BY t.label, i.matricula
`).all();

const permitida = db.prepare(`
  SELECT 1 FROM categoria_esportes ce
  JOIN esportes e ON e.id = ce.esporte_id
  WHERE ce.categoria_id = ? AND e.id = ?
    AND (e.genero = 'misto' OR e.genero = ?)
`);

const invalidas = demos.filter((demo) => {
  const okModalidade = permitida.all(demo.categoria_id, demo.esporte_id, demo.sexo).length > 0;
  const okProva = demo.esporte_nome !== "Atletismo" || demo.provas > 0;
  return !okModalidade || !okProva;
});

const porTurma = db.prepare(`
  SELECT t.label, COUNT(DISTINCT i.id) AS inscritos
  FROM turmas t LEFT JOIN inscricoes i ON i.turma_id = t.id AND i.matricula LIKE 'DEMO-%'
  WHERE t.label LIKE '6º Ano %' OR t.label LIKE '7º Ano %'
  GROUP BY t.id ORDER BY t.label
`).all();

console.log(JSON.stringify({ total: demos.length, invalidas, porTurma }, null, 2));
if (invalidas.length) process.exit(1);
