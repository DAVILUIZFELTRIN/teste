# Alterações desta versão

Base: versão do GitHub (jogos-satc-permanente-main). Nenhuma função nova sua foi removida e o visual foi mantido,
exceto os botões de escolha de tela (mais contraste para uso ao sol).

## Servidor – estabilidade
- Recriado/fortalecido `middleware/auth.js`; segredo do login obrigatório em produção (`JWT_SECRET`).
- Todas as rotas passam por `safeRouter`; erros viram resposta 500/400 em vez de derrubar o servidor.
- Corrigida a queda por inscrições simultâneas na mesma turma/esporte (criação de time sem erro de duplicidade).
- Corrigida a queda por data inválida em `PUT /api/configuracoes`.
- Tratamento central de erros, rota inexistente responde 404 em JSON, `unhandledRejection` registrado.
- Seed reescrito (assíncrono): cria admin, categorias, turmas, esportes e provas em banco novo; roda ao iniciar; novo `pnpm seed`.
- Cabeçalhos de segurança, CORS fechado em produção (`CORS_ORIGIN`), `trust proxy`.

## Inscrições
- Matrícula com exatamente 5 números (tela e servidor).
- Uma inscrição ativa por matrícula (índice único + trava da turma durante a inscrição).
- Vagas protegidas contra disputa simultânea.
- Valor único R$ 25 (`VALOR_INSCRICAO`) para todas as turmas; campo Taxa travado no admin.
- Código da inscrição com 6 letras/números (antes 4 números).
- Nome normalizado (espaços); `criado_em` preenchido; provas globais de Atletismo aceitas.
- Reativar inscrição cancelada confere conflito de matrícula.

## Privacidade e segurança
- API pública de jogos não entrega ocorrências, observações, escalações nem quem registrou (só o admin vê).
- Consulta por matrícula não revela sexo nem referência PIX.
- Busca por nome não aceita curingas (%, _) e exige 3 letras.
- Limite de 10 tentativas de login em 15 minutos; renovação automática do login a cada 30 minutos.
- QR Code salvo no banco quando o Manus não está configurado (servido em `/api/turmas/:id/qr`).

## Jogos, tabelas e súmulas
- Atletismo do Ensino Médio (1º ao 3º ano EM) volta a criar súmula; ano da turma lido corretamente.
- Jogo não pode ser finalizado sem placar pela API.
- Nova agenda (`agenda.js`): recusa conflito de quadra/horário, time repetido no horário e alunos em dois esportes simultâneos.
- Novo `POST /api/jogos/lote`: cria todos os jogos do gerador ou nenhum; sem jogos repetidos.
- Gerador de tabelas: sorteio, várias quadras, mata-mata sem descartar times (fase preliminar + byes), nomes de fase corretos, horários corretos, botão "Próxima fase (vencedores)", botão não duplica jogos.

## Relatório, TV e telas
- Relatório: cartões agora aparecem; artilharia correta (não confunde nomes com "gol"); novos blocos de campeões/líderes e arrecadação; botão Imprimir / salvar PDF.
- TV: usa a data de Brasília (antes mudava de dia às 21h), mostra placar ao vivo.
- Início e Jogos: data de "hoje" em horário de Brasília.
- Inscrição: matrícula só números (máx. 5); aviso se a carga inicial falhar (antes ficava carregando).
- Consulta: matrícula numérica; mostra o QR Code da turma para pagamento pendente.
- Botões de escolha de tela (menu, abas do admin, filtros de Jogos) com alto contraste.

## Testes e documentação
- Testes de inscrição, pagamento, turmas e súmulas reativados (estavam excluídos) e adaptados.
- 10 novos testes de regressão; trava para só rodar em banco de teste. Total: 42 testes.
- Novos `README.md`, `.env.example` e este arquivo.

## Atenção ao publicar
1. Defina `JWT_SECRET` no ambiente de produção (sem ele o servidor não inicia).
2. Ao subir, todas as turmas passam para R$ 25 (ou o valor de `VALOR_INSCRICAO`).
3. Matrículas já duplicadas no banco: a inscrição mais antiga fica como a "ativa"; as demais continuam existindo, mas não bloqueiam nada.
4. A imagem de fundo da página inicial continua hospedada no Manus.
