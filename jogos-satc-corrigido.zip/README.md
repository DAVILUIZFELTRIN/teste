# Jogos SATC

Gerenciador do campeonato escolar: inscrições, tabelas de jogos, súmulas digitais, classificação, tela de TV e relatório final.

## Como rodar

1. `pnpm install`
2. Copie `.env.example` para `.env` e preencha (principalmente `DATABASE_URL` e `JWT_SECRET`).
3. Desenvolvimento: `pnpm dev`  |  Produção: `pnpm build` e depois `pnpm start`.

Na primeira vez o sistema cria sozinho o administrador, as categorias, turmas, esportes e provas
(só cria o que ainda não existe; nunca recria turmas que você apagou). Para rodar manualmente: `pnpm seed`.

## Testes

`pnpm test` roda em um banco de **teste** (o nome precisa conter "test", ex.: `satc_test`).
Os testes se recusam a rodar em outro banco para não apagar dados reais.

## Regras importantes

- Matrícula: exatamente 5 números; só uma inscrição ativa por matrícula.
- Valor da inscrição único para todas as turmas (`VALOR_INSCRICAO`, padrão R$ 25).
- QR Code de pagamento por turma: usa o armazenamento do Manus se estiver configurado; senão, guarda no próprio banco.
- Login do admin renova sozinho a cada 30 minutos; máximo de 10 tentativas de login por 15 minutos.
- A API pública de jogos mostra só resultado e árbitro. Ocorrências e observações ficam no painel do admin.
- Consulta por matrícula mostra dados reduzidos; consulta por código da inscrição mostra tudo; busca por nome mostra só nome, turma, esportes e situação.
- A agenda recusa dois jogos na mesma quadra/horário, o mesmo time duas vezes no mesmo horário e alunos inscritos em dois esportes jogando ao mesmo tempo.
