import request from "supertest";
import { describe, expect, it } from "vitest";
import { app } from "./legacy/server.js";

describe("Jogos SATC public API", () => {
  it("reports the service as healthy", async () => {
    const response = await request(app).get("/api/health");
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ ok: true });
  });

  it("exposes the migrated championship catalog", async () => {
    const [categories, sports, classes] = await Promise.all([
      request(app).get("/api/categorias"),
      request(app).get("/api/esportes"),
      request(app).get("/api/turmas"),
    ]);

    expect(categories.status).toBe(200);
    expect(categories.body.length).toBeGreaterThan(0);
    expect(sports.status).toBe(200);
    expect(sports.body.length).toBeGreaterThan(0);
    expect(classes.status).toBe(200);
    expect(classes.body.length).toBeGreaterThan(0);
  });
});
