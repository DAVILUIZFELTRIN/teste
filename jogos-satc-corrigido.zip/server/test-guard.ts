// Protecao dos testes automaticos: eles criam e apagam dados, entao so podem
// rodar em um banco cujo nome contenha "test". Evita apagar dados reais por engano.
const url = process.env.DATABASE_URL || "";
const nomeDoBanco = url.split("?")[0].split("/").pop() || "";
if (!/test/i.test(nomeDoBanco) && process.env.ALLOW_TESTS_ON_ANY_DB !== "1") {
  throw new Error(
    `Os testes so rodam em um banco de teste (nome contendo "test"). Banco atual: "${nomeDoBanco}". ` +
      "Crie um banco separado, por exemplo satc_test, e aponte DATABASE_URL para ele.",
  );
}
process.env.SEED_DEMO = "1"; // os testes usam as inscricoes de demonstracao (matriculas 90001+)
process.env.NODE_ENV = "test";
