import { Router } from "express";

// Express 4 nao captura erros de funcoes async. Este Router embrulha cada
// handler para que qualquer falha (ex.: banco fora do ar) vire resposta 500
// em vez de deixar a requisicao pendurada ou derrubar o servidor.
const METODOS = ["get", "post", "put", "delete", "patch"];

export function safeRouter() {
  const router = Router();
  for (const metodo of METODOS) {
    const original = router[metodo].bind(router);
    router[metodo] = (path, ...handlers) =>
      original(
        path,
        ...handlers.map((handler) =>
          typeof handler === "function"
            ? (req, res, next) => {
                try {
                  const resultado = handler(req, res, next);
                  if (resultado && typeof resultado.catch === "function") resultado.catch(next);
                } catch (erro) {
                  next(erro);
                }
              }
            : handler,
        ),
      );
  }
  return router;
}
