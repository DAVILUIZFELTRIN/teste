import jwt from "jsonwebtoken";

const isProduction = process.env.NODE_ENV === "production";
const JWT_SECRET = process.env.JWT_SECRET || (isProduction ? "" : "segredo-somente-para-desenvolvimento");

if (!JWT_SECRET) {
  throw new Error("JWT_SECRET e obrigatorio em producao. Defina uma frase longa e aleatoria no .env.");
}

export function signToken(admin) {
  return jwt.sign(
    { id: admin.id, username: admin.username, nome: admin.nome },
    JWT_SECRET,
    { expiresIn: "8h" },
  );
}

function lerToken(req) {
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : null;
}

export function requireAdmin(req, res, next) {
  const token = lerToken(req);
  if (!token) return res.status(401).json({ erro: "Token nao fornecido." });
  try {
    req.admin = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ erro: "Token invalido ou expirado." });
  }
}

// Identifica o admin quando ha token valido, mas nao bloqueia visitantes.
export function optionalAdmin(req, res, next) {
  const token = lerToken(req);
  if (token) {
    try {
      req.admin = jwt.verify(token, JWT_SECRET);
    } catch {
      req.admin = null;
    }
  }
  next();
}
