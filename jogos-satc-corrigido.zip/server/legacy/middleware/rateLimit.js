// Limitador simples em memoria (suficiente para um unico processo Node).
export function rateLimit({ janelaMs, maximo, mensagem }) {
  const tentativas = new Map();
  return (req, res, next) => {
    const agora = Date.now();
    const chave = req.ip || "desconhecido";
    const registro = tentativas.get(chave);
    if (!registro || agora - registro.inicio > janelaMs) {
      tentativas.set(chave, { inicio: agora, total: 1 });
      return next();
    }
    registro.total += 1;
    if (registro.total > maximo) {
      const espera = Math.ceil((registro.inicio + janelaMs - agora) / 1000);
      res.set("Retry-After", String(espera));
      return res.status(429).json({ erro: mensagem || "Muitas tentativas. Aguarde um pouco." });
    }
    next();
  };
}
