// Configurações centrais do campeonato.

// Valor único da inscrição (R$), igual para todas as turmas.
export const VALOR_INSCRICAO = Number(process.env.VALOR_INSCRICAO || 25);

// Matrícula: exatamente 5 dígitos numéricos.
export const MATRICULA_REGEX = /^\d{5}$/;

// Data de hoje (AAAA-MM-DD) no fuso de Brasília. O servidor costuma rodar em UTC,
// o que faria "hoje" virar "amanhã" depois das 21h.
export function hojeBrasilia() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "America/Sao_Paulo" }).format(new Date());
}
