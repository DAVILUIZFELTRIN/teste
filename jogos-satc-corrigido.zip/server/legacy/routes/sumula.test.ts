import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let jogoId;
let timeA;
let timeB;
let token;

beforeAll(async () => {
  const admin = await db.prepare("SELECT * FROM admins LIMIT 1").get();
  const esporte = await db.prepare("SELECT id FROM esportes WHERE nome = 'Atletismo'").get();
  const turmaA = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
  const turmaB = await db.prepare("SELECT id FROM turmas WHERE label = '7º Ano C'").get();
  timeA = (await db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaA.id)).lastInsertRowid;
  timeB = (await db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaB.id)).lastInsertRowid;
  timeA = (await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaA.id)).id;
  timeB = (await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaB.id)).id;
  jogoId = (await db.prepare(`INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status) VALUES (?, ?, ?, '2099-01-01', '10:00', 'Teste Vitest', 'Teste', 'agendado')`).run(esporte.id, timeA, timeB)).lastInsertRowid;
  token = signToken(admin);
});

afterAll(async () => {
  await db.prepare("DELETE FROM jogos WHERE id = ?").run(jogoId);
});

describe("súmula estruturada", () => {
  it("grava e lê os detalhes específicos de Atletismo", async () => {
    const salvar = await request(app)
      .put(`/api/jogos/${jogoId}/sumula`)
      .set("Authorization", `Bearer ${token}`)
      .send({
        placarA: 1,
        placarB: 0,
        arbitro: "Árbitro Vitest",
        observacoes: "Partida de validação",
        detalhes: {
          prova: "Corrida 75m",
          sexoCompeticao: "masculino",
          participantesA: "Aluno DEMO 6A",
          participantesB: "Aluno DEMO 7C",
          resultado: "Corrida 75m — 1º lugar: Aluno DEMO 6A",
          ocorrencias: "Nenhuma",
        },
      });
    expect(salvar.status).toBe(200);
    expect(salvar.body.sumula.tipo).toBe("atletismo");
    expect(salvar.body.sumula.detalhes.resultado).toContain("Corrida 75m");

    const ler = await request(app).get(`/api/jogos/${jogoId}`).set("Authorization", `Bearer ${token}`);
    expect(ler.status).toBe(200);
    expect(ler.body.sumula.arbitro).toBe("Árbitro Vitest");
    expect(ler.body.sumula.detalhes.ocorrencias).toBe("Nenhuma");
  });
});
