import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";

const router = safeRouter();

router.get("/", async (req, res) => {
  const rows = await db.prepare("SELECT * FROM categorias ORDER BY ordem, id").all();
  res.json(rows);
});

router.post("/", requireAdmin, async (req, res) => {
  const { nome, ordem } = req.body || {};
  if (!nome?.trim()) return res.status(400).json({ erro: "nome e obrigatorio." });
  const info = await db
    .prepare("INSERT INTO categorias (nome, ordem) VALUES (?, ?)")
    .run(nome.trim(), Number(ordem) || 0);
  res.status(201).json(await db.prepare("SELECT * FROM categorias WHERE id = ?").get(info.lastInsertRowid));
});

router.put("/:id", requireAdmin, async (req, res) => {
  const cat = await db.prepare("SELECT * FROM categorias WHERE id = ?").get(req.params.id);
  if (!cat) return res.status(404).json({ erro: "Categoria nao encontrada." });
  const { nome, ordem } = req.body || {};
  await db.prepare("UPDATE categorias SET nome = ?, ordem = ? WHERE id = ?").run(
    nome ?? cat.nome,
    ordem === undefined ? cat.ordem : Number(ordem),
    cat.id,
  );
  res.json(await db.prepare("SELECT * FROM categorias WHERE id = ?").get(cat.id));
});

router.delete("/:id", requireAdmin, async (req, res) => {
  const emUso = await db.prepare("SELECT COUNT(*) AS n FROM turmas WHERE categoria_id = ?").get(req.params.id);
  if (emUso.n > 0) {
    return res.status(409).json({ erro: "Existem turmas usando esta categoria. Mude a categoria delas antes de excluir." });
  }
  await db.prepare("DELETE FROM categorias WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

export default router;
