import { describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";

describe("regras públicas de inscrição", () => {
  it("filtra modalidades femininas e mistas para uma turma do 6º ano", async () => {
    const response = await request(app).get("/api/esportes?turmaId=1&sexo=feminino");
    expect(response.status).toBe(200);
    expect(response.body.length).toBeGreaterThan(0);
    expect(response.body.every((esporte) => esporte.genero !== "masculino")).toBe(true);
  });

  it("filtra modalidades masculinas e mistas para uma turma do 7º ano", async () => {
    const response = await request(app).get("/api/esportes?turmaId=2&sexo=masculino");
    expect(response.status).toBe(200);
    expect(response.body.every((esporte) => esporte.genero !== "feminino")).toBe(true);
  });

  it("retorna provas de Atletismo específicas da categoria", async () => {
    const response = await request(app).get("/api/esportes?turmaId=1&sexo=masculino");
    const atletismo = response.body.find((esporte) => esporte.nome === "Atletismo");
    expect(atletismo).toBeDefined();
    expect(atletismo.provas).toEqual(expect.arrayContaining([
      expect.objectContaining({ nome: "Corrida 75m" }),
    ]));
  });
});
