import { describe, expect, it } from "vitest";
import { tipoSumula } from "./jogos.js";

describe("modelos de súmula", () => {
  it("classifica Atletismo como modalidade de provas", () => {
    expect(tipoSumula("Atletismo")).toBe("atletismo");
  });

  it("classifica Xadrez e Tênis de Mesa como modalidades individuais", () => {
    expect(tipoSumula("Xadrez Masculino")).toBe("individual");
    expect(tipoSumula("Tênis de Mesa Feminino")).toBe("individual");
  });

  it("classifica as demais modalidades como coletivas", () => {
    expect(tipoSumula("Futsal Masculino")).toBe("coletiva");
  });
});
