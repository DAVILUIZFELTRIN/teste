import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin, optionalAdmin } from "../middleware/auth.js";
import { verificarConflitos, esporteEhIndividual } from "../agenda.js";

const router = safeRouter();

// "6º Ano A" -> 6 ... "9º Ano D" -> 9 e "1º Ano EM A" -> 1 ... "3º Ano EM D" -> 3.
function atletismoAnoDaTurma(label = "") {
  const ano = String(label).match(/(?:^|\D)(\d{1,2})\s*[º°o]?\s*ano\b/i)?.[1];
  return ano && Number(ano) >= 1 && Number(ano) <= 12 ? ano : "";
}

// Visitantes veem só o essencial da súmula. Ocorrências, escalações e observações
// (que citam alunos menores de idade) ficam restritas ao administrador.
const CAMPOS_PUBLICOS_DETALHES = ["resultado", "sets", "periodos", "setsResultado", "periodoAtual", "classificacaoDistancia", "colocacoes"];

const SELECT_JOGO = `
  SELECT j.*, e.nome AS esporte_nome, e.icone AS esporte_icone,
         ta.id AS ta_id, tua.id AS time_a_turma_id, tua.label AS time_a_label,
         tb.id AS tb_id, tub.id AS time_b_turma_id, tub.label AS time_b_label
  FROM jogos j
  JOIN esportes e ON e.id = j.esporte_id
  LEFT JOIN times ta ON ta.id = j.time_a_id LEFT JOIN turmas tua ON tua.id = ta.turma_id
  LEFT JOIN times tb ON tb.id = j.time_b_id LEFT JOIN turmas tub ON tub.id = tb.turma_id
`;

export function tipoSumula(nome) {
  if (nome === "Atletismo") return "atletismo";
  if (["Xadrez", "Tênis de Mesa"].some((termo) => nome.includes(termo))) return "individual";
  return "coletiva";
}

export const MODELOS_SUMULA = {
  atletismo: { titulo: "Atletismo", tipo: "atletismo", campos: ["prova", "sexoCompeticao", "participantesA", "resultado"] },
  xadrez: { titulo: "Xadrez", tipo: "individual", campos: ["participantesA", "participantesB", "rodadas", "resultado", "ocorrencias"] },
  "tênis-de-mesa": { titulo: "Tênis de Mesa", tipo: "individual", campos: ["participantesA", "participantesB", "sets", "resultado", "ocorrencias"] },
  futebol: { titulo: "Futebol de Campo", tipo: "coletiva", campos: ["participantesA", "participantesB", "periodos", "substituicoes", "cartoes", "goleadores", "ocorrencias"] },
  futsal: { titulo: "Futsal", tipo: "coletiva", campos: ["participantesA", "participantesB", "periodos", "substituicoes", "cartoes", "goleadores", "ocorrencias"] },
  handebol: { titulo: "Handebol", tipo: "coletiva", campos: ["participantesA", "participantesB", "periodos", "substituicoes", "cartoes", "goleadores", "ocorrencias"] },
  voleibol: { titulo: "Voleibol", tipo: "coletiva", campos: ["participantesA", "participantesB", "sets", "substituicoes", "ocorrencias"] },
  "street-ball": { titulo: "Street-ball", tipo: "coletiva", campos: ["participantesA", "participantesB", "periodos", "substituicoes", "ocorrencias"] },
  "futevôlei": { titulo: "Futevôlei", tipo: "coletiva", campos: ["participantesA", "participantesB", "sets", "ocorrencias"] },
  queimada: { titulo: "Queimada", tipo: "coletiva", campos: ["participantesA", "participantesB", "rodadas", "eliminacoes", "ocorrencias"] },
};

export function modeloSumula(nome) {
  const normalizado = String(nome || "").toLowerCase();
  if (normalizado === "atletismo") return { id: "atletismo", ...MODELOS_SUMULA.atletismo };
  if (normalizado.includes("xadrez")) return { id: "xadrez", ...MODELOS_SUMULA.xadrez };
  if (normalizado.includes("tênis de mesa") || normalizado.includes("tenis de mesa")) return { id: "tênis-de-mesa", ...MODELOS_SUMULA["tênis-de-mesa"] };
  const chave = Object.keys(MODELOS_SUMULA).find((item) => !["atletismo", "xadrez", "tênis-de-mesa"].includes(item) && normalizado.includes(item));
  const id = chave || "futebol";
  return { id, ...MODELOS_SUMULA[id] };
}

export function validarDetalhesSumula(modeloOuTipo, detalhes, finalizar) {
  if (!finalizar) return null;
  const modelo = typeof modeloOuTipo === "string"
    ? (modeloOuTipo === "individual"
      ? { campos: ["participantesA", "participantesB", "sets", "resultado", "ocorrencias"] }
      : modeloOuTipo === "coletiva"
        ? { campos: ["participantesA", "participantesB", "periodos", "ocorrencias"] }
        : MODELOS_SUMULA[modeloOuTipo] || Object.values(MODELOS_SUMULA).find((item) => item.tipo === modeloOuTipo))
    : modeloOuTipo;
  const obrigatorios = modelo?.campos || [];
  const faltantes = obrigatorios.filter((campo) => !String(detalhes?.[campo] ?? "").trim());
  return faltantes.length ? `Preencha os campos da súmula: ${faltantes.join(", ")}.` : null;
}

async function sincronizarClassificacao(database, esporteId) {
  const times = await database.prepare("SELECT id, esporte_id FROM times WHERE esporte_id = ?").all(esporteId);
  const jogos = await database.prepare("SELECT time_a_id, time_b_id, placar_a, placar_b FROM jogos WHERE esporte_id = ? AND status = 'finalizado' AND placar_a IS NOT NULL AND placar_b IS NOT NULL").all(esporteId);
  const tabela = new Map(times.map((time) => [time.id, {
    esporteId: time.esporte_id,
    timeId: time.id,
    pontos: 0,
    jogos: 0,
    vitorias: 0,
    empates: 0,
    derrotas: 0,
    golsPro: 0,
    golsContra: 0,
  }]));
  for (const jogo of jogos) {
    const a = tabela.get(jogo.time_a_id);
    const b = tabela.get(jogo.time_b_id);
    if (!a || !b) continue;
    a.jogos += 1; b.jogos += 1;
    a.golsPro += jogo.placar_a; a.golsContra += jogo.placar_b;
    b.golsPro += jogo.placar_b; b.golsContra += jogo.placar_a;
    if (jogo.placar_a > jogo.placar_b) { a.vitorias += 1; a.pontos += 3; b.derrotas += 1; }
    else if (jogo.placar_a < jogo.placar_b) { b.vitorias += 1; b.pontos += 3; a.derrotas += 1; }
    else { a.empates += 1; b.empates += 1; a.pontos += 1; b.pontos += 1; }
  }
  const atualizadoEm = new Date().toISOString();
  for (const row of tabela.values()) {
    const sql = database.kind === "mysql"
      ? `INSERT INTO classificacoes (esporte_id, time_id, pontos, jogos, vitorias, empates, derrotas, gols_pro, gols_contra, saldo_gols, atualizado_em)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE pontos = VALUES(pontos), jogos = VALUES(jogos), vitorias = VALUES(vitorias), empates = VALUES(empates), derrotas = VALUES(derrotas), gols_pro = VALUES(gols_pro), gols_contra = VALUES(gols_contra), saldo_gols = VALUES(saldo_gols), atualizado_em = VALUES(atualizado_em)`
      : `INSERT OR REPLACE INTO classificacoes (esporte_id, time_id, pontos, jogos, vitorias, empates, derrotas, gols_pro, gols_contra, saldo_gols, atualizado_em)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    await database.prepare(sql).run(row.esporteId, row.timeId, row.pontos, row.jogos, row.vitorias, row.empates, row.derrotas, row.golsPro, row.golsContra, row.golsPro - row.golsContra, atualizadoEm);
  }
}

function shape(row, completo = true) {
  let dados = {};
  try { dados = row.sumula_dados ? JSON.parse(row.sumula_dados) : {}; } catch { dados = {}; }
  return {
    id: row.id,
    esporte: { id: row.esporte_id, nome: row.esporte_nome, icone: row.esporte_icone },
    timeA: row.ta_id ? { id: row.ta_id, turmaId: row.time_a_turma_id, label: row.time_a_label } : null,
    timeB: row.tb_id ? { id: row.tb_id, turmaId: row.time_b_turma_id, label: row.time_b_label } : null,
    data: row.data,
    hora: row.hora,
    local: row.local,
    fase: row.fase,
    status: row.status,
    placarA: row.placar_a,
    placarB: row.placar_b,
    sumula: {
      tipo: tipoSumula(row.esporte_nome),
      modelo: modeloSumula(row.esporte_nome),
      observacoes: completo ? row.sumula_observacoes : null,
      arbitro: row.sumula_arbitro,
      registradoPor: completo ? row.sumula_registrado_por : null,
      registradoEm: row.sumula_registrado_em,
      detalhes: completo
        ? dados
        : Object.fromEntries(CAMPOS_PUBLICOS_DETALHES.filter((c) => dados[c] !== undefined).map((c) => [c, dados[c]])),
    },
  };
}

router.get("/", optionalAdmin, async (req, res) => {
  const { esporteId, status, data } = req.query;
  const clauses = [];
  const params = [];
  if (esporteId) { clauses.push("j.esporte_id = ?"); params.push(esporteId); }
  if (status) { clauses.push("j.status = ?"); params.push(status); }
  if (data) { clauses.push("j.data = ?"); params.push(data); }
  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
  const rows = await db.prepare(`${SELECT_JOGO} ${where} ORDER BY j.data, j.hora`).all(...params);
  res.json(rows.map((row) => shape(row, !!req.admin)));
});

router.get("/:id", optionalAdmin, async (req, res) => {
  const row = await db.prepare(`${SELECT_JOGO} WHERE j.id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ erro: "Jogo nao encontrado." });
  res.json(shape(row, !!req.admin));
});

// Criação em lote usada pelo gerador de tabelas: ou cria TODOS os jogos ou nenhum.
router.post("/lote", requireAdmin, async (req, res) => {
  const { esporteId, jogos } = req.body || {};
  const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(esporteId);
  if (!esporte) return res.status(400).json({ erro: "Esporte invalido." });
  if (esporteEhIndividual(esporte)) return res.status(400).json({ erro: "O gerador de tabelas e para esportes de equipe." });
  if (!Array.isArray(jogos) || jogos.length === 0) return res.status(400).json({ erro: "Nenhum jogo informado." });
  if (jogos.length > 200) return res.status(400).json({ erro: "Limite de 200 jogos por vez." });

  const erros = [];
  const nomes = new Map();
  const vistoLocal = new Set();
  const vistoTime = new Set();
  const lista = [];
  for (const [i, item] of jogos.entries()) {
    const n = i + 1;
    const { timeAId, timeBId, data, hora, local, fase } = item || {};
    if (!timeAId || !timeBId || !data || !hora || !String(local || "").trim()) { erros.push(`Jogo ${n}: dados incompletos.`); continue; }
    if (Number(timeAId) === Number(timeBId)) { erros.push(`Jogo ${n}: os dois times sao iguais.`); continue; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(data) || !/^\d{2}:\d{2}$/.test(hora)) { erros.push(`Jogo ${n}: data ou hora invalida.`); continue; }
    for (const id of [timeAId, timeBId]) {
      if (!nomes.has(Number(id))) {
        const t = await db.prepare("SELECT t.id, tu.label FROM times t JOIN turmas tu ON tu.id = t.turma_id WHERE t.id = ? AND t.esporte_id = ?").get(id, esporte.id);
        nomes.set(Number(id), t?.label || null);
      }
      if (!nomes.get(Number(id))) erros.push(`Jogo ${n}: time ${id} nao pertence ao esporte.`);
    }
    // conflitos dentro do próprio lote
    const chaveLocal = `${data}|${hora}|${String(local).trim().toLowerCase()}`;
    if (vistoLocal.has(chaveLocal)) erros.push(`Jogo ${n}: ${local} ja esta ocupado em ${data} as ${hora} por outro jogo do lote.`);
    vistoLocal.add(chaveLocal);
    for (const id of [timeAId, timeBId]) {
      const chave = `${data}|${hora}|${id}`;
      if (vistoTime.has(chave)) erros.push(`Jogo ${n}: ${nomes.get(Number(id))} joga duas vezes as ${hora}.`);
      vistoTime.add(chave);
    }
    lista.push({ timeAId: Number(timeAId), timeBId: Number(timeBId), data, hora, local: String(local).trim(), fase: String(fase || "Fase de Grupos") });
  }
  if (erros.length) return res.status(400).json({ erro: erros.slice(0, 6).join(" ") });

  try {
    const criados = await db.transaction(async (database) => {
      const ids = [];
      for (const [i, j] of lista.entries()) {
        const repetido = await database
          .prepare(
            `SELECT id FROM jogos WHERE esporte_id = ? AND fase = ? AND
             ((time_a_id = ? AND time_b_id = ?) OR (time_a_id = ? AND time_b_id = ?)) LIMIT 1`,
          )
          .get(esporte.id, j.fase, j.timeAId, j.timeBId, j.timeBId, j.timeAId);
        if (repetido) throw Object.assign(new Error(`Jogo ${i + 1}: ${nomes.get(j.timeAId)} x ${nomes.get(j.timeBId)} (${j.fase}) ja existe.`), { status: 409 });
        const conflitos = await verificarConflitos(database, { esporteId: esporte.id, timeIds: [j.timeAId, j.timeBId], data: j.data, hora: j.hora, local: j.local });
        if (conflitos.length) throw Object.assign(new Error(`Jogo ${i + 1}: ${conflitos.join(" ")}`), { status: 409 });
        const info = await database
          .prepare("INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'agendado')")
          .run(esporte.id, j.timeAId, j.timeBId, j.data, j.hora, j.local, j.fase);
        ids.push(info.lastInsertRowid);
      }
      return ids;
    });
    res.status(201).json({ criados: criados.length, ids: criados });
  } catch (erro) {
    if (erro?.status === 409) return res.status(409).json({ erro: `Nenhum jogo foi criado. ${erro.message}` });
    throw erro;
  }
});

router.post("/", requireAdmin, async (req, res) => {
  const { esporteId, timeAId, timeBId, atletismoAno, atletismoProvaId, xadrezAno, xadrezSexo, data, hora, local, fase } = req.body || {};
  const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(esporteId);
  const isAtletismo = String(esporte?.nome || "").toLowerCase() === "atletismo";
  const isXadrezIndividual = String(esporte?.nome || "").toLowerCase().includes("xadrez") || esporte?.modalidade === "individual" && String(esporte?.nome || "").toLowerCase().includes("xadrez");
  let resolvedTimeAId = timeAId;
  let resolvedTimeBId = timeBId;
  let resolvedFase = fase || "Fase de Grupos";
  if (isAtletismo) {
    const ano = Number(atletismoAno);
    const prova = await db.prepare("SELECT id, nome, categoria_id FROM provas_atletismo WHERE id = ? AND ativo = 1").get(atletismoProvaId);
    if (!Number.isInteger(ano) || ano < 1 || ano > 12) return res.status(400).json({ erro: "Selecione um ano válido para o Atletismo." });
    if (!prova) return res.status(400).json({ erro: "Selecione a prova da súmula de Atletismo." });
    const candidatosTodos = await db.prepare("SELECT ti.id, t.label FROM times ti JOIN turmas t ON t.id = ti.turma_id WHERE ti.esporte_id = ? ORDER BY t.label, ti.id").all(esporteId);
    const candidatos = candidatosTodos.filter((item) => Number(atletismoAnoDaTurma(item.label)) === ano);
    if (candidatos.length < 2) return res.status(400).json({ erro: `Não há turmas suficientes para criar a súmula do ${ano}º ano.` });
    [resolvedTimeAId, resolvedTimeBId] = [candidatos[0].id, candidatos[1].id];
    resolvedFase = `Atletismo · ${ano}º ano · ${prova.nome}`;
  }
  if (isXadrezIndividual) {
    const ano = Number(xadrezAno);
    const sexo = ["masculino", "feminino"].includes(String(esporte?.genero || "").toLowerCase())
      ? String(esporte.genero).toLowerCase()
      : (["masculino", "feminino"].includes(String(xadrezSexo || "").toLowerCase()) ? String(xadrezSexo).toLowerCase() : "");
    if (!Number.isInteger(ano) || ano < 1 || ano > 12) return res.status(400).json({ erro: "Selecione o ano da competição de Xadrez." });
    if (!sexo) return res.status(400).json({ erro: "Selecione o sexo da competição de Xadrez." });
    resolvedTimeAId = null; resolvedTimeBId = null;
    resolvedFase = `Xadrez · ${ano}º ano · ${sexo === "feminino" ? "Feminino" : "Masculino"}`;
  }
  if (!esporteId || (!isXadrezIndividual && (!resolvedTimeAId || !resolvedTimeBId)) || !data || !hora || !local) {
    return res.status(400).json({ erro: isXadrezIndividual ? "esporteId, ano, sexo, data, hora e local sao obrigatorios." : "esporteId, timeAId, timeBId, data, hora e local sao obrigatorios." });
  }
  if (!isXadrezIndividual && Number(resolvedTimeAId) === Number(resolvedTimeBId)) return res.status(400).json({ erro: "Os dois times devem ser diferentes." });
  if (!isXadrezIndividual) {
    const timeA = await db.prepare("SELECT * FROM times WHERE id = ? AND esporte_id = ?").get(resolvedTimeAId, esporteId);
    const timeB = await db.prepare("SELECT * FROM times WHERE id = ? AND esporte_id = ?").get(resolvedTimeBId, esporteId);
    if (!timeA || !timeB) return res.status(400).json({ erro: "Os times informados nao pertencem ao esporte selecionado." });
  }
  if (!isAtletismo && !isXadrezIndividual && !esporteEhIndividual(esporte)) {
    const conflitos = await verificarConflitos(db, { esporteId: Number(esporteId), timeIds: [resolvedTimeAId, resolvedTimeBId], data, hora, local });
    if (conflitos.length) return res.status(409).json({ erro: `Conflito de agenda: ${conflitos.join(" ")}` });
  }
  const info = await db
    .prepare(
      `INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'agendado')`,
    )
    .run(esporteId, resolvedTimeAId, resolvedTimeBId, data, hora, local, resolvedFase);
  const row = await db.prepare(`${SELECT_JOGO} WHERE j.id = ?`).get(info.lastInsertRowid);
  res.status(201).json(shape(row));
});

router.put("/:id", requireAdmin, async (req, res) => {
  const jogo = await db.prepare("SELECT * FROM jogos WHERE id = ?").get(req.params.id);
  if (!jogo) return res.status(404).json({ erro: "Jogo nao encontrado." });
  const { data, hora, local, fase, status } = req.body || {};
  if (status === "finalizado" && (jogo.placar_a === null || jogo.placar_b === null)) {
    return res.status(400).json({ erro: "Para finalizar o jogo registre o placar pela súmula." });
  }
  if ((data !== undefined || hora !== undefined || local !== undefined) && jogo.time_a_id && jogo.time_b_id) {
    const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(jogo.esporte_id);
    if (!esporteEhIndividual(esporte)) {
      const conflitos = await verificarConflitos(db, {
        esporteId: jogo.esporte_id, timeIds: [jogo.time_a_id, jogo.time_b_id],
        data: data ?? jogo.data, hora: hora ?? jogo.hora, local: local ?? jogo.local, ignorarJogoId: jogo.id,
      });
      if (conflitos.length) return res.status(409).json({ erro: `Conflito de agenda: ${conflitos.join(" ")}` });
    }
  }
  await db.prepare("UPDATE jogos SET data = ?, hora = ?, local = ?, fase = ?, status = ? WHERE id = ?").run(
    data ?? jogo.data,
    hora ?? jogo.hora,
    local ?? jogo.local,
    fase ?? jogo.fase,
    status ?? jogo.status,
    jogo.id,
  );
  res.json(shape(await db.prepare(`${SELECT_JOGO} WHERE j.id = ?`).get(jogo.id)));
});

router.put("/:id/sumula", requireAdmin, async (req, res) => {
  const jogo = await db.prepare("SELECT * FROM jogos WHERE id = ?").get(req.params.id);
  if (!jogo) return res.status(404).json({ erro: "Jogo nao encontrado." });
  const { placarA, placarB, observacoes, arbitro, detalhes, finalizar, reabrir, motivoReabertura } = req.body || {};
  const jogoAnterior = jogo;
  const inteiroNaoNegativo = (valor) => (typeof valor === "number" || (typeof valor === "string" && valor.trim() !== "")) && /^\d+$/.test(String(valor).trim());
  if (!inteiroNaoNegativo(placarA) || !inteiroNaoNegativo(placarB)) return res.status(400).json({ erro: "O placar deve ser formado por números inteiros iguais ou maiores que zero." });
  if (jogoAnterior.status === "finalizado" && !reabrir) return res.status(409).json({ erro: "Esta súmula já foi finalizada. Informe um motivo para reabri-la antes de alterar." });
  if (jogoAnterior.status === "finalizado" && reabrir && !String(motivoReabertura || "").trim()) return res.status(400).json({ erro: "Informe o motivo da reabertura da súmula." });
  const esporte = await db.prepare("SELECT nome FROM esportes WHERE id = ?").get(jogo.esporte_id);
  const modelo = modeloSumula(esporte?.nome || "");
  const detalhesNormalizados = detalhes && typeof detalhes === "object" ? detalhes : {};
  const erroDetalhes = validarDetalhesSumula(modelo, detalhesNormalizados, finalizar !== false);
  if (placarA === undefined || placarB === undefined) return res.status(400).json({ erro: "placarA e placarB sao obrigatorios." });
  if (erroDetalhes) return res.status(400).json({ erro: erroDetalhes });
  const registradoPor = req.admin?.nome || req.admin?.username || "admin";
  const registradoEm = new Date().toISOString();
  const status = finalizar === false ? "em_andamento" : "finalizado";
  await db.prepare(
    `UPDATE jogos SET placar_a = ?, placar_b = ?, sumula_observacoes = ?, sumula_arbitro = ?, sumula_dados = ?,
       sumula_registrado_por = ?, sumula_registrado_em = ?, status = ?
     WHERE id = ?`,
  ).run(
    Number(placarA), Number(placarB), observacoes || null, arbitro || null,
    JSON.stringify(detalhesNormalizados), registradoPor, registradoEm, status, jogo.id,
  );
  const sumulaSql = db.kind === "mysql"
    ? `INSERT INTO sumulas (jogo_id, modelo_id, dados, observacoes, arbitro, registrado_por, registrado_em)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE modelo_id = VALUES(modelo_id), dados = VALUES(dados), observacoes = VALUES(observacoes), arbitro = VALUES(arbitro), registrado_por = VALUES(registrado_por), registrado_em = VALUES(registrado_em)`
    : `INSERT OR REPLACE INTO sumulas (jogo_id, modelo_id, dados, observacoes, arbitro, registrado_por, registrado_em)
       VALUES (?, ?, ?, ?, ?, ?, ?)`;
  await db.prepare(sumulaSql).run(jogo.id, modelo.id, JSON.stringify(detalhesNormalizados), observacoes || null, arbitro || null, registradoPor, registradoEm);
  if (jogoAnterior.status === "finalizado" && reabrir) {
    await db.prepare("INSERT INTO auditoria_jogos (jogo_id, acao, motivo, realizado_por, realizado_em) VALUES (?, 'reabertura', ?, ?, ?)").run(jogo.id, String(motivoReabertura).trim(), registradoPor, registradoEm);
  }
  await sincronizarClassificacao(db, jogo.esporte_id);
  res.json(shape(await db.prepare(`${SELECT_JOGO} WHERE j.id = ?`).get(jogo.id)));
});

router.delete("/:id", requireAdmin, async (req, res) => {
  const jogo = await db.prepare("SELECT * FROM jogos WHERE id = ?").get(req.params.id);
  if (!jogo) return res.status(404).json({ erro: "Jogo nao encontrado." });
  const { confirmacao, motivo } = req.body || {};
  if (jogo.status === "finalizado" && (confirmacao !== "EXCLUIR JOGO FINALIZADO" || !String(motivo || "").trim())) return res.status(400).json({ erro: "Para excluir jogo finalizado, confirme digitando EXCLUIR JOGO FINALIZADO e informe o motivo." });
  await db.prepare("INSERT INTO auditoria_jogos (jogo_id, acao, motivo, realizado_por, realizado_em) VALUES (?, ?, ?, ?, ?)").run(jogo.id, "exclusao", motivo || "Exclusão administrativa", req.admin?.nome || "admin", new Date().toISOString());
  await db.prepare("DELETE FROM jogos WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

export default router;
