import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";
import { storagePut } from "../../storage.ts";
import { ENV } from "../../_core/env.ts";
import { VALOR_INSCRICAO } from "../config.js";

const router = safeRouter();


function decodeQrCode(dataUrl) {
  if (!dataUrl) return null;
  const match = String(dataUrl).match(/^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new Error("O QR Code deve ser uma imagem PNG válida. JPG e WEBP também são aceitos.");
  const buffer = Buffer.from(match[2], "base64");
  if (!buffer.length || buffer.length > 5 * 1024 * 1024) throw new Error("A imagem do QR Code deve ter até 5 MB.");
  return { buffer, contentType: match[1] === "image/jpg" ? "image/jpeg" : match[1] };
}

// Salva o QR Code. Se o armazenamento externo (Manus) estiver configurado, usa ele; caso contrário
// guarda a imagem no próprio banco e serve por /api/turmas/:id/qr (funciona em qualquer hospedagem).
async function salvarQrCode(turmaId, dataUrl) {
  const decoded = decodeQrCode(dataUrl);
  if (!decoded) return null;
  if (ENV.forgeApiUrl && ENV.forgeApiKey) {
    const uploaded = await storagePut(`turmas/${turmaId}/qr-code`, decoded.buffer, decoded.contentType);
    return { url: uploaded.url, data: null };
  }
  return { url: `/api/turmas/${turmaId}/qr?v=${Date.now()}`, data: String(dataUrl) };
}

const SELECT = `
  SELECT t.id, t.label, t.categoria_id, t.taxa, t.vagas, t.ativo, t.qr_code_url, c.nome AS categoria_nome
  FROM turmas t JOIN categorias c ON c.id = t.categoria_id
`;

async function withExtras(turma) {
  const registered = await db
    .prepare("SELECT COUNT(*) AS n FROM inscricoes WHERE turma_id = ? AND status_pagamento != 'cancelado'")
    .get(turma.id);
  return {
    ...turma,
    ativo: !!turma.ativo,
    inscritos: registered.n,
    categoria: { id: turma.categoria_id, nome: turma.categoria_nome },
  };
}

router.get("/", async (req, res) => {
  const all = req.query.all === "1";
  const rows = all
    ? await db.prepare(`${SELECT} ORDER BY t.label`).all()
    : await db.prepare(`${SELECT} WHERE t.ativo = 1 ORDER BY t.label`).all();
  res.json(await Promise.all(rows.map(withExtras)));
});

router.get("/:id/qr", async (req, res) => {
  const turma = await db.prepare("SELECT qr_code_data FROM turmas WHERE id = ?").get(req.params.id);
  const match = String(turma?.qr_code_data || "").match(/^data:(image\/[a-z+]+);base64,(.+)$/);
  if (!match) return res.status(404).json({ erro: "QR Code nao cadastrado." });
  res.set({ "Content-Type": match[1], "Cache-Control": "public, max-age=3600" });
  res.send(Buffer.from(match[2], "base64"));
});

router.get("/:id/alunos", requireAdmin, async (req, res) => {
  const turmaId = Number(req.params.id);
  const turma = await db.prepare(`${SELECT} WHERE t.id = ?`).get(turmaId);
  if (!turma) return res.status(404).json({ erro: "Turma nao encontrada." });
  const esporteId = req.query.esporteId ? Number(req.query.esporteId) : null;
  if (req.query.esporteId && !Number.isInteger(esporteId)) {
    return res.status(400).json({ erro: "esporteId invalido." });
  }
  const sexo = req.query.sexo ? String(req.query.sexo).toLowerCase() : null;
  if (sexo && !["masculino", "feminino"].includes(sexo)) {
    return res.status(400).json({ erro: "sexo invalido." });
  }
  const esporteClause = esporteId
    ? " AND EXISTS (SELECT 1 FROM inscricao_esportes ie_esporte JOIN esportes esporte_alvo ON esporte_alvo.id = ie_esporte.esporte_id WHERE ie_esporte.inscricao_id = i.id AND ie_esporte.esporte_id = ? AND (esporte_alvo.genero = 'misto' OR LOWER(i.sexo) = LOWER(esporte_alvo.genero)))"
    : "";
  const sexoClause = sexo ? " AND LOWER(i.sexo) = ?" : "";
  const esporteParams = [...(esporteId ? [esporteId] : []), ...(sexo ? [sexo] : [])];
  const alunos = await db.prepare(`
    SELECT i.id, i.codigo, i.nome, i.matricula, i.sexo, i.status_pagamento, i.valor,
      GROUP_CONCAT(DISTINCT e.nome) AS esportes_nomes
    FROM inscricoes i
    LEFT JOIN inscricao_esportes ie ON ie.inscricao_id = i.id
    LEFT JOIN esportes e ON e.id = ie.esporte_id
    WHERE i.turma_id = ? AND i.status_pagamento != 'cancelado'${esporteClause}${sexoClause}
    GROUP BY i.id, i.codigo, i.nome, i.matricula, i.sexo, i.status_pagamento, i.valor
    ORDER BY LOWER(i.nome), i.nome, i.id
  `).all(turmaId, ...esporteParams);
  const alunosComProvas = await Promise.all(alunos.map(async (aluno) => {
    const provas = await db.prepare(`
      SELECT p.nome FROM inscricao_provas_atletismo ipa
      JOIN provas_atletismo p ON p.id = ipa.prova_id
      WHERE ipa.inscricao_id = ? ORDER BY p.ordem, p.id
    `).all(aluno.id);
    return {
      ...aluno,
      esportes: aluno.esportes_nomes ? aluno.esportes_nomes.split(",").map((nome) => nome.trim()).filter(Boolean) : [],
      esportes_nomes: undefined,
      provasAtletismo: provas.map((prova) => prova.nome),
    };
  }));
  res.json({ turma: { id: turma.id, label: turma.label, categoria: { id: turma.categoria_id, nome: turma.categoria_nome } }, alunos: alunosComProvas });
});

router.post("/", requireAdmin, async (req, res) => {
  const { label, categoriaId, taxa, vagas, qrCodeDataUrl } = req.body || {};
  if (!label || !categoriaId) return res.status(400).json({ erro: "label e categoriaId sao obrigatorios." });
  const categoria = await db.prepare("SELECT * FROM categorias WHERE id = ?").get(categoriaId);
  if (!categoria) return res.status(400).json({ erro: "Categoria invalida." });
  const info = await db
    .prepare("INSERT INTO turmas (label, categoria_id, taxa, vagas, ativo) VALUES (?, ?, ?, ?, 1)")
    .run(label, categoriaId, VALOR_INSCRICAO, Number(vagas) || 40);
  try {
    const qr = await salvarQrCode(info.lastInsertRowid, qrCodeDataUrl);
    if (qr) await db.prepare("UPDATE turmas SET qr_code_url = ?, qr_code_data = ? WHERE id = ?").run(qr.url, qr.data, info.lastInsertRowid);
  } catch (error) {
    return res.status(400).json({ erro: error.message || "Não foi possível salvar o QR Code." });
  }
  const row = await db.prepare(`${SELECT} WHERE t.id = ?`).get(info.lastInsertRowid);
  res.status(201).json(await withExtras(row));
});

router.put("/:id", requireAdmin, async (req, res) => {
  const turma = await db.prepare("SELECT * FROM turmas WHERE id = ?").get(req.params.id);
  if (!turma) return res.status(404).json({ erro: "Turma nao encontrada." });
  const { label, categoriaId, taxa, vagas, ativo, qrCodeDataUrl, removerQrCode } = req.body || {};
  if (categoriaId) {
    const categoria = await db.prepare("SELECT * FROM categorias WHERE id = ?").get(categoriaId);
    if (!categoria) return res.status(400).json({ erro: "Categoria invalida." });
  }
  let qrCodeUrl = removerQrCode ? null : turma.qr_code_url;
  let qrCodeData = removerQrCode ? null : turma.qr_code_data;
  try {
    const novoQr = await salvarQrCode(turma.id, qrCodeDataUrl);
    if (novoQr) { qrCodeUrl = novoQr.url; qrCodeData = novoQr.data; }
  } catch (error) {
    return res.status(400).json({ erro: error.message || "Não foi possível salvar o QR Code." });
  }
  await db.prepare(
    "UPDATE turmas SET label = ?, categoria_id = ?, taxa = ?, vagas = ?, ativo = ?, qr_code_url = ?, qr_code_data = ? WHERE id = ?",
  ).run(
    label ?? turma.label,
    categoriaId ?? turma.categoria_id,
    VALOR_INSCRICAO, // valor único para todas as turmas
    vagas ?? turma.vagas,
    ativo === undefined ? turma.ativo : ativo ? 1 : 0,
    qrCodeUrl,
    qrCodeData,
    turma.id,
  );
  res.json(await withExtras(await db.prepare(`${SELECT} WHERE t.id = ?`).get(turma.id)));
});

router.delete("/:id", requireAdmin, async (req, res) => {
  const emUso = await db.prepare("SELECT COUNT(*) AS n FROM inscricoes WHERE turma_id = ?").get(req.params.id);
  if (emUso.n > 0) {
    return res.status(409).json({ erro: "Existem inscricoes vinculadas a esta turma. Desative-a em vez de excluir." });
  }
  await db.prepare("DELETE FROM turmas WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

export default router;
