import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let token: string;
const auth = () => ({ Authorization: `Bearer ${token}` });
const ids: Record<string, number> = {};
const jogosCriados: number[] = [];
const matriculasCriadas: string[] = [];

async function turma(label: string) {
  return (await db.prepare("SELECT id, categoria_id FROM turmas WHERE label = ?").get(label)) as any;
}
async function esporte(nome: string) {
  return (await db.prepare("SELECT id FROM esportes WHERE nome = ?").get(nome)) as any;
}
async function inscrever(matricula: string, label: string, esporteId: number, extra: object = {}) {
  matriculasCriadas.push(matricula);
  const t = await turma(label);
  return request(app).post("/api/inscricoes").send({ nome: `Aluno ${matricula}`, matricula, sexo: "masculino", turmaId: t.id, esportes: [esporteId], ...extra });
}

beforeAll(async () => {
  token = signToken(await db.prepare("SELECT * FROM admins LIMIT 1").get());
  const futsal = await esporte("Futsal Masculino");
  ids.futsal = futsal.id;
  // inscrições em sequência criam os times
  for (const [i, label] of ["9º Ano A", "9º Ano B", "9º Ano C", "9º Ano D"].entries()) await inscrever(`7${i}001`, label, futsal.id);
  for (const label of ["9º Ano A", "9º Ano B", "9º Ano C", "9º Ano D"]) {
    const t = await turma(label);
    ids[label] = ((await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(futsal.id, t.id)) as any).id;
  }
});

afterAll(async () => {
  for (const id of jogosCriados) await db.prepare("DELETE FROM jogos WHERE id = ?").run(id);
  for (const m of new Set(matriculasCriadas)) await db.prepare("DELETE FROM inscricoes WHERE matricula = ?").run(m);
});

describe("estabilidade (antes derrubavam o servidor)", () => {
  it("vários alunos diferentes se inscrevem ao mesmo tempo na mesma turma e esporte", async () => {
    const respostas = await Promise.all(Array.from({ length: 10 }, (_, i) => inscrever(`7${i}100`, "9º Ano A", ids.futsal)));
    expect(respostas.every((r) => r.status === 201)).toBe(true);
    const t = await turma("9º Ano A");
    const times = (await db.prepare("SELECT COUNT(*) AS n FROM times WHERE esporte_id = ? AND turma_id = ?").get(ids.futsal, t.id)) as any;
    expect(Number(times.n)).toBe(1);
    expect((await request(app).get("/api/health")).status).toBe(200);
  });

  it("data inválida na configuração responde 400 em vez de derrubar o servidor", async () => {
    const r = await request(app).put("/api/configuracoes").set(auth()).send({ inscricoesAbertasEm: "lixo" });
    expect(r.status).toBe(400);
    expect((await request(app).get("/api/health")).status).toBe(200);
  });

  it("mesma matrícula enviada ao mesmo tempo grava só uma inscrição", async () => {
    const respostas = await Promise.all(Array.from({ length: 6 }, () => inscrever("89999", "9º Ano B", ids.futsal)));
    expect(respostas.filter((r) => r.status === 201)).toHaveLength(1);
  });
});

describe("regras de inscrição", () => {
  it("matrícula exige 5 números e o valor é sempre R$ 25", async () => {
    for (const m of ["1234", "123456", "12a45", "abcde"]) expect((await inscrever(m, "9º Ano C", ids.futsal)).status).toBe(400);
    const t = await turma("9º Ano C");
    await request(app).put(`/api/turmas/${t.id}`).set(auth()).send({ label: "9º Ano C", categoriaId: t.categoria_id, taxa: 99, vagas: 40, ativo: true });
    const r = await inscrever("88888", "9º Ano C", ids.futsal);
    expect(r.status).toBe(201);
    expect(Number(r.body.valor)).toBe(25);
  });

  it("busca por nome recusa curingas e consulta por matrícula não revela sexo nem PIX", async () => {
    expect((await request(app).get("/api/inscricoes/status?nome=%25%25%25")).status).toBe(400);
    expect((await request(app).get("/api/inscricoes/status?nome=ab")).status).toBe(400);
    const r = await request(app).get("/api/inscricoes/status?matricula=88888");
    expect(r.status).toBe(200);
    expect(r.body.sexo).toBeUndefined();
    expect(r.body.pix_code).toBeUndefined();
  });
});

describe("agenda e gerador em lote", () => {
  const jogo = (a: string, b: string, hora: string, local: string, fase = "Teste Lote") => ({
    timeAId: ids[a], timeBId: ids[b], data: "2099-08-01", hora, local, fase,
  });

  it("cria tudo ou nada e recusa conflito de quadra, de time e jogo repetido", async () => {
    const ok = await request(app).post("/api/jogos/lote").set(auth()).send({
      esporteId: ids.futsal, jogos: [jogo("9º Ano A", "9º Ano B", "08:00", "Q1"), jogo("9º Ano C", "9º Ano D", "08:00", "Q2")],
    });
    expect(ok.status).toBe(201);
    jogosCriados.push(...ok.body.ids);

    const repetido = await request(app).post("/api/jogos/lote").set(auth()).send({ esporteId: ids.futsal, jogos: [jogo("9º Ano A", "9º Ano B", "10:00", "Q1")] });
    expect(repetido.status).toBe(409);

    const antes = (await db.prepare("SELECT COUNT(*) AS n FROM jogos").get()) as any;
    const parcial = await request(app).post("/api/jogos/lote").set(auth()).send({
      esporteId: ids.futsal, jogos: [jogo("9º Ano A", "9º Ano C", "11:00", "Q1", "Outra"), jogo("9º Ano B", "9º Ano D", "08:00", "Q1", "Outra")],
    });
    expect(parcial.status).toBe(409);
    const depois = (await db.prepare("SELECT COUNT(*) AS n FROM jogos").get()) as any;
    expect(Number(depois.n)).toBe(Number(antes.n));
  });

  it("não deixa marcar jogo na mesma quadra/horário nem o mesmo time duas vezes", async () => {
    const quadra = await request(app).post("/api/jogos").set(auth()).send({ esporteId: ids.futsal, timeAId: ids["9º Ano A"], timeBId: ids["9º Ano D"], data: "2099-08-01", hora: "08:00", local: "Q2" });
    expect(quadra.status).toBe(409);
    const time = await request(app).post("/api/jogos").set(auth()).send({ esporteId: ids.futsal, timeAId: ids["9º Ano A"], timeBId: ids["9º Ano C"], data: "2099-08-01", hora: "08:00", local: "Q9" });
    expect(time.status).toBe(409);
  });

  it("não finaliza jogo sem placar", async () => {
    const r = await request(app).post("/api/jogos").set(auth()).send({ esporteId: ids.futsal, timeAId: ids["9º Ano B"], timeBId: ids["9º Ano D"], data: "2099-08-02", hora: "08:00", local: "Q1" });
    jogosCriados.push(r.body.id);
    expect((await request(app).put(`/api/jogos/${r.body.id}`).set(auth()).send({ status: "finalizado" })).status).toBe(400);
  });
});

describe("relatório final", () => {
  it("lista artilharia e cartões corretamente e não confunde nomes com 'gol'", async () => {
    const r = await request(app).post("/api/jogos").set(auth()).send({ esporteId: ids.futsal, timeAId: ids["9º Ano A"], timeBId: ids["9º Ano B"], data: "2099-08-03", hora: "08:00", local: "Q5", fase: "Relatorio" });
    jogosCriados.push(r.body.id);
    const detalhes = {
      participantesA: "a", participantesB: "b", periodos: "1", substituicoes: "x", cartoes: "y", goleadores: "z", ocorrencias: "-", resultado: "2x0",
      eventos: [{ time: "01:00", text: "GOLS · Ana Relatorio" }, { time: "02:00", text: "GOLS · Ana Relatorio" }, { time: "03:00", text: "AMARELOS · Rogolino Relatorio" }, { time: "04:00", text: "VERMELHOS · Bia Relatorio" }],
    };
    const s = await request(app).put(`/api/jogos/${r.body.id}/sumula`).set(auth()).send({ placarA: 2, placarB: 0, arbitro: "X", detalhes, finalizar: true });
    expect(s.status).toBe(200);
    const rel = await request(app).get("/api/admin/relatorio").set(auth());
    const gols = Object.fromEntries(rel.body.artilharia.map((a: any) => [a.nome, a.total]));
    expect(gols["Ana Relatorio"]).toBe(2);
    expect(gols["Rogolino Relatorio"]).toBeUndefined();
    const cartoes = Object.fromEntries(rel.body.cartoes.map((c: any) => [c.nome, c.detalhe]));
    expect(cartoes["Rogolino Relatorio"]).toBe("1 amarelo(s)");
    expect(cartoes["Bia Relatorio"]).toBe("1 vermelho(s)");
    expect(rel.body.arrecadacao).toBeDefined();
    expect(Array.isArray(rel.body.campeoes)).toBe(true);
  });
});

describe("Atletismo do Ensino Médio", () => {
  it("cria súmula para 1º ano EM e para 8º ano", async () => {
    const atletismo = await esporte("Atletismo");
    for (const [label, matricula] of [["1º Ano EM A", "87001"], ["1º Ano EM B", "87002"], ["8º Ano A", "87003"], ["8º Ano B", "87004"]]) {
      const t = await turma(label);
      const prova = (await db.prepare("SELECT id FROM provas_atletismo WHERE (categoria_id = ? OR categoria_id IS NULL) AND ativo = 1 LIMIT 1").get(t.categoria_id)) as any;
      await inscrever(matricula, label, atletismo.id, { provasAtletismo: [prova.id] });
    }
    for (const [ano, label] of [[1, "1º Ano EM A"], [8, "8º Ano A"]] as const) {
      const t = await turma(label);
      const prova = (await db.prepare("SELECT id FROM provas_atletismo WHERE (categoria_id = ? OR categoria_id IS NULL) AND ativo = 1 LIMIT 1").get(t.categoria_id)) as any;
      const r = await request(app).post("/api/jogos").set(auth()).send({ esporteId: atletismo.id, atletismoAno: ano, atletismoProvaId: prova.id, data: "2099-08-04", hora: "08:00", local: "Pista" });
      expect(r.status).toBe(201);
      jogosCriados.push(r.body.id);
    }
  });
});
