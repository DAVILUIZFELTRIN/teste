import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";

const router = safeRouter();

// Tabela de classificação de um esporte de equipe (3 pontos vitória, 1 empate).
export async function tabelaEquipes(esporteId) {
  const times = await db
    .prepare(
      `SELECT t.id AS time_id, tu.label AS turma_label
       FROM times t JOIN turmas tu ON tu.id = t.turma_id
       WHERE t.esporte_id = ?`,
    )
    .all(esporteId);

  const tabela = new Map(
    times.map((t) => [
      t.time_id,
      {
        timeId: t.time_id,
        turma: t.turma_label,
        pontos: 0,
        jogos: 0,
        vitorias: 0,
        empates: 0,
        derrotas: 0,
        golsPro: 0,
        golsContra: 0,
      },
    ]),
  );

  const jogos = await db
    .prepare("SELECT * FROM jogos WHERE esporte_id = ? AND status = 'finalizado' AND placar_a IS NOT NULL")
    .all(esporteId);

  for (const j of jogos) {
    const a = tabela.get(j.time_a_id);
    const b = tabela.get(j.time_b_id);
    if (!a || !b) continue;
    a.jogos += 1;
    b.jogos += 1;
    a.golsPro += j.placar_a;
    a.golsContra += j.placar_b;
    b.golsPro += j.placar_b;
    b.golsContra += j.placar_a;
    if (j.placar_a > j.placar_b) {
      a.vitorias += 1;
      a.pontos += 3;
      b.derrotas += 1;
    } else if (j.placar_a < j.placar_b) {
      b.vitorias += 1;
      b.pontos += 3;
      a.derrotas += 1;
    } else {
      a.empates += 1;
      b.empates += 1;
      a.pontos += 1;
      b.pontos += 1;
    }
  }

  const resultado = [...tabela.values()]
    .map((r) => ({ ...r, saldoGols: r.golsPro - r.golsContra }))
    .sort((x, y) => y.pontos - x.pontos || y.saldoGols - x.saldoGols || y.golsPro - x.golsPro);

  return resultado;
}

router.get("/", async (req, res) => {
  const { esporteId } = req.query;
  if (!esporteId) return res.status(400).json({ erro: "esporteId e obrigatorio." });

  const esporte = await db.prepare("SELECT nome, modalidade FROM esportes WHERE id = ?").get(esporteId);
  const individual = esporte?.modalidade === "individual" || /atletismo|xadrez/i.test(String(esporte?.nome || ""));
  if (individual) {
    const jogosIndividuais = await db.prepare("SELECT fase, sumula_dados FROM jogos WHERE esporte_id = ? AND status = 'finalizado' AND sumula_dados IS NOT NULL ORDER BY id DESC").all(esporteId);
    const resultados = [];
    for (const jogo of jogosIndividuais) {
      try {
        const dados = JSON.parse(jogo.sumula_dados || "{}");
        const lista = Array.isArray(dados.colocacoes) ? dados.colocacoes : Array.isArray(dados.classificacaoDistancia) ? dados.classificacaoDistancia : [];
        lista.forEach((item, index) => resultados.push({ colocacao: Number(item.posicao || index + 1), participante: item.nome || "Participante", turma: item.turmaLabel || "", resultado: item.distancia ? `${item.distancia} m` : item.resultado || "Registrado", fase: jogo.fase }));
      } catch {}
    }
    return res.json({ tipo: "individual", esporte: esporte?.nome, resultados });
  }
  res.json(await tabelaEquipes(esporteId));
});

export default router;
