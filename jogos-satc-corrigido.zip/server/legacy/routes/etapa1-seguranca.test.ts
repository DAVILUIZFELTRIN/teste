import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let token;
let jogoId;

beforeAll(async () => {
  token = signToken(await db.prepare("SELECT * FROM admins LIMIT 1").get());
  const esporte = await db.prepare("SELECT id FROM esportes WHERE nome = 'Futsal Masculino'").get();
  const turmaA = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
  const turmaB = await db.prepare("SELECT id FROM turmas WHERE label = '7º Ano C'").get();
  await db.prepare("INSERT IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaA.id);
  await db.prepare("INSERT IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaB.id);
  const a = await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaA.id);
  const b = await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaB.id);
  jogoId = (await db.prepare("INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status) VALUES (?, ?, ?, '2099-05-01', '09:00', 'Teste Etapa 1', 'Teste', 'agendado')").run(esporte.id, a.id, b.id)).lastInsertRowid;
  await request(app).put(`/api/jogos/${jogoId}/sumula`).set("Authorization", `Bearer ${token}`).send({
    placarA: 1, placarB: 0, arbitro: "Prof. Teste", observacoes: "Observação com nome de aluno",
    detalhes: { participantesA: "a", participantesB: "b", periodos: "1", substituicoes: "x", cartoes: "y", goleadores: "z", ocorrencias: "Fulano expulso", resultado: "1x0" },
  });
});

afterAll(async () => {
  await db.prepare("DELETE FROM jogos WHERE id = ?").run(jogoId);
});

describe("privacidade dos jogos", () => {
  it("visitante não vê ocorrências nem observações; admin vê tudo", async () => {
    const publico = await request(app).get(`/api/jogos/${jogoId}`);
    expect(publico.body.sumula.detalhes.ocorrencias).toBeUndefined();
    expect(publico.body.sumula.observacoes).toBeNull();
    expect(publico.body.sumula.detalhes.resultado).toBe("1x0");
    const lista = await request(app).get("/api/jogos");
    expect(JSON.stringify(lista.body)).not.toContain("Fulano expulso");
    const admin = await request(app).get(`/api/jogos/${jogoId}`).set("Authorization", `Bearer ${token}`);
    expect(admin.body.sumula.detalhes.ocorrencias).toBe("Fulano expulso");
  });
});

describe("login e renovação", () => {
  it("renova o token de um admin logado e recusa quem não está logado", async () => {
    const ok = await request(app).post("/api/auth/renovar").set("Authorization", `Bearer ${token}`);
    expect(ok.status).toBe(200);
    expect(typeof ok.body.token).toBe("string");
    const sem = await request(app).post("/api/auth/renovar");
    expect(sem.status).toBe(401);
  });

  it("áreas de admin exigem login", async () => {
    expect((await request(app).get("/api/admin/dashboard")).status).toBe(401);
    expect((await request(app).get("/api/inscricoes")).status).toBe(401);
  });
});

describe("erros tratados", () => {
  it("JSON quebrado e rota inexistente respondem com mensagem, sem travar", async () => {
    const quebrado = await request(app).post("/api/inscricoes").set("Content-Type", "application/json").send("{quebrado");
    expect(quebrado.status).toBe(400);
    expect((await request(app).get("/api/nao-existe")).status).toBe(404);
  });
});

describe("valor único e vagas", () => {
  it("todas as turmas têm a mesma taxa de R$ 25", async () => {
    const turmas = await request(app).get("/api/turmas?all=1");
    expect(new Set(turmas.body.map((t) => Number(t.taxa)))).toEqual(new Set([25]));
  });
});
