import { safeRouter } from "../middleware/safeRouter.js";
import bcrypt from "bcryptjs";
import { db } from "../db.js";
import { signToken, requireAdmin } from "../middleware/auth.js";
import { rateLimit } from "../middleware/rateLimit.js";

const router = safeRouter();

// Máximo de 10 tentativas de login a cada 15 minutos por endereço.
const limiteLogin = rateLimit({ janelaMs: 15 * 60 * 1000, maximo: 10, mensagem: "Muitas tentativas de login. Aguarde alguns minutos." });

router.post("/login", limiteLogin, async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== "string" || typeof password !== "string" || !username || !password) {
    return res.status(400).json({ erro: "Usuario e senha sao obrigatorios." });
  }
  const admin = await db.prepare("SELECT * FROM admins WHERE username = ?").get(username);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.status(401).json({ erro: "Usuario ou senha invalidos." });
  }
  const token = signToken(admin);
  res.json({ token, admin: { id: admin.id, username: admin.username, nome: admin.nome } });
});

// Renova o token enquanto o admin usa o sistema (evita cair no meio de uma partida).
router.post("/renovar", requireAdmin, async (req, res) => {
  const admin = await db.prepare("SELECT id, username, nome FROM admins WHERE id = ?").get(req.admin.id);
  if (!admin) return res.status(401).json({ erro: "Administrador nao encontrado." });
  res.json({ token: signToken(admin) });
});

router.get("/me", requireAdmin, (req, res) => {
  res.json({ admin: req.admin });
});

router.post("/trocar-senha", requireAdmin, async (req, res) => {
  const { senhaAtual, novaSenha } = req.body || {};
  if (!senhaAtual || !novaSenha || novaSenha.length < 6) {
    return res.status(400).json({ erro: "Senha atual e nova senha (min. 6 caracteres) sao obrigatorias." });
  }
  const admin = await db.prepare("SELECT * FROM admins WHERE id = ?").get(req.admin.id);
  if (!admin || !bcrypt.compareSync(senhaAtual, admin.password_hash)) {
    return res.status(401).json({ erro: "Senha atual incorreta." });
  }
  const hash = bcrypt.hashSync(novaSenha, 10);
  await db.prepare("UPDATE admins SET password_hash = ? WHERE id = ?").run(hash, admin.id);
  res.json({ ok: true });
});

export default router;
