import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";
import { hojeBrasilia } from "../config.js";

const router = safeRouter();

router.get("/", requireAdmin, async (req, res) => {
  const [inscricoes, totalInscritos, arrecadado, jogosHoje, jogosTotal, jogosFinalizados, turmasAtivas, esportesAtivos] = await Promise.all([
    db.prepare("SELECT status_pagamento AS status, COUNT(*) AS n FROM inscricoes GROUP BY status_pagamento").all(),
    db.prepare("SELECT COUNT(*) AS n FROM inscricoes WHERE status_pagamento != 'cancelado'").get(),
    db.prepare("SELECT COALESCE(SUM(valor),0) AS total FROM inscricoes WHERE status_pagamento = 'confirmado'").get(),
    db.prepare("SELECT COUNT(*) AS n FROM jogos WHERE data = ?").get(hojeBrasilia()),
    db.prepare("SELECT COUNT(*) AS n FROM jogos").get(),
    db.prepare("SELECT COUNT(*) AS n FROM jogos WHERE status = 'finalizado'").get(),
    db.prepare("SELECT COUNT(*) AS n FROM turmas WHERE ativo = 1").get(),
    db.prepare("SELECT COUNT(*) AS n FROM esportes WHERE ativo = 1").get(),
  ]);

  res.json({
    inscricoesPorStatus: inscricoes,
    totalInscritos: totalInscritos.n,
    arrecadado: arrecadado.total,
    jogosHoje: jogosHoje.n,
    jogosTotal: jogosTotal.n,
    jogosFinalizados: jogosFinalizados.n,
    turmasAtivas: turmasAtivas.n,
    esportesAtivos: esportesAtivos.n,
  });
});

export default router;
