import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let demo;
let token;
let statusOriginal;

beforeAll(async () => {
  demo = await db.prepare("SELECT * FROM inscricoes WHERE matricula = '90001'").get();
  const admin = await db.prepare("SELECT * FROM admins LIMIT 1").get();
  token = signToken(admin);
  statusOriginal = demo.status_pagamento;
});

afterAll(async () => {
  await db.prepare("UPDATE inscricoes SET status_pagamento = ?, confirmado_em = CASE WHEN ? = 'confirmado' THEN datetime('now') ELSE confirmado_em END WHERE id = ?").run(statusOriginal, statusOriginal, demo.id);
});

describe("fluxo de pagamento", () => {
  it("consulta uma inscrição DEMO pela API pública", async () => {
    const response = await request(app).get(`/api/inscricoes/status?matricula=${demo.matricula}`);
    expect(response.status).toBe(200);
    expect(response.body.status_pagamento).toBe(statusOriginal);
  });

  it("altera para pendente e cancelado com proteção administrativa", async () => {
    const pendente = await request(app).put(`/api/inscricoes/${demo.id}/pagamento`).set("Authorization", `Bearer ${token}`).send({ status: "pendente" });
    expect(pendente.status).toBe(200);
    expect(pendente.body.status_pagamento).toBe("pendente");

    const cancelado = await request(app).put(`/api/inscricoes/${demo.id}/pagamento`).set("Authorization", `Bearer ${token}`).send({ status: "cancelado" });
    expect(cancelado.status).toBe(200);
    expect(cancelado.body.status_pagamento).toBe("cancelado");
  });
});
