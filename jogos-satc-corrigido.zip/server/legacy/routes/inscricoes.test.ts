import { afterAll, describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";
import db from "../db.js";

const matriculas = ["80001", "80002", "80003", "80004", "80005", "80006"];
const turma6 = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
const turma7 = await db.prepare("SELECT id FROM turmas WHERE label = '7º Ano C'").get();
const atletismo = await db.prepare("SELECT id FROM esportes WHERE nome = 'Atletismo'").get();
const prova = await db.prepare("SELECT id FROM provas_atletismo WHERE categoria_id = 1 ORDER BY ordem, id LIMIT 1").get();

afterAll(async () => {
  await db.prepare(`DELETE FROM inscricoes WHERE matricula IN (${matriculas.map(() => "?").join(",")})`).run(...matriculas);
});

describe("POST /api/inscricoes", () => {
  it("rejeita matrícula que não tenha exatamente 5 números", async () => {
    for (const matricula of ["1234", "123456", "12a45", " 1234", "ABCDE"]) {
      const response = await request(app).post("/api/inscricoes").send({
        nome: "Aluno matrícula inválida", matricula, sexo: "masculino", turmaId: turma6.id,
        esportes: [atletismo.id], provasAtletismo: [prova.id],
      });
      expect(response.status).toBe(400);
    }
  });

  it("cobra sempre o valor único de R$ 25 e não aceita a mesma matrícula duas vezes", async () => {
    const dados = { nome: "Aluno valor único", matricula: "80005", sexo: "masculino", turmaId: turma7.id, esportes: [atletismo.id], provasAtletismo: [prova.id] };
    const primeira = await request(app).post("/api/inscricoes").send(dados);
    expect(primeira.status).toBe(201);
    expect(Number(primeira.body.valor)).toBe(25);
    const repetida = await request(app).post("/api/inscricoes").send(dados);
    expect(repetida.status).toBe(409);
  });

  it("com envios simultâneos da mesma matrícula, grava só uma inscrição", async () => {
    const dados = { nome: "Aluno corrida", matricula: "80006", sexo: "masculino", turmaId: turma6.id, esportes: [atletismo.id], provasAtletismo: [prova.id] };
    const respostas = await Promise.all(Array.from({ length: 5 }, () => request(app).post("/api/inscricoes").send(dados)));
    expect(respostas.filter((r) => r.status === 201)).toHaveLength(1);
    expect(respostas.filter((r) => r.status === 409)).toHaveLength(4);
  });

  it("aceita Atletismo com prova válida no 6º e 7º ano", async () => {
    for (const [matricula, turma, sexo] of [[matriculas[0], turma6, "masculino"], [matriculas[1], turma7, "feminino"]]) {
      const response = await request(app).post("/api/inscricoes").send({
        nome: `Aluno de teste ${matricula}`, matricula, sexo, turmaId: turma.id,
        esportes: [atletismo.id], provasAtletismo: [prova.id],
      });
      expect(response.status).toBe(201);
      expect(response.body.esportes.some((item) => item.nome === "Atletismo")).toBe(true);
    }
  });

  it("rejeita inscrição sem sexo", async () => {
    const response = await request(app).post("/api/inscricoes").send({
      nome: "Aluno sem sexo", matricula: "80004", turmaId: turma6.id,
      esportes: [atletismo.id], provasAtletismo: [prova.id],
    });
    expect(response.status).toBe(400);
  });

  it("rejeita Atletismo sem pelo menos uma prova", async () => {
    const response = await request(app).post("/api/inscricoes").send({
      nome: "Aluno inválido", matricula: matriculas[2], sexo: "masculino", turmaId: turma6.id,
      esportes: [atletismo.id], provasAtletismo: [],
    });
    expect(response.status).toBe(400);
  });
});
