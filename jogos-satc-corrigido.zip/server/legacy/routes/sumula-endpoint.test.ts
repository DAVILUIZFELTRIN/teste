import { afterAll, beforeAll, describe, expect, it } from "vitest";
import request from "supertest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let token;
let jogoColetivo;
let jogoIndividual;

async function criarJogo(nomeEsporte) {
  const esporte = await db.prepare("SELECT id FROM esportes WHERE nome = ?").get(nomeEsporte);
  const turmaA = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
  const turmaB = await db.prepare("SELECT id FROM turmas WHERE label = '7º Ano C'").get();
  await db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaA.id);
  await db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaB.id);
  const timeA = await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaA.id);
  const timeB = await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaB.id);
  return (await db.prepare(`INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status) VALUES (?, ?, ?, '2099-02-01', '11:00', 'Teste Vitest', 'Teste', 'agendado')`).run(esporte.id, timeA.id, timeB.id)).lastInsertRowid;
}

beforeAll(async () => {
  token = signToken(await db.prepare("SELECT * FROM admins LIMIT 1").get());
  jogoColetivo = await criarJogo("Futsal Masculino");
  jogoIndividual = await criarJogo("Xadrez Masculino");
});

afterAll(async () => {
  await db.prepare("DELETE FROM jogos WHERE id IN (?, ?)").run(jogoColetivo, jogoIndividual);
});

describe("endpoint de súmula por esporte", () => {
  it("rejeita súmula coletiva sem períodos e aceita Futsal completa", async () => {
    const invalida = await request(app).put(`/api/jogos/${jogoColetivo}/sumula`).set("Authorization", `Bearer ${token}`).send({
      placarA: 2, placarB: 1, detalhes: { participantesA: "Time A", participantesB: "Time B", ocorrencias: "Nenhuma" },
    });
    expect(invalida.status).toBe(400);
    expect(invalida.body.erro).toContain("periodos");

    const valida = await request(app).put(`/api/jogos/${jogoColetivo}/sumula`).set("Authorization", `Bearer ${token}`).send({
      placarA: 2, placarB: 1, arbitro: "Árbitro Futsal", detalhes: { participantesA: "Time A", participantesB: "Time B", periodos: "1º tempo 1–0; 2º tempo 1–1", substituicoes: "12 entra; 9 sai", cartoes: "Nenhum", goleadores: "Atleta 10 aos 12 min", ocorrencias: "Nenhuma" },
    });
    expect(valida.status).toBe(200);
    expect(valida.body.sumula.modelo.id).toBe("futsal");

    const lida = await request(app).get(`/api/jogos/${jogoColetivo}`).set("Authorization", `Bearer ${token}`);
    expect(lida.body.sumula.detalhes.periodos).toContain("1º tempo");
  });

  it("rejeita individual sem sets/resultado e aceita Xadrez completo", async () => {
    const invalida = await request(app).put(`/api/jogos/${jogoIndividual}/sumula`).set("Authorization", `Bearer ${token}`).send({
      placarA: 1, placarB: 0, detalhes: { participantesA: "Jogador A", participantesB: "Jogador B", ocorrencias: "Nenhuma" },
    });
    expect(invalida.status).toBe(400);
    expect(invalida.body.erro).toContain("rodadas");

    const valida = await request(app).put(`/api/jogos/${jogoIndividual}/sumula`).set("Authorization", `Bearer ${token}`).send({
      placarA: 1, placarB: 0, arbitro: "Árbitro Xadrez", detalhes: { participantesA: "Jogador A", participantesB: "Jogador B", rodadas: "Partida única", resultado: "Jogador A venceu", ocorrencias: "Nenhuma" },
    });
    expect(valida.status).toBe(200);
    expect(valida.body.sumula.tipo).toBe("individual");

    const lida = await request(app).get(`/api/jogos/${jogoIndividual}`).set("Authorization", `Bearer ${token}`);
    expect(lida.body.sumula.detalhes.resultado).toBe("Jogador A venceu");
  });
});
