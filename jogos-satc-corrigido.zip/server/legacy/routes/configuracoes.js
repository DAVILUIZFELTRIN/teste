import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";

const router = safeRouter();
const KEYS = ["inscricoes_abertas_em", "inscricoes_fecha_em", "inscricoes_bloqueadas"];

function statusOf(abre, fecha, bloqueada = false, now = Date.now()) {
  if (bloqueada) return "bloqueadas";
  if (abre && now < Date.parse(abre)) return "em_breve";
  if (fecha && now > Date.parse(fecha)) return "encerradas";
  return "abertas";
}

async function carregar() {
  const rows = await db.prepare(`SELECT chave, valor FROM configuracoes WHERE chave IN (${KEYS.map(() => "?").join(", ")})`).all(...KEYS);
  const values = Object.fromEntries(rows.map((row) => [row.chave, row.valor || ""]));
  return {
    inscricoesAbertasEm: values.inscricoes_abertas_em || null,
    inscricoesFechaEm: values.inscricoes_fecha_em || null,
    inscricoesBloqueadas: values.inscricoes_bloqueadas === "1",
    status: statusOf(values.inscricoes_abertas_em, values.inscricoes_fecha_em, values.inscricoes_bloqueadas === "1"),
  };
}

router.get("/", async (req, res) => res.json(await carregar()));

router.put("/", requireAdmin, async (req, res) => {
  const { inscricoesAbertasEm, inscricoesFechaEm, inscricoesBloqueadas = false } = req.body || {};
  // Valida ANTES de converter (converter data inválida gerava erro e derrubava o servidor).
  if (inscricoesAbertasEm && Number.isNaN(Date.parse(inscricoesAbertasEm))) return res.status(400).json({ erro: "Data de abertura inválida." });
  if (inscricoesFechaEm && Number.isNaN(Date.parse(inscricoesFechaEm))) return res.status(400).json({ erro: "Data de encerramento inválida." });
  const abre = inscricoesAbertasEm ? new Date(inscricoesAbertasEm).toISOString() : null;
  const fecha = inscricoesFechaEm ? new Date(inscricoesFechaEm).toISOString() : null;
  if (abre && fecha && Date.parse(abre) >= Date.parse(fecha)) return res.status(400).json({ erro: "A abertura deve acontecer antes do encerramento." });
  const now = new Date().toISOString();
  const sql = db.kind === "mysql"
    ? "INSERT INTO configuracoes (chave, valor, atualizado_em) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor), atualizado_em = VALUES(atualizado_em)"
    : "INSERT OR REPLACE INTO configuracoes (chave, valor, atualizado_em) VALUES (?, ?, ?)";
  await db.prepare(sql).run("inscricoes_abertas_em", abre, now);
  await db.prepare(sql).run("inscricoes_fecha_em", fecha, now);
  await db.prepare(sql).run("inscricoes_bloqueadas", inscricoesBloqueadas ? "1" : "0", now);
  res.json(await carregar());
});

export { carregar as carregarConfiguracoes, statusOf as statusInscricoes };
export default router;
