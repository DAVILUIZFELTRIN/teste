import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";

const router = safeRouter();

async function withSubcategorias(esporte, categoriaId = null, includeInactive = false) {
  const params = [esporte.id, esporte.nome];
  const filters = ["(p.esporte_id = ? OR (p.esporte_id IS NULL AND ? = 'Atletismo'))"];
  if (categoriaId) { filters.push("(p.categoria_id = ? OR p.categoria_id IS NULL)"); params.push(categoriaId); }
  if (!includeInactive) filters.push("p.ativo = 1");
  return db.prepare(`SELECT p.id, p.nome, p.ordem, p.ativo, p.categoria_id, p.esporte_id FROM provas_atletismo p WHERE ${filters.join(" AND ")} ORDER BY p.ordem, p.id`).all(...params);
}

async function withCategorias(esporte, categoriaId = null, includeInactive = false) {
  const categorias = await db
    .prepare(
      `SELECT c.id, c.nome FROM categoria_esportes ce
       JOIN categorias c ON c.id = ce.categoria_id
       WHERE ce.esporte_id = ? ORDER BY c.ordem`,
    )
    .all(esporte.id);
  return { ...esporte, ativo: !!esporte.ativo, categorias, subcategorias: await withSubcategorias(esporte, categoriaId, includeInactive), provas: await withSubcategorias(esporte, categoriaId, includeInactive) };
}

router.get("/", async (req, res) => {
  const { all, turmaId, categoriaId, sexo } = req.query;
  const sexoNormalizado = String(sexo || "").toLowerCase();
  let categoriaAlvo = categoriaId ? Number(categoriaId) : null;

  if (turmaId) {
    const turma = await db.prepare("SELECT categoria_id FROM turmas WHERE id = ?").get(turmaId);
    if (!turma) return res.status(404).json({ erro: "Turma nao encontrada." });
    categoriaAlvo = turma.categoria_id;
  }

  let rows;
  if (categoriaAlvo) {
    const params = [categoriaAlvo];
    const sexoClause = ["masculino", "feminino"].includes(sexoNormalizado)
      ? "AND (e.genero = ? OR e.genero = 'misto')"
      : "";
    if (sexoClause) params.push(sexoNormalizado);
    rows = await db
      .prepare(
        `SELECT e.* FROM esportes e
         JOIN categoria_esportes ce ON ce.esporte_id = e.id
         WHERE ce.categoria_id = ? ${all === "1" ? "" : "AND e.ativo = 1"}
           ${sexoClause}
         ORDER BY e.nome`,
      )
      .all(...params);
  } else {
    rows = all === "1"
      ? await db.prepare("SELECT * FROM esportes ORDER BY nome").all()
      : await db.prepare("SELECT * FROM esportes WHERE ativo = 1 ORDER BY nome").all();
  }

  const result = [];
  for (const esporte of rows) {
    result.push({
      ...(await withCategorias(esporte, categoriaAlvo, all === "1")),
    });
  }
  res.json(result);
});

router.post("/", requireAdmin, async (req, res) => {
  const { nome, icone, formato, descricao, genero, modalidade, categoriaIds } = req.body || {};
  if (!nome) return res.status(400).json({ erro: "nome e obrigatorio." });
  const info = await db
    .prepare("INSERT INTO esportes (nome, icone, formato, descricao, genero, modalidade, ativo) VALUES (?, ?, ?, ?, ?, ?, 1)")
    .run(nome, icone || "🏆", formato || "pontos_corridos", descricao || null, ["masculino", "feminino", "misto"].includes(genero) ? genero : "misto", ["individual", "dupla", "equipe"].includes(modalidade) ? modalidade : "equipe");
  const esporteId = info.lastInsertRowid;
  if (Array.isArray(categoriaIds)) {
    const insert = db.prepare("INSERT INTO categoria_esportes (categoria_id, esporte_id) VALUES (?, ?)");
    for (const cId of categoriaIds) await insert.run(cId, esporteId);
  }
  res.status(201).json(await withCategorias(await db.prepare("SELECT * FROM esportes WHERE id = ?").get(esporteId), null, true));
});

router.put("/:id", requireAdmin, async (req, res) => {
  const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(req.params.id);
  if (!esporte) return res.status(404).json({ erro: "Esporte nao encontrado." });
  const { nome, icone, formato, descricao, genero, modalidade, ativo, categoriaIds } = req.body || {};
  await db.prepare(
    "UPDATE esportes SET nome = ?, icone = ?, formato = ?, descricao = ?, genero = ?, modalidade = ?, ativo = ? WHERE id = ?",
  ).run(
    nome ?? esporte.nome,
    icone ?? esporte.icone,
    formato ?? esporte.formato,
    descricao === undefined ? esporte.descricao : descricao,
    ["masculino", "feminino", "misto"].includes(genero) ? genero : esporte.genero,
    ["individual", "dupla", "equipe"].includes(modalidade) ? modalidade : (esporte.modalidade || "equipe"),
    ativo === undefined ? esporte.ativo : ativo ? 1 : 0,
    esporte.id,
  );

  if (Array.isArray(categoriaIds)) {
    await db.prepare("DELETE FROM categoria_esportes WHERE esporte_id = ?").run(esporte.id);
    const insert = db.prepare("INSERT INTO categoria_esportes (categoria_id, esporte_id) VALUES (?, ?)");
    for (const cId of categoriaIds) await insert.run(cId, esporte.id);
  }

  res.json(await withCategorias(await db.prepare("SELECT * FROM esportes WHERE id = ?").get(esporte.id), null, true));
});

router.delete("/:id", requireAdmin, async (req, res) => {
  await db.prepare("DELETE FROM esportes WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

router.get("/:id/subcategorias", requireAdmin, async (req, res) => {
  const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(req.params.id);
  if (!esporte) return res.status(404).json({ erro: "Esporte nao encontrado." });
  res.json(await withSubcategorias(esporte, null, true));
});

router.post("/:id/subcategorias", requireAdmin, async (req, res) => {
  const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(req.params.id);
  if (!esporte) return res.status(404).json({ erro: "Esporte nao encontrado." });
  const { nome, ordem, categoriaIds } = req.body || {};
  if (!String(nome || "").trim()) return res.status(400).json({ erro: "nome da subcategoria e obrigatorio." });
  const categorias = Array.isArray(categoriaIds) && categoriaIds.length ? categoriaIds : [null];
  for (const categoriaId of categorias) {
    const exists = await db.prepare("SELECT id FROM provas_atletismo WHERE esporte_id = ? AND nome = ? AND ((categoria_id = ?) OR (categoria_id IS NULL AND ? IS NULL))").get(esporte.id, String(nome).trim(), categoriaId, categoriaId);
    if (!exists) await db.prepare("INSERT INTO provas_atletismo (esporte_id, categoria_id, nome, ordem, ativo) VALUES (?, ?, ?, ?, 1)").run(esporte.id, categoriaId || null, String(nome).trim(), Number(ordem) || 0);
  }
  res.status(201).json(await withSubcategorias(esporte, null, true));
});

router.put("/:id/subcategorias/:subcategoriaId", requireAdmin, async (req, res) => {
  const esporte = await db.prepare("SELECT * FROM esportes WHERE id = ?").get(req.params.id);
  const subcategoria = await db.prepare("SELECT * FROM provas_atletismo WHERE id = ? AND esporte_id = ?").get(req.params.subcategoriaId, req.params.id);
  if (!esporte || !subcategoria) return res.status(404).json({ erro: "Subcategoria nao encontrada." });
  const { nome, ordem, ativo, categoriaId } = req.body || {};
  await db.prepare("UPDATE provas_atletismo SET nome = ?, ordem = ?, ativo = ?, categoria_id = ? WHERE id = ? AND esporte_id = ?").run(String(nome ?? subcategoria.nome).trim(), ordem ?? subcategoria.ordem, ativo === undefined ? subcategoria.ativo : (ativo ? 1 : 0), categoriaId === undefined ? subcategoria.categoria_id : (categoriaId || null), subcategoria.id, esporte.id);
  res.json(await db.prepare("SELECT id, nome, ordem, ativo, categoria_id, esporte_id FROM provas_atletismo WHERE id = ?").get(subcategoria.id));
});

router.delete("/:id/subcategorias/:subcategoriaId", requireAdmin, async (req, res) => {
  const subcategoria = await db.prepare("SELECT * FROM provas_atletismo WHERE id = ? AND esporte_id = ?").get(req.params.subcategoriaId, req.params.id);
  if (!subcategoria) return res.status(404).json({ erro: "Subcategoria nao encontrada." });
  const usage = await db.prepare("SELECT COUNT(*) AS total FROM inscricao_provas_atletismo WHERE prova_id = ?").get(subcategoria.id);
  if (Number(usage.total) > 0) { await db.prepare("UPDATE provas_atletismo SET ativo = 0 WHERE id = ?").run(subcategoria.id); return res.json({ ok: true, desativada: true, mensagem: "Subcategoria usada em inscricoes; foi desativada para preservar o historico." }); }
  await db.prepare("DELETE FROM provas_atletismo WHERE id = ? AND esporte_id = ?").run(subcategoria.id, req.params.id);
  res.json({ ok: true, removida: true });
});

router.get("/:id/times", requireAdmin, async (req, res) => {
  const rows = await db
    .prepare(
      `SELECT t.id, tu.id AS turma_id, tu.label AS turma_label
       FROM times t JOIN turmas tu ON tu.id = t.turma_id
       WHERE t.esporte_id = ? ORDER BY tu.label`,
    )
    .all(req.params.id);
  res.json(rows);
});

export default router;
