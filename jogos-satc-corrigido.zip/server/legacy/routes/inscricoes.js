import { safeRouter } from "../middleware/safeRouter.js";
import crypto from "node:crypto";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";
import { carregarConfiguracoes } from "./configuracoes.js";
import { VALOR_INSCRICAO, MATRICULA_REGEX } from "../config.js";

const router = safeRouter();

// Código com 6 letras/números sem caracteres confusos (0/O, 1/I): praticamente sem repetição.
const ALFABETO_CODIGO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function gerarCodigo() {
  const ano = new Date().getFullYear();
  let sufixo = "";
  for (let i = 0; i < 6; i += 1) sufixo += ALFABETO_CODIGO[crypto.randomInt(ALFABETO_CODIGO.length)];
  return `SATC-${ano}-${sufixo}`;
}

class ErroNegocio extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function gerarReferenciaPix(codigo, valor) {
  const chavePix = process.env.PIX_KEY || "financeiro@satc.edu.br";
  return `Chave PIX da escola: ${chavePix} | Valor: R$ ${Number(valor).toFixed(2)} | Referencia: ${codigo}`;
}

async function withEsportes(inscricao) {
  const esportes = await db
    .prepare(
      `SELECT e.id, e.nome, e.icone FROM inscricao_esportes ie
       JOIN esportes e ON e.id = ie.esporte_id WHERE ie.inscricao_id = ?`,
    )
    .all(inscricao.id);
  const result = [];
  for (const esporte of esportes) {
    result.push({
      ...esporte,
      ...(esporte.nome === "Atletismo"
        ? {
            provas: await db
              .prepare(
                `SELECT p.id, p.nome, p.ordem FROM inscricao_provas_atletismo ipa
                 JOIN provas_atletismo p ON p.id = ipa.prova_id
                 WHERE ipa.inscricao_id = ? ORDER BY p.ordem, p.id`,
              )
              .all(inscricao.id),
          }
        : {}),
    });
  }
  const turma = await db.prepare("SELECT qr_code_url FROM turmas WHERE id = ?").get(inscricao.turma_id);
  const { matricula_ativa, ...publico } = inscricao; // campo interno, não exposto
  return { ...publico, qr_code_url: turma?.qr_code_url || null, esportes: result };
}

// INSERT IGNORE: se duas inscrições criarem o mesmo time ao mesmo tempo, a segunda apenas reaproveita
// (antes, o erro de duplicidade derrubava o servidor inteiro).
async function garantirTime(database, esporteId, turmaId) {
  await database.prepare("INSERT IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporteId, turmaId);
}

router.post("/", async (req, res) => {
  const { nome, matricula, sexo, turmaId, esportes, provasAtletismo } = req.body || {};
  const configuracoes = await carregarConfiguracoes();
  if (configuracoes.status !== "abertas") {
    const erro = configuracoes.status === "em_breve"
      ? "As inscrições ainda não foram abertas."
      : configuracoes.status === "bloqueadas"
        ? "As inscrições estão bloqueadas temporariamente pela organização."
        : "As inscrições já foram encerradas.";
    return res.status(403).json({ erro });
  }
  const sexoNormalizado = String(sexo || "").toLowerCase();
  const matriculaLimpa = String(matricula ?? "").trim();
  const nomeLimpo = String(nome ?? "").trim().replace(/\s+/g, " ");
  if (!nomeLimpo || !matriculaLimpa || !["masculino", "feminino"].includes(sexoNormalizado) || !turmaId || !Array.isArray(esportes) || esportes.length === 0) {
    return res.status(400).json({ erro: "nome, matricula, sexo, turmaId e ao menos 1 esporte sao obrigatorios. Sexo deve ser masculino ou feminino." });
  }
  if (!MATRICULA_REGEX.test(matriculaLimpa)) return res.status(400).json({ erro: "A matricula deve ter exatamente 5 numeros." });
  if (nomeLimpo.length > 255) return res.status(400).json({ erro: "Nome muito longo." });
  if (esportes.some((id) => !Number.isInteger(Number(id)) || Number(id) <= 0)) return res.status(400).json({ erro: "Esportes invalidos." });
  const turma = await db.prepare("SELECT * FROM turmas WHERE id = ? AND ativo = 1").get(turmaId);
  if (!turma) return res.status(400).json({ erro: "Turma invalida ou inativa." });

  const permitidos = await db
    .prepare(
      `SELECT ce.esporte_id FROM categoria_esportes ce
       JOIN esportes e ON e.id = ce.esporte_id
       WHERE ce.categoria_id = ?
         AND e.ativo = 1
         AND (e.genero = ? OR e.genero = 'misto')`,
    )
    .all(turma.categoria_id, sexoNormalizado);
  const esportesPermitidos = new Set(permitidos.map((r) => Number(r.esporte_id)));
  const esporteInvalido = esportes.some((id) => !esportesPermitidos.has(Number(id)));
  if (esporteInvalido) {
    return res.status(400).json({ erro: "Um ou mais esportes selecionados nao estao disponiveis para esta turma e sexo." });
  }

  const atletismo = await db.prepare("SELECT id FROM esportes WHERE nome = 'Atletismo'").get();
  const atletismoSelecionado = atletismo && esportes.some((id) => Number(id) === Number(atletismo.id));
  const provasSelecionadas = Array.isArray(provasAtletismo) ? [...new Set(provasAtletismo.map(Number))] : [];
  if (atletismoSelecionado) {
    const provasPermitidas = new Set(
      (await db.prepare("SELECT id FROM provas_atletismo WHERE (categoria_id = ? OR categoria_id IS NULL) AND ativo = 1").all(turma.categoria_id)).map((p) => Number(p.id)),
    );
    if (provasSelecionadas.length === 0 || provasSelecionadas.some((id) => !provasPermitidas.has(id))) {
      return res.status(400).json({ erro: "Selecione ao menos uma prova valida de Atletismo para competir nessa modalidade." });
    }
  }

  const criadoEm = new Date().toISOString();
  const esportesIds = [...new Set(esportes.map(Number))];
  const pagamentoSql = db.kind === "mysql"
    ? `INSERT INTO pagamentos (inscricao_id, status, valor, pix_code, criado_em, atualizado_em)
       VALUES (?, 'pendente', ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE valor = VALUES(valor), pix_code = VALUES(pix_code), atualizado_em = VALUES(atualizado_em)`
    : `INSERT OR REPLACE INTO pagamentos (inscricao_id, status, valor, pix_code, criado_em, atualizado_em)
       VALUES (?, 'pendente', ?, ?, ?, ?)`;

  let inscricaoId;
  // Repete o sorteio do código no raro caso de repetição.
  for (let tentativa = 0; tentativa < 5; tentativa += 1) {
    const codigo = gerarCodigo();
    const pixCode = gerarReferenciaPix(codigo, VALOR_INSCRICAO);
    try {
      inscricaoId = await db.transaction(async (database) => {
        // Trava a linha da turma: inscrições simultâneas na última vaga são processadas uma de cada vez.
        await database.prepare("SELECT id FROM turmas WHERE id = ? FOR UPDATE").get(turma.id);

        const jaInscrito = await database
          .prepare("SELECT id FROM inscricoes WHERE matricula = ? AND status_pagamento != 'cancelado'")
          .get(matriculaLimpa);
        if (jaInscrito) throw new ErroNegocio(409, "Ja existe uma inscricao ativa para esta matricula.");

        const vagasOcupadas = await database
          .prepare("SELECT COUNT(*) AS n FROM inscricoes WHERE turma_id = ? AND status_pagamento != 'cancelado'")
          .get(turma.id);
        if (Number(vagasOcupadas.n) >= Number(turma.vagas)) throw new ErroNegocio(409, "Nao ha mais vagas para esta turma.");

        const info = await database
          .prepare(
            `INSERT INTO inscricoes (codigo, nome, matricula, matricula_ativa, sexo, turma_id, status_pagamento, valor, pix_code, criado_em)
             VALUES (?, ?, ?, ?, ?, ?, 'pendente', ?, ?, ?)`,
          )
          .run(codigo, nomeLimpo, matriculaLimpa, matriculaLimpa, sexoNormalizado, turma.id, VALOR_INSCRICAO, pixCode, criadoEm);
        const id = info.lastInsertRowid;
        const insertEsporte = database.prepare("INSERT INTO inscricao_esportes (inscricao_id, esporte_id) VALUES (?, ?)");
        for (const esporteId of esportesIds) {
          await insertEsporte.run(id, esporteId);
          await garantirTime(database, esporteId, turma.id);
        }
        if (atletismoSelecionado) {
          const insertProva = database.prepare("INSERT INTO inscricao_provas_atletismo (inscricao_id, prova_id) VALUES (?, ?)");
          for (const provaId of provasSelecionadas) await insertProva.run(id, provaId);
        }
        await database.prepare(pagamentoSql).run(id, VALOR_INSCRICAO, pixCode, criadoEm, criadoEm);
        return id;
      });
      break;
    } catch (erro) {
      if (erro instanceof ErroNegocio) return res.status(erro.status).json({ erro: erro.message });
      if (erro?.code === "ER_DUP_ENTRY") {
        if (/matricula_ativa/.test(String(erro.message))) return res.status(409).json({ erro: "Ja existe uma inscricao ativa para esta matricula." });
        continue; // código repetido: sorteia outro
      }
      throw erro;
    }
  }
  if (!inscricaoId) return res.status(500).json({ erro: "Nao foi possivel gerar a inscricao. Tente novamente." });

  const inscricao = await db.prepare("SELECT * FROM inscricoes WHERE id = ?").get(inscricaoId);
  res.status(201).json(await withEsportes(inscricao));
});

router.get("/status", async (req, res) => {
  const { codigo, matricula, nome } = req.query;
  if (!codigo && !matricula && !nome) return res.status(400).json({ erro: "Informe codigo, matricula ou nome para consultar." });
  if (nome && !codigo && !matricula) {
    const termo = String(nome).trim();
    if (termo.length < 3) return res.status(400).json({ erro: "Informe pelo menos 3 letras do nome." });
    // Escapa % e _ para que o visitante não use curingas e liste todos os alunos.
    const termoSeguro = termo.replace(/[|%_]/g, (c) => `|${c}`);
    if (termoSeguro.replace(/\|./g, "").trim().length < 3) return res.status(400).json({ erro: "Informe pelo menos 3 letras do nome." });
    const rows = await db.prepare(`SELECT i.id, i.nome, i.status_pagamento, t.label AS turma_label
      FROM inscricoes i JOIN turmas t ON t.id = i.turma_id
      WHERE LOWER(i.nome) LIKE LOWER(?) ESCAPE '|' AND i.status_pagamento != 'cancelado'
      ORDER BY LOWER(i.nome), i.id DESC LIMIT 30`).all(`%${termoSeguro}%`);
    const resultados = await Promise.all(rows.map(async (row) => {
      const esportes = await db.prepare(`SELECT e.nome FROM inscricao_esportes ie JOIN esportes e ON e.id = ie.esporte_id WHERE ie.inscricao_id = ? ORDER BY e.nome`).all(row.id);
      return { nome: row.nome, turma: row.turma_label, esportes: esportes.map((item) => item.nome), status_pagamento: row.status_pagamento };
    }));
    return res.json({ resultados });
  }
  const inscricao = codigo
    ? await db.prepare("SELECT * FROM inscricoes WHERE codigo = ?").get(String(codigo).trim().toUpperCase())
    : await db.prepare("SELECT * FROM inscricoes WHERE matricula = ? ORDER BY id DESC").get(String(matricula).trim());
  if (!inscricao) return res.status(404).json({ erro: "Inscricao nao encontrada." });
  const completa = await withEsportes(inscricao);
  // Consulta só por matrícula não revela sexo nem a referência de pagamento (matrículas são fáceis de adivinhar).
  if (!codigo) {
    const { sexo, pix_code, ...reduzida } = completa;
    return res.json(reduzida);
  }
  res.json(completa);
});

router.get("/", requireAdmin, async (req, res) => {
  const { status } = req.query;
  const rows = status
    ? await db.prepare("SELECT * FROM inscricoes WHERE status_pagamento = ? ORDER BY id DESC").all(status)
    : await db.prepare("SELECT * FROM inscricoes ORDER BY id DESC").all();
  res.json(await Promise.all(rows.map(withEsportes)));
});

router.put("/:id/pagamento", requireAdmin, async (req, res) => {
  const { status } = req.body || {};
  if (!["pendente", "confirmado", "cancelado"].includes(status)) return res.status(400).json({ erro: "status invalido." });
  const inscricao = await db.prepare("SELECT * FROM inscricoes WHERE id = ?").get(req.params.id);
  if (!inscricao) return res.status(404).json({ erro: "Inscricao nao encontrada." });
  const atualizadoEm = new Date().toISOString();
  if (status !== "cancelado" && inscricao.status_pagamento === "cancelado") {
    // Reativar só é possível se a matrícula não foi usada em outra inscrição ativa.
    const conflito = await db
      .prepare("SELECT id FROM inscricoes WHERE matricula = ? AND status_pagamento != 'cancelado' AND id != ?")
      .get(inscricao.matricula, inscricao.id);
    if (conflito) return res.status(409).json({ erro: "Esta matricula ja possui outra inscricao ativa." });
  }
  await db.prepare("UPDATE inscricoes SET matricula_ativa = ? WHERE id = ?").run(status === "cancelado" ? null : inscricao.matricula, inscricao.id);
  await db.prepare(
    "UPDATE inscricoes SET status_pagamento = ?, confirmado_em = CASE WHEN ? = 'confirmado' THEN ? ELSE confirmado_em END WHERE id = ?",
  ).run(status, status, atualizadoEm, inscricao.id);
  await db.prepare(
    "UPDATE pagamentos SET status = ?, confirmado_em = CASE WHEN ? = 'confirmado' THEN ? ELSE confirmado_em END, atualizado_em = ? WHERE inscricao_id = ?",
  ).run(status, status, atualizadoEm, atualizadoEm, inscricao.id);
  res.json(await withEsportes(await db.prepare("SELECT * FROM inscricoes WHERE id = ?").get(inscricao.id)));
});

export default router;
