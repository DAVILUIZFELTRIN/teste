import { describe, expect, it } from "vitest";
import { modeloSumula, validarDetalhesSumula } from "./jogos.js";

describe("modelos específicos de súmula", () => {
  it("classifica Futebol como modelo coletivo com períodos obrigatórios", () => {
    const modelo = modeloSumula("Futebol de Campo Masculino");
    expect(modelo.tipo).toBe("coletiva");
    expect(modelo.campos).toContain("periodos");
    expect(validarDetalhesSumula(modelo.tipo, { participantesA: "A", participantesB: "B" }, true)).toContain("periodos");
  });

  it("classifica Voleibol como coletivo com sets e substituições", () => {
    const modelo = modeloSumula("Voleibol Misto");
    expect(modelo.tipo).toBe("coletiva");
    expect(modelo.campos).toEqual(expect.arrayContaining(["sets", "substituicoes"]));
  });

  it("classifica Tênis de Mesa como individual com sets e resultado", () => {
    const modelo = modeloSumula("Tênis de Mesa Feminino");
    expect(modelo.tipo).toBe("individual");
    expect(validarDetalhesSumula(modelo.tipo, { participantesA: "A", participantesB: "B", sets: "3-1" }, true)).toContain("resultado");
    expect(validarDetalhesSumula(modelo.tipo, { participantesA: "A", participantesB: "B", sets: "3-1", resultado: "A venceu", ocorrencias: "Nenhuma" }, true)).toBeNull();
  });
});
