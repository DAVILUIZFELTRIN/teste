import request from "supertest";
import { describe, expect, it, beforeAll } from "vitest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let token;

describe("GET /api/turmas/:id/alunos", () => {
  beforeAll(async () => {
    token = signToken(await db.prepare("SELECT * FROM admins LIMIT 1").get());
  });

  it("retorna alunos alfabeticamente com esporte, pagamento e provas de Atletismo", async () => {
    const turma = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
    const resposta = await request(app)
      .get(`/api/turmas/${turma.id}/alunos`)
      .set("Authorization", `Bearer ${token}`);

    expect(resposta.status).toBe(200);
    expect(resposta.body.turma.categoria.nome).toBe("6º e 7º Ano");
    expect(resposta.body.alunos.length).toBeGreaterThan(0);

    const nomes = resposta.body.alunos.map((aluno) => aluno.nome);
    expect(nomes).toEqual([...nomes].sort((a, b) => a.localeCompare(b, "pt-BR")));

    const primeiro = resposta.body.alunos[0];
    expect(primeiro).toEqual(expect.objectContaining({ matricula: expect.any(String), sexo: expect.stringMatching(/masculino|feminino/), status_pagamento: expect.any(String), esportes: expect.any(Array) }));
    const atleta = resposta.body.alunos.find((aluno) => aluno.esportes.includes("Atletismo"));
    expect(atleta?.provasAtletismo?.length).toBeGreaterThan(0);
  });

  it("exige autenticação administrativa", async () => {
    const turma = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
    const resposta = await request(app).get(`/api/turmas/${turma.id}/alunos`);
    expect(resposta.status).toBe(401);
  });
});
