import { safeRouter } from "../middleware/safeRouter.js";
import { db } from "../db.js";
import { requireAdmin } from "../middleware/auth.js";
import { tabelaEquipes } from "./classificacao.js";

const router = safeRouter();

// A súmula grava eventos como "GOLS · Nome", "AMARELOS · Nome", "VERMELHOS · Nome", "AZUIS · Nome".
// Lê só o prefixo (e não qualquer texto com "gol" no nome do aluno).
const TIPOS = [
  { chave: "gol", prefixo: /^(GOLS?|PONTOS?)$/i },
  { chave: "amarelo", prefixo: /^(AMARELOS?|CART[ÃA]O AMARELO)$/i },
  { chave: "azul", prefixo: /^(AZUIS|AZUL|CART[ÃA]O AZUL)$/i },
  { chave: "vermelho", prefixo: /^(VERMELHOS?|CART[ÃA]O VERMELHO)$/i },
];

function lerEvento(evento) {
  const texto = String(typeof evento === "string" ? evento : evento?.text || "").trim();
  const partes = texto.split("·");
  if (partes.length < 2) return null;
  const prefixo = partes[0].trim();
  const nome = partes.slice(1).join("·").trim();
  const tipo = TIPOS.find((t) => t.prefixo.test(prefixo));
  return tipo && nome ? { tipo: tipo.chave, nome } : null;
}

const dinheiro = (v) => Number(Number(v || 0).toFixed(2));

router.get("/", requireAdmin, async (req, res) => {
  const [status, esportes, jogos, turmas, valores] = await Promise.all([
    db.prepare("SELECT status_pagamento AS status, COUNT(*) AS total FROM inscricoes GROUP BY status_pagamento ORDER BY status_pagamento").all(),
    db.prepare(
      `SELECT e.id, e.nome, e.modalidade, COUNT(i.id) AS inscritos FROM esportes e
       LEFT JOIN inscricao_esportes ie ON ie.esporte_id = e.id
       LEFT JOIN inscricoes i ON i.id = ie.inscricao_id AND i.status_pagamento != 'cancelado'
       WHERE e.ativo = 1 GROUP BY e.id, e.nome, e.modalidade ORDER BY inscritos DESC, e.nome`,
    ).all(),
    db.prepare("SELECT status, COUNT(*) AS total FROM jogos GROUP BY status ORDER BY status").all(),
    db.prepare(
      `SELECT t.label, t.vagas, COUNT(i.id) AS inscritos FROM turmas t
       LEFT JOIN inscricoes i ON i.turma_id = t.id AND i.status_pagamento != 'cancelado'
       WHERE t.ativo = 1 GROUP BY t.id, t.label, t.vagas ORDER BY t.label`,
    ).all(),
    db.prepare("SELECT status_pagamento AS status, COUNT(*) AS total, COALESCE(SUM(valor), 0) AS soma FROM inscricoes GROUP BY status_pagamento").all(),
  ]);

  // Artilharia e cartões, a partir dos eventos das súmulas finalizadas.
  const finalizados = await db
    .prepare("SELECT j.sumula_dados, e.nome AS esporte FROM jogos j JOIN esportes e ON e.id = j.esporte_id WHERE j.status = 'finalizado' AND j.sumula_dados IS NOT NULL")
    .all();
  const gols = new Map();
  const cartoes = new Map();
  for (const jogo of finalizados) {
    let dados = {};
    try { dados = JSON.parse(jogo.sumula_dados || "{}"); } catch { continue; }
    for (const evento of Array.isArray(dados.eventos) ? dados.eventos : []) {
      const lido = lerEvento(evento);
      if (!lido) continue;
      if (lido.tipo === "gol") {
        const chave = `${jogo.esporte}|${lido.nome}`;
        gols.set(chave, (gols.get(chave) || 0) + 1);
      } else {
        const atual = cartoes.get(lido.nome) || { amarelo: 0, azul: 0, vermelho: 0 };
        atual[lido.tipo] += 1;
        cartoes.set(lido.nome, atual);
      }
    }
  }
  const artilharia = [...gols.entries()]
    .map(([chave, total]) => { const [esporte, nome] = chave.split("|"); return { nome, esporte, total }; })
    .sort((a, b) => b.total - a.total || a.nome.localeCompare(b.nome))
    .slice(0, 30);
  const listaCartoes = [...cartoes.entries()]
    .map(([nome, c]) => ({
      nome, ...c, total: c.amarelo + c.azul + c.vermelho,
      detalhe: [c.amarelo && `${c.amarelo} amarelo(s)`, c.azul && `${c.azul} azul(is)`, c.vermelho && `${c.vermelho} vermelho(s)`].filter(Boolean).join(", "),
    }))
    .sort((a, b) => b.vermelho - a.vermelho || b.total - a.total || a.nome.localeCompare(b.nome))
    .slice(0, 30);

  // Campeões: líder da classificação de cada esporte de equipe. "definitivo" só quando todos os jogos acabaram.
  const campeoes = [];
  for (const esporte of esportes) {
    if (esporte.modalidade === "individual" || /atletismo|xadrez/i.test(esporte.nome)) continue;
    const total = await db.prepare("SELECT COUNT(*) AS n, SUM(CASE WHEN status = 'finalizado' THEN 1 ELSE 0 END) AS fim FROM jogos WHERE esporte_id = ?").get(esporte.id);
    if (!Number(total.n)) continue;
    const tabela = await tabelaEquipes(esporte.id);
    const lider = tabela.find((linha) => linha.jogos > 0);
    if (!lider) continue;
    campeoes.push({
      esporte: esporte.nome,
      turma: lider.turma,
      pontos: lider.pontos,
      jogosRestantes: Number(total.n) - Number(total.fim || 0),
      definitivo: Number(total.n) === Number(total.fim || 0),
      podio: tabela.filter((l) => l.jogos > 0).slice(0, 3).map((l) => ({ turma: l.turma, pontos: l.pontos })),
    });
  }

  const porStatus = Object.fromEntries(valores.map((v) => [v.status, v]));
  const arrecadacao = {
    confirmado: dinheiro(porStatus.confirmado?.soma),
    pendente: dinheiro(porStatus.pendente?.soma),
    inscricoesConfirmadas: Number(porStatus.confirmado?.total || 0),
    inscricoesPendentes: Number(porStatus.pendente?.total || 0),
  };

  const totalInscritos = status.reduce((sum, row) => sum + Number(row.total), 0);
  res.json({ geradoEm: new Date().toISOString(), totalInscritos, status, esportes, jogos, turmas, artilharia, cartoes: listaCartoes, campeoes, arrecadacao });
});

export default router;
