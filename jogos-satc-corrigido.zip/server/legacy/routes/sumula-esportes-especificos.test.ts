import request from "supertest";
import { beforeAll, afterAll, describe, expect, it } from "vitest";
import { app } from "../server.js";
import db from "../db.js";
import { signToken } from "../middleware/auth.js";

let token;
const jogos = [];

async function criarJogo(nomeEsporte) {
  const esporte = await db.prepare("SELECT id FROM esportes WHERE nome = ?").get(nomeEsporte);
  const turmaA = await db.prepare("SELECT id FROM turmas WHERE label = '6º Ano A'").get();
  const turmaB = await db.prepare("SELECT id FROM turmas WHERE label = '7º Ano C'").get();
  if (!esporte || !turmaA || !turmaB) throw new Error(`Dados de teste ausentes para ${nomeEsporte}`);
  await db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaA.id);
  await db.prepare("INSERT OR IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(esporte.id, turmaB.id);
  const timeA = await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaA.id);
  const timeB = await db.prepare("SELECT id FROM times WHERE esporte_id = ? AND turma_id = ?").get(esporte.id, turmaB.id);
  const id = (await db.prepare("INSERT INTO jogos (esporte_id, time_a_id, time_b_id, data, hora, local, fase, status) VALUES (?, ?, ?, '2099-03-01', '10:00', 'Teste modelos específicos', 'Teste', 'agendado')").run(esporte.id, timeA.id, timeB.id)).lastInsertRowid;
  jogos.push(id);
  return id;
}

describe("modelos específicos de súmula", () => {
  beforeAll(async () => {
    token = signToken(await db.prepare("SELECT * FROM admins LIMIT 1").get());
  });

  afterAll(async () => {
    if (jogos.length) await db.prepare(`DELETE FROM jogos WHERE id IN (${jogos.map(() => "?").join(",")})`).run(...jogos);
  });

  it("grava Futebol com períodos, cartões e goleadores", async () => {
    const jogo = await criarJogo("Futebol de Campo Masculino");
    const base = { participantesA: "Escalação A", participantesB: "Escalação B", periodos: "1º tempo 1–0; 2º tempo 2–1", substituicoes: "A12 por A8", cartoes: "Amarelo A5", goleadores: "A10 aos 18 min", ocorrencias: "Nenhuma" };
    const invalida = await request(app).put(`/api/jogos/${jogo}/sumula`).set("Authorization", `Bearer ${token}`).send({ placarA: 2, placarB: 1, detalhes: { ...base, goleadores: "" } });
    expect(invalida.status).toBe(400);
    expect(invalida.body.erro).toContain("goleadores");

    const valida = await request(app).put(`/api/jogos/${jogo}/sumula`).set("Authorization", `Bearer ${token}`).send({ placarA: 2, placarB: 1, arbitro: "Árbitro Futebol", detalhes: base });
    expect(valida.status).toBe(200);
    expect(valida.body.sumula.modelo.id).toBe("futebol");
    expect(valida.body.sumula.modelo.titulo).toContain("Futebol");
    const lida = await request(app).get(`/api/jogos/${jogo}`).set("Authorization", `Bearer ${token}`);
    expect(lida.body.sumula.detalhes.cartoes).toContain("Amarelo");
  });

  it("grava Queimada com rodadas e eliminações", async () => {
    const jogo = await criarJogo("Queimada Mista");
    const base = { participantesA: "Equipe A", participantesB: "Equipe B", rodadas: "Rodada única", eliminacoes: "A3, A7 e B2", ocorrencias: "Nenhuma" };
    const invalida = await request(app).put(`/api/jogos/${jogo}/sumula`).set("Authorization", `Bearer ${token}`).send({ placarA: 5, placarB: 3, detalhes: { ...base, eliminacoes: "" } });
    expect(invalida.status).toBe(400);
    expect(invalida.body.erro).toContain("eliminacoes");

    const valida = await request(app).put(`/api/jogos/${jogo}/sumula`).set("Authorization", `Bearer ${token}`).send({ placarA: 5, placarB: 3, arbitro: "Árbitro Queimada", detalhes: base });
    expect(valida.status).toBe(200);
    expect(valida.body.sumula.modelo.id).toBe("queimada");
    expect(valida.body.sumula.modelo.titulo).toBe("Queimada");
    const lida = await request(app).get(`/api/jogos/${jogo}`).set("Authorization", `Bearer ${token}`);
    expect(lida.body.sumula.detalhes.rodadas).toContain("única");
  });
});
