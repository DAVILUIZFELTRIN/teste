import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";

import authRoutes from "./routes/auth.js";
import categoriasRoutes from "./routes/categorias.js";
import turmasRoutes from "./routes/turmas.js";
import esportesRoutes from "./routes/esportes.js";
import inscricoesRoutes from "./routes/inscricoes.js";
import jogosRoutes from "./routes/jogos.js";
import classificacaoRoutes from "./routes/classificacao.js";
import dashboardRoutes from "./routes/dashboard.js";
import configuracoesRoutes from "./routes/configuracoes.js";
import relatorioRoutes from "./routes/relatorio.js";
import { registerStorageProxy } from "../_core/storageProxy.ts";
import { runSeed } from "./seed.js";

// Garante admin, categorias, turmas, esportes e provas (só cria o que ainda não existe).
await runSeed();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const app = express();

// Atrás de proxy (hospedagem), usa o IP real do visitante no limitador de login.
app.set("trust proxy", 1);
app.disable("x-powered-by");

// Cabeçalhos de segurança básicos.
app.use((req, res, next) => {
  res.set({
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "strict-origin-when-cross-origin",
  });
  next();
});

// CORS: em produção o site e a API ficam no mesmo endereço, então não é necessário.
// Se o frontend ficar em outro domínio, defina CORS_ORIGIN (vários separados por vírgula).
const origens = (process.env.CORS_ORIGIN || "").split(",").map((o) => o.trim()).filter(Boolean);
if (origens.length) app.use(cors({ origin: origens }));
else if (process.env.NODE_ENV !== "production") app.use(cors());

// 8 MB: necessário para enviar a imagem do QR Code de pagamento das turmas.
app.use(express.json({ limit: "8mb" }));

app.use("/api/auth", authRoutes);
app.use("/api/categorias", categoriasRoutes);
app.use("/api/turmas", turmasRoutes);
app.use("/api/esportes", esportesRoutes);
app.use("/api/inscricoes", inscricoesRoutes);
app.use("/api/jogos", jogosRoutes);
app.use("/api/classificacao", classificacaoRoutes);
app.use("/api/admin/dashboard", dashboardRoutes);
app.use("/api/configuracoes", configuracoesRoutes);
app.use("/api/admin/relatorio", relatorioRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true }));
registerStorageProxy(app);

app.use("/api", (req, res) => res.status(404).json({ erro: "Rota nao encontrada." }));

// Em producao: serve o build do frontend pelo mesmo servidor,
// assim a hospedagem so precisa rodar um processo Node.
const frontendDist = path.join(process.cwd(), "dist", "public");
app.use(express.static(frontendDist));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(frontendDist, "index.html"), (err) => {
    if (err) next();
  });
});

// Tratamento central de erros: nunca deixa a requisição pendurada nem derruba o servidor.
app.use((erro, req, res, next) => {
  if (res.headersSent) return next(erro);
  if (erro?.type === "entity.parse.failed") return res.status(400).json({ erro: "JSON invalido." });
  if (erro?.type === "entity.too.large") return res.status(413).json({ erro: "Requisicao grande demais." });
  if (erro?.status && erro.status < 500) return res.status(erro.status).json({ erro: erro.message });
  console.error(`[erro] ${req.method} ${req.originalUrl}:`, erro);
  res.status(500).json({ erro: "Erro interno do servidor. Tente novamente em instantes." });
});

process.on("unhandledRejection", (motivo) => console.error("[unhandledRejection]", motivo));

if (process.env.NODE_ENV !== "test" && !process.env.VITEST) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
  });
}
