import "dotenv/config";
import { runSeed } from "./seed.js";
import { db } from "./db.js";

// Uso manual: pnpm seed   (SEED_DEMO=1 pnpm seed  para incluir alunos de demonstracao)
await runSeed();
await db.close();
