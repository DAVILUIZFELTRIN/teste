import "dotenv/config";
import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  throw new Error("DATABASE_URL e obrigatorio para executar o Jogos SATC.");
}

const schemaStatements = [
  `CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    nome VARCHAR(255) NOT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    ordem INT NOT NULL DEFAULT 0
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS configuracoes (
    chave VARCHAR(120) PRIMARY KEY,
    valor TEXT NULL,
    atualizado_em VARCHAR(40) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    label VARCHAR(120) NOT NULL,
    categoria_id INT NOT NULL,
    taxa DECIMAL(10,2) NOT NULL DEFAULT 0,
    vagas INT NOT NULL DEFAULT 40,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    qr_code_url TEXT NULL,
    CONSTRAINT fk_turmas_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS esportes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    icone VARCHAR(32) NOT NULL DEFAULT '🏆',
    formato VARCHAR(80) NOT NULL DEFAULT 'pontos_corridos',
    descricao TEXT,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    genero VARCHAR(20) NOT NULL DEFAULT 'misto',
    modalidade VARCHAR(20) NOT NULL DEFAULT 'equipe'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS categoria_esportes (
    categoria_id INT NOT NULL,
    esporte_id INT NOT NULL,
    PRIMARY KEY (categoria_id, esporte_id),
    CONSTRAINT fk_categoria_esportes_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE,
    CONSTRAINT fk_categoria_esportes_esporte FOREIGN KEY (esporte_id) REFERENCES esportes(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS inscricoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(120) NOT NULL UNIQUE,
    nome VARCHAR(255) NOT NULL,
    matricula VARCHAR(120) NOT NULL,
    turma_id INT NOT NULL,
    status_pagamento VARCHAR(30) NOT NULL DEFAULT 'pendente',
    valor DECIMAL(10,2) NOT NULL,
    pix_code TEXT NOT NULL,
    criado_em VARCHAR(40) NOT NULL DEFAULT '',
    confirmado_em VARCHAR(40),
    sexo VARCHAR(20),
    CONSTRAINT fk_inscricoes_turma FOREIGN KEY (turma_id) REFERENCES turmas(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS inscricao_esportes (
    inscricao_id INT NOT NULL,
    esporte_id INT NOT NULL,
    PRIMARY KEY (inscricao_id, esporte_id),
    CONSTRAINT fk_inscricao_esportes_inscricao FOREIGN KEY (inscricao_id) REFERENCES inscricoes(id) ON DELETE CASCADE,
    CONSTRAINT fk_inscricao_esportes_esporte FOREIGN KEY (esporte_id) REFERENCES esportes(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS provas_atletismo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT NOT NULL,
    nome VARCHAR(255) NOT NULL,
    ordem INT NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    UNIQUE KEY uq_provas_categoria_nome (categoria_id, nome),
    CONSTRAINT fk_provas_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS inscricao_provas_atletismo (
    inscricao_id INT NOT NULL,
    prova_id INT NOT NULL,
    PRIMARY KEY (inscricao_id, prova_id),
    CONSTRAINT fk_inscricao_provas_inscricao FOREIGN KEY (inscricao_id) REFERENCES inscricoes(id) ON DELETE CASCADE,
    CONSTRAINT fk_inscricao_provas_prova FOREIGN KEY (prova_id) REFERENCES provas_atletismo(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS times (
    id INT AUTO_INCREMENT PRIMARY KEY,
    esporte_id INT NOT NULL,
    turma_id INT NOT NULL,
    UNIQUE KEY uq_times_esporte_turma (esporte_id, turma_id),
    CONSTRAINT fk_times_esporte FOREIGN KEY (esporte_id) REFERENCES esportes(id),
    CONSTRAINT fk_times_turma FOREIGN KEY (turma_id) REFERENCES turmas(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS jogos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    esporte_id INT NOT NULL,
    time_a_id INT NOT NULL,
    time_b_id INT NOT NULL,
    data VARCHAR(20) NOT NULL,
    hora VARCHAR(20) NOT NULL,
    local VARCHAR(255) NOT NULL,
    fase VARCHAR(120) NOT NULL DEFAULT 'Fase de Grupos',
    status VARCHAR(30) NOT NULL DEFAULT 'agendado',
    placar_a INT,
    placar_b INT,
    sumula_observacoes TEXT,
    sumula_arbitro VARCHAR(255),
    sumula_registrado_por VARCHAR(255),
    sumula_registrado_em VARCHAR(40),
    sumula_dados TEXT,
    CONSTRAINT fk_jogos_esporte FOREIGN KEY (esporte_id) REFERENCES esportes(id),
    CONSTRAINT fk_jogos_time_a FOREIGN KEY (time_a_id) REFERENCES times(id),
    CONSTRAINT fk_jogos_time_b FOREIGN KEY (time_b_id) REFERENCES times(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS auditoria_jogos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jogo_id INT NOT NULL,
    acao VARCHAR(40) NOT NULL,
    motivo TEXT,
    realizado_por VARCHAR(255),
    realizado_em VARCHAR(40) NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS pagamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inscricao_id INT NOT NULL UNIQUE,
    status VARCHAR(30) NOT NULL DEFAULT 'pendente',
    valor DECIMAL(10,2) NOT NULL,
    pix_code TEXT NOT NULL,
    criado_em VARCHAR(40) NOT NULL,
    confirmado_em VARCHAR(40),
    atualizado_em VARCHAR(40) NOT NULL,
    CONSTRAINT fk_pagamentos_inscricao FOREIGN KEY (inscricao_id) REFERENCES inscricoes(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS sumulas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jogo_id INT NOT NULL UNIQUE,
    modelo_id VARCHAR(120) NOT NULL,
    dados TEXT NOT NULL,
    observacoes TEXT,
    arbitro VARCHAR(255),
    registrado_por VARCHAR(255),
    registrado_em VARCHAR(40) NOT NULL,
    CONSTRAINT fk_sumulas_jogo FOREIGN KEY (jogo_id) REFERENCES jogos(id) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  `CREATE TABLE IF NOT EXISTS classificacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    esporte_id INT NOT NULL,
    time_id INT NOT NULL UNIQUE,
    pontos INT NOT NULL DEFAULT 0,
    jogos INT NOT NULL DEFAULT 0,
    vitorias INT NOT NULL DEFAULT 0,
    empates INT NOT NULL DEFAULT 0,
    derrotas INT NOT NULL DEFAULT 0,
    gols_pro INT NOT NULL DEFAULT 0,
    gols_contra INT NOT NULL DEFAULT 0,
    saldo_gols INT NOT NULL DEFAULT 0,
    atualizado_em VARCHAR(40) NOT NULL,
    CONSTRAINT fk_classificacoes_esporte FOREIGN KEY (esporte_id) REFERENCES esportes(id),
    CONSTRAINT fk_classificacoes_time FOREIGN KEY (time_id) REFERENCES times(id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  "CREATE INDEX idx_jogos_data ON jogos(data)",
  "ALTER TABLE provas_atletismo ADD COLUMN esporte_id INT NULL",
  "ALTER TABLE provas_atletismo MODIFY categoria_id INT NULL",
  "ALTER TABLE esportes ADD COLUMN modalidade VARCHAR(20) NOT NULL DEFAULT 'equipe'",
  "ALTER TABLE jogos MODIFY time_a_id INT NULL",
  "ALTER TABLE jogos MODIFY time_b_id INT NULL",
  "CREATE INDEX idx_jogos_esporte ON jogos(esporte_id)",
  "CREATE INDEX idx_inscricoes_matricula ON inscricoes(matricula)",
  "ALTER TABLE turmas ADD COLUMN qr_code_url TEXT NULL",
  "ALTER TABLE turmas ADD COLUMN qr_code_data MEDIUMTEXT NULL",
  "ALTER TABLE inscricoes ADD COLUMN matricula_ativa VARCHAR(120) NULL",
  `UPDATE inscricoes SET matricula_ativa = matricula
   WHERE matricula_ativa IS NULL AND status_pagamento != 'cancelado'
     AND id IN (SELECT id FROM (SELECT MIN(id) AS id FROM inscricoes WHERE status_pagamento != 'cancelado' GROUP BY matricula) AS primeiras)`,
  "CREATE UNIQUE INDEX uq_inscricoes_matricula_ativa ON inscricoes(matricula_ativa)",
];

function normalizeSql(sql) {
  return sql
    .replace(/INSERT OR REPLACE INTO/gi, "REPLACE INTO")
    .replace(/INSERT OR IGNORE INTO/gi, "INSERT IGNORE INTO")
    .replace(/datetime\(\s*'now'\s*\)/gi, "CURRENT_TIMESTAMP");
}

async function createPool() {
  const pool = mysql.createPool({
    uri: DATABASE_URL,
    connectionLimit: 5,
    waitForConnections: true,
    queueLimit: 0,
  });
  for (const statement of schemaStatements) {
    try {
      await pool.query(statement);
    } catch (error) {
      if (!/duplicate key name|already exists|duplicate column|duplicate entry|multiple primary key|already has a primary key/i.test(String(error?.message || error))) {
        throw error;
      }
    }
  }
  await pool.query("UPDATE provas_atletismo p JOIN esportes e ON e.nome = 'Atletismo' SET p.esporte_id = e.id WHERE p.esporte_id IS NULL");
  await pool.query("UPDATE esportes SET modalidade = 'individual' WHERE LOWER(nome) LIKE '%atletismo%' OR LOWER(nome) LIKE '%xadrez%' OR LOWER(nome) LIKE '%tênis de mesa%' OR LOWER(nome) LIKE '%tenis de mesa%'");
  await pool.query("UPDATE esportes SET modalidade = 'dupla' WHERE LOWER(nome) LIKE '%futevôlei%' OR LOWER(nome) LIKE '%futevolei%'");
  return pool;
}

function createMysqlAdapter(poolOrConnection, ownsPool = false) {
  return {
    kind: "mysql",
    prepare(sql) {
      const normalized = normalizeSql(sql);
      const normalizeParams = (params) => params.map((param) => (param === undefined ? null : param));
      return {
        async get(...params) {
          const [rows] = await poolOrConnection.execute(normalized, normalizeParams(params));
          return rows[0];
        },
        async all(...params) {
          const [rows] = await poolOrConnection.execute(normalized, normalizeParams(params));
          return rows;
        },
        async run(...params) {
          const [result] = await poolOrConnection.execute(normalized, normalizeParams(params));
          return { lastInsertRowid: result.insertId, changes: result.affectedRows };
        },
      };
    },
    async transaction(callback) {
      const connection = await poolOrConnection.getConnection();
      const transactionDb = createMysqlAdapter(connection);
      try {
        await connection.beginTransaction();
        const result = await callback(transactionDb);
        await connection.commit();
        return result;
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }
    },
    async close() {
      if (ownsPool) await poolOrConnection.end();
    },
  };
}

const pool = await createPool();
export const db = createMysqlAdapter(pool, true);
export default db;
