// Regras de agenda: evita marcar dois jogos que não podem acontecer ao mesmo tempo.

// Esportes individuais (Atletismo, Xadrez etc.) têm várias súmulas no mesmo local e horário; não entram nas regras.
export function esporteEhIndividual(esporte) {
  return esporte?.modalidade === "individual" || /atletismo|xadrez/i.test(String(esporte?.nome || ""));
}

// Retorna uma lista de mensagens de conflito (vazia = pode agendar).
// `database` pode ser o db normal ou o objeto de uma transação.
export async function verificarConflitos(database, { esporteId, timeIds, data, hora, local, ignorarJogoId = 0 }) {
  const conflitos = [];
  const ids = timeIds.filter(Boolean).map(Number);

  // 1) Mesma quadra/local no mesmo dia e horário.
  const localOcupado = await database
    .prepare(
      `SELECT j.id, e.nome AS esporte FROM jogos j JOIN esportes e ON e.id = j.esporte_id
       WHERE j.data = ? AND j.hora = ? AND LOWER(TRIM(j.local)) = LOWER(TRIM(?)) AND j.id != ? LIMIT 1`,
    )
    .get(data, hora, local, ignorarJogoId);
  if (localOcupado) conflitos.push(`"${local}" já está ocupado em ${data} às ${hora} (${localOcupado.esporte}).`);

  if (ids.length) {
    const marcas = ids.map(() => "?").join(", ");

    // 2) O mesmo time já joga nesse horário.
    const timeOcupado = await database
      .prepare(
        `SELECT j.id, tu.label FROM jogos j
         JOIN times t ON t.id IN (j.time_a_id, j.time_b_id) JOIN turmas tu ON tu.id = t.turma_id
         WHERE j.data = ? AND j.hora = ? AND j.id != ? AND t.id IN (${marcas}) LIMIT 1`,
      )
      .get(data, hora, ignorarJogoId, ...ids);
    if (timeOcupado) conflitos.push(`${timeOcupado.label} já tem outro jogo em ${data} às ${hora}.`);

    // 3) Alunos inscritos em dois esportes cujos jogos da mesma turma caem no mesmo horário.
    const turmas = await database.prepare(`SELECT turma_id FROM times WHERE id IN (${marcas})`).all(...ids);
    for (const { turma_id: turmaId } of turmas) {
      const outro = await database
        .prepare(
          `SELECT j.esporte_id, e.nome AS esporte, tu.label FROM jogos j
           JOIN esportes e ON e.id = j.esporte_id
           JOIN times t ON t.id IN (j.time_a_id, j.time_b_id) JOIN turmas tu ON tu.id = t.turma_id
           WHERE j.data = ? AND j.hora = ? AND j.id != ? AND j.esporte_id != ? AND t.turma_id = ?
             AND EXISTS (
               SELECT 1 FROM inscricoes i
               JOIN inscricao_esportes ie1 ON ie1.inscricao_id = i.id AND ie1.esporte_id = ?
               JOIN inscricao_esportes ie2 ON ie2.inscricao_id = i.id AND ie2.esporte_id = j.esporte_id
               WHERE i.turma_id = ? AND i.status_pagamento != 'cancelado')
           LIMIT 1`,
        )
        .get(data, hora, ignorarJogoId, esporteId, turmaId, esporteId, turmaId);
      if (outro) conflitos.push(`Há alunos de ${outro.label} inscritos nos dois esportes: ${outro.esporte} já joga em ${data} às ${hora}.`);
    }
  }
  return conflitos;
}
