import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { db } from "./db.js";
import { VALOR_INSCRICAO } from "./config.js";

// Cria os dados basicos (admin, categorias, turmas, esportes, provas).
// E seguro rodar varias vezes: so cria o que ainda nao existe.
// Inscricoes de demonstracao so sao criadas com SEED_DEMO=1.
export async function runSeed({ demo = process.env.SEED_DEMO === "1", log = console.log } = {}) {
  // --- Admin ---
  const adminCount = (await db.prepare("SELECT COUNT(*) AS n FROM admins").get()).n;
  if (Number(adminCount) === 0) {
    const isProd = process.env.NODE_ENV === "production";
    const username = process.env.ADMIN_USERNAME || "admin";
    let senha = process.env.ADMIN_PASSWORD;
    let gerada = false;
    if (!senha) {
      if (isProd) {
        senha = crypto.randomBytes(9).toString("base64url");
        gerada = true;
      } else {
        senha = "satc2024";
      }
    }
    await db
      .prepare("INSERT INTO admins (username, password_hash, nome) VALUES (?, ?, ?)")
      .run(username, bcrypt.hashSync(senha, 10), "Administrador Geral");
    log(`Admin criado -> usuario: ${username}${gerada || !isProd ? ` | senha: ${senha}` : ""} (troque a senha depois de entrar)`);
  }

  // --- Categorias ---
  const CATEGORIAS = ["6\u00ba e 7\u00ba Ano", "8\u00ba e 9\u00ba Ano", "Ensino M\u00e9dio"];
  if (Number((await db.prepare("SELECT COUNT(*) AS n FROM categorias").get()).n) === 0) {
    for (const [i, nome] of CATEGORIAS.entries()) {
      await db.prepare("INSERT INTO categorias (nome, ordem) VALUES (?, ?)").run(nome, i + 1);
    }
    log(`Criadas ${CATEGORIAS.length} categorias.`);
  }
  const categoriaIds = {};
  for (const c of await db.prepare("SELECT * FROM categorias").all()) categoriaIds[c.nome] = c.id;
  const catSexto = categoriaIds[CATEGORIAS[0]];
  const catOitavo = categoriaIds[CATEGORIAS[1]];
  const catMedio = categoriaIds[CATEGORIAS[2]];

  // --- Turmas (quatro secoes por ano) ---
  const gruposDeTurmas = [
    { prefixo: "6\u00ba Ano", categoriaId: catSexto, vagas: 40 },
    { prefixo: "7\u00ba Ano", categoriaId: catSexto, vagas: 40 },
    { prefixo: "8\u00ba Ano", categoriaId: catOitavo, vagas: 40 },
    { prefixo: "9\u00ba Ano", categoriaId: catOitavo, vagas: 40 },
    { prefixo: "1\u00ba Ano EM", categoriaId: catMedio, vagas: 50 },
    { prefixo: "2\u00ba Ano EM", categoriaId: catMedio, vagas: 50 },
    { prefixo: "3\u00ba Ano EM", categoriaId: catMedio, vagas: 50 },
  ];
  let turmasCriadas = 0;
  const turmasExistentes = Number((await db.prepare("SELECT COUNT(*) AS n FROM turmas").get()).n);
  for (const grupo of turmasExistentes === 0 ? gruposDeTurmas : []) {
    for (const secao of ["A", "B", "C", "D"]) {
      const label = `${grupo.prefixo} ${secao}`;
      if (!(await db.prepare("SELECT id FROM turmas WHERE label = ?").get(label))) {
        await db
          .prepare("INSERT INTO turmas (label, categoria_id, taxa, vagas, ativo) VALUES (?, ?, ?, ?, 1)")
          .run(label, grupo.categoriaId, VALOR_INSCRICAO, grupo.vagas);
        turmasCriadas += 1;
      }
    }
  }
  // Valor unico: todas as turmas passam a ter a mesma taxa.
  await db.prepare("UPDATE turmas SET taxa = ?").run(VALOR_INSCRICAO);
  if (turmasCriadas) log(`${turmasCriadas} turmas criadas.`);

  // --- Esportes ---
  const ESPORTES = [
    { nome: "Futebol de Campo Masculino", icone: "\u26bd", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Futsal Masculino", icone: "\u26bd", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Futsal Feminino", icone: "\u26bd", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Handebol Feminino", icone: "\ud83e\udd3e", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Handebol Masculino", icone: "\ud83e\udd3e", categorias: [catMedio] },
    { nome: "T\u00eanis de Mesa Masculino", icone: "\ud83c\udfd3", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "T\u00eanis de Mesa Feminino", icone: "\ud83c\udfd3", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Xadrez Masculino", icone: "\u265f\ufe0f", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Xadrez Feminino", icone: "\u265f\ufe0f", categorias: [catSexto, catOitavo, catMedio] },
    { nome: "Queimada Mista", icone: "\ud83c\udfbe", categorias: [catSexto] },
    {
      nome: "Atletismo",
      icone: "\ud83c\udfc3",
      categorias: [catSexto, catOitavo, catMedio],
      descricao:
        "6\u00ba/7\u00ba ano: corrida 75m, lan\u00e7amento de pelota, salto em dist\u00e2ncia e revezamento 4x100m. " +
        "8\u00ba ano em diante: corrida 100m, salto em dist\u00e2ncia e revezamento 4x100m. Aberto para qualquer g\u00eanero.",
    },
    { nome: "Street-ball Masculino", icone: "\ud83c\udfc0", categorias: [catOitavo, catMedio] },
    { nome: "Street-ball Feminino", icone: "\ud83c\udfc0", categorias: [catOitavo, catMedio] },
    { nome: "Voleibol Misto", icone: "\ud83c\udfd0", categorias: [catOitavo, catMedio] },
    { nome: "Futev\u00f4lei Masculino", icone: "\ud83c\udfd0", categorias: [catMedio] },
    { nome: "Futev\u00f4lei Misto", icone: "\ud83c\udfd0", categorias: [catMedio] },
  ];
  if (Number((await db.prepare("SELECT COUNT(*) AS n FROM esportes").get()).n) === 0) {
    for (const e of ESPORTES) {
      const genero = /masculino/i.test(e.nome) ? "masculino" : /feminino/i.test(e.nome) ? "feminino" : "misto";
      const modalidade = /atletismo|xadrez|t[eê]nis de mesa/i.test(e.nome) ? "individual" : /futev[oô]lei/i.test(e.nome) ? "dupla" : "equipe";
      const info = await db
        .prepare("INSERT INTO esportes (nome, icone, descricao, genero, modalidade, ativo) VALUES (?, ?, ?, ?, ?, 1)")
        .run(e.nome, e.icone, e.descricao || null, genero, modalidade);
      for (const catId of e.categorias) {
        await db.prepare("INSERT INTO categoria_esportes (categoria_id, esporte_id) VALUES (?, ?)").run(catId, info.lastInsertRowid);
      }
    }
    log(`Criados ${ESPORTES.length} esportes.`);
  }

  // --- Provas de Atletismo ---
  const provasAtletismo = [
    { categoriaId: catSexto, nomes: ["Corrida 75m", "Lan\u00e7amento de pelota", "Salto em dist\u00e2ncia", "Revezamento 4x100m"] },
    { categoriaId: catOitavo, nomes: ["Corrida 100m", "Salto em dist\u00e2ncia", "Revezamento 4x100m"] },
    { categoriaId: catMedio, nomes: ["Corrida 100m", "Salto em dist\u00e2ncia", "Revezamento 4x100m"] },
  ];
  const provasExistentes = Number((await db.prepare("SELECT COUNT(*) AS n FROM provas_atletismo").get()).n);
  for (const grupo of provasExistentes === 0 ? provasAtletismo : []) {
    for (const [ordem, nome] of grupo.nomes.entries()) {
      await db
        .prepare("INSERT IGNORE INTO provas_atletismo (categoria_id, nome, ordem, ativo) VALUES (?, ?, ?, 1)")
        .run(grupo.categoriaId, nome, ordem);
    }
  }

  // Liga as provas ao esporte Atletismo (campo usado pela gestão de subcategorias).
  await db
    .prepare("UPDATE provas_atletismo p JOIN esportes e ON e.nome = 'Atletismo' SET p.esporte_id = e.id WHERE p.esporte_id IS NULL")
    .run();

  // --- Inscricoes de demonstracao (opcional) ---
  if (demo) {
    const atletismo = await db.prepare("SELECT id FROM esportes WHERE nome = 'Atletismo'").get();
    const provaBase = await db
      .prepare("SELECT id FROM provas_atletismo WHERE categoria_id = ? ORDER BY ordem, id LIMIT 1")
      .get(catSexto);
    let contador = 90000; // matriculas de 5 digitos reservadas para demonstracao
    for (const prefixo of ["6\u00ba Ano", "7\u00ba Ano"]) {
      for (const secao of ["A", "B", "C", "D"]) {
        const turma = await db.prepare("SELECT id FROM turmas WHERE label = ?").get(`${prefixo} ${secao}`);
        if (!turma) continue;
        for (let numero = 1; numero <= 4; numero += 1) {
          contador += 1;
          const matricula = String(contador);
          if (await db.prepare("SELECT id FROM inscricoes WHERE matricula = ?").get(matricula)) continue;
          const info = await db
            .prepare(
              `INSERT INTO inscricoes (codigo, nome, matricula, matricula_ativa, sexo, turma_id, status_pagamento, valor, pix_code, criado_em)
               VALUES (?, ?, ?, ?, ?, ?, 'confirmado', ?, ?, ?)`,
            )
            .run(
              `DEMO-${matricula}`,
              `Aluno demonstrativo ${prefixo} ${secao} ${String(numero).padStart(2, "0")}`,
              matricula, matricula,
              numero % 2 === 0 ? "feminino" : "masculino",
              turma.id, VALOR_INSCRICAO, "DEMO - pagamento n\u00e3o real", new Date().toISOString(),
            );
          if (atletismo) {
            await db.prepare("INSERT IGNORE INTO inscricao_esportes (inscricao_id, esporte_id) VALUES (?, ?)").run(info.lastInsertRowid, atletismo.id);
            await db.prepare("INSERT IGNORE INTO times (esporte_id, turma_id) VALUES (?, ?)").run(atletismo.id, turma.id);
            if (provaBase) await db.prepare("INSERT IGNORE INTO inscricao_provas_atletismo (inscricao_id, prova_id) VALUES (?, ?)").run(info.lastInsertRowid, provaBase.id);
          }
        }
      }
    }
    log("Inscri\u00e7\u00f5es de demonstra\u00e7\u00e3o conferidas (matr\u00edculas 90001+).");
  }
}
