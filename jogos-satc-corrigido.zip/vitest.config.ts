import { defineConfig } from "vitest/config";
import path from "path";

const templateRoot = path.resolve(import.meta.dirname);

export default defineConfig({
  root: templateRoot,
  resolve: {
    alias: {
      "@": path.resolve(templateRoot, "client", "src"),
      "@shared": path.resolve(templateRoot, "shared"),
      "@assets": path.resolve(templateRoot, "attached_assets"),
    },
  },
  test: {
    environment: "node",
    setupFiles: ["server/test-guard.ts"],
    fileParallelism: false,
    testTimeout: 20000,
    hookTimeout: 20000,
    include: ["server/**/*.test.ts", "server/**/*.spec.ts"],
  },
});
