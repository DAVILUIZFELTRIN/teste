import { useEffect, useState } from "react";
import { api } from "../api.js";
import { dataHojeBrasilia } from "../utils/data.js";

const horaAgora = () => new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" });

// Tela para exibir em televisão: jogos do dia, com atualização automática e sem dados pessoais.
export default function TVJogosPage() {
  const [jogos, setJogos] = useState([]);
  const [erro, setErro] = useState("");
  const [hora, setHora] = useState(horaAgora());

  async function carregar() {
    try {
      const lista = await api.getJogos({ data: dataHojeBrasilia() });
      setJogos([...lista].sort((a, b) => String(a.hora).localeCompare(String(b.hora))));
      setErro("");
    } catch (e) {
      setErro(e.message);
    }
    setHora(horaAgora());
  }

  useEffect(() => {
    carregar();
    const timer = setInterval(carregar, 30000);
    return () => clearInterval(timer);
  }, []);

  return (
    <main className="tv-page min-h-screen bg-black text-white px-8 py-10">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-end border-b-2 border-green-500 pb-5 mb-8">
          <div>
            <p className="text-green-400 font-mono uppercase tracking-[.3em] text-sm">Jogos SATC · placar ao vivo</p>
            <h1 className="text-6xl font-black uppercase font-display">Jogos de hoje</h1>
          </div>
          <p className="text-slate-400 font-mono">Atualização automática · {hora}</p>
        </div>
        {erro && <p className="text-red-400">{erro}</p>}
        {!erro && jogos.length === 0 && <div className="py-24 text-center text-slate-500 text-2xl uppercase font-display">Nenhum jogo agendado para hoje</div>}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
          {jogos.map((j) => {
            const individual = !j.timeA;
            const temPlacar = !individual && j.status !== "agendado" && j.placarA != null && j.placarB != null;
            return (
              <article key={j.id} className="border border-slate-700 bg-slate-950 p-6">
                <div className="flex justify-between text-green-400 font-mono uppercase text-sm">
                  <span>{j.esporte?.icone} {j.esporte?.nome}</span>
                  <span>{j.hora}</span>
                </div>
                <h2 className="text-3xl font-black uppercase font-display mt-5">
                  {j.timeA?.label || "Competição individual"}
                  <span className="text-slate-600 mx-3">×</span>
                  {j.timeB?.label || "Todos contra todos"}
                </h2>
                <p className="text-slate-400 mt-2 uppercase">{j.local} · {j.fase}</p>
                {temPlacar && (
                  <div className="text-6xl text-green-400 font-black font-display mt-6">
                    {j.placarA} <span className="text-slate-600">-</span> {j.placarB}
                    {j.status === "em_andamento" && <span className="ml-4 text-lg text-amber-300 uppercase tracking-wider align-middle">ao vivo</span>}
                  </div>
                )}
                {!temPlacar && (
                  <div className="mt-6 text-amber-300 font-black uppercase tracking-wider">
                    {j.status === "em_andamento" ? "Ao vivo" : j.status === "finalizado" ? "Finalizado" : "Agendado"}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </div>
    </main>
  );
}
