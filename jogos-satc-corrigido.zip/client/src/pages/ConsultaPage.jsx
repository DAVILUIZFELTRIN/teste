import { useState } from "react";
import { api } from "../api.js";
import { SectionHeader, StatusBadge, ErrorBox } from "../components/UI.jsx";

export default function ConsultaPage() {
  const [modo, setModo] = useState("codigo");
  const [valor, setValor] = useState("");
  const [resultado, setResultado] = useState(null);
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  async function buscar(e) {
    e.preventDefault();
    if (!valor.trim()) return;
    setLoading(true);
    setErro("");
    setResultado(null);
    try {
      const r = await api.consultarInscricao({ [modo]: valor.trim() });
      setResultado(r);
    } catch (err) {
      setErro(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="pt-14 max-w-xl mx-auto px-4 py-12">
      <SectionHeader eyebrow="03" title="CONSULTAR" />
      <p className="text-slate-400 mb-6">Veja se sua inscricao ja foi paga ou esta pendente.</p>

      <form onSubmit={buscar} className="space-y-4">
        <div className="flex gap-2 text-xs font-mono uppercase tracking-widest">
          <button
            type="button"
            onClick={() => { setModo("codigo"); setValor(""); }}
            className={`px-3 py-1.5 rounded-sm border ${modo === "codigo" ? "border-green-500 text-green-400 bg-green-500/10" : "border-line text-slate-400"}`}
          >
            Por codigo
          </button>
          <button
            type="button"
            onClick={() => { setModo("matricula"); setValor(""); }}
            className={`px-3 py-1.5 rounded-sm border ${modo === "matricula" ? "border-green-500 text-green-400 bg-green-500/10" : "border-line text-slate-400"}`}
          >
            Por matricula
          </button>
          <button
            type="button"
            onClick={() => { setModo("nome"); setValor(""); }}
            className={`px-3 py-1.5 rounded-sm border ${modo === "nome" ? "border-green-500 text-green-400 bg-green-500/10" : "border-line text-slate-400"}`}
          >
            Por nome
          </button>
        </div>
        <input
          className="input"
          value={valor}
          onChange={(e) => setValor(modo === "matricula" ? e.target.value.replace(/\D/g, "").slice(0, 5) : e.target.value)}
          inputMode={modo === "matricula" ? "numeric" : "text"}
          maxLength={modo === "matricula" ? 5 : 120}
          placeholder={modo === "codigo" ? "Ex: SATC-2026-AB3K7M" : modo === "nome" ? "Nome completo ou parte do nome" : "5 números da matrícula"}
        />
        <button
          type="submit"
          disabled={loading}
          className="w-full py-4 bg-green-500 text-black font-black uppercase tracking-wider hover:bg-green-400 disabled:opacity-50"
        >
          {loading ? "Buscando..." : "Consultar"}
        </button>
      </form>

      <ErrorBox message={erro} />

      {resultado && modo === "nome" && (
        <div className="mt-8 space-y-2">
          {(resultado.resultados || []).map((item, index) => <div key={`${item.nome}-${item.turma}-${index}`} className="border border-line p-4">
            <div className="flex justify-between gap-3"><strong className="font-display uppercase text-lg">{item.nome}</strong><StatusBadge status={item.status_pagamento} /></div>
            <p className="text-sm text-slate-400 mt-1">{item.turma}</p>
            <p className="text-xs text-green-400 mt-2">{item.esportes.join(", ") || "Nenhum esporte"}</p>
          </div>)}
          {(resultado.resultados || []).length === 0 && <div className="border border-line p-6 text-center text-slate-500">Nenhuma inscrição encontrada.</div>}
        </div>
      )}
      {resultado && modo !== "nome" && (
        <div className="mt-8 border border-line p-6 space-y-3">
          <div className="flex justify-between items-center"><span className="font-black text-2xl font-display uppercase">{resultado.nome}</span><StatusBadge status={resultado.status_pagamento} /></div>
          <Row label="Codigo" value={resultado.codigo} /><Row label="Matricula" value={resultado.matricula} />{resultado.valor != null && <Row label="Valor" value={`R$ ${Number(resultado.valor).toFixed(2)}`} />}<Row label="Esportes" value={resultado.esportes.map((s) => s.nome).join(", ")} />
          {resultado.status_pagamento === "pendente" && (resultado.qr_code_url
            ? <div className="mt-3 text-center"><p className="text-xs text-slate-400 mb-2">Pague pelo QR Code da sua turma e entregue o comprovante ao responsável.</p><img src={resultado.qr_code_url} alt="QR Code de pagamento da turma" className="mx-auto w-48 h-48 object-contain bg-white p-2 rounded" /></div>
            : resultado.pix_code && <div className="text-xs text-slate-300 bg-panel border border-line p-3 rounded break-all font-mono mt-2">{resultado.pix_code}</div>)}
        </div>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between border-b border-line pb-2 last:border-0 last:pb-0 text-sm">
      <span className="text-slate-500 font-mono text-xs uppercase tracking-widest">{label}</span>
      <span className="text-slate-200 font-semibold">{value || "-"}</span>
    </div>
  );
}
