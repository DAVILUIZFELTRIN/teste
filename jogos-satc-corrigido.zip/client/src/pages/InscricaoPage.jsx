import { useEffect, useState } from "react";
import { api } from "../api.js";
import { ErrorBox } from "../components/UI.jsx";

export default function InscricaoPage() {
  const [step, setStep] = useState(1);
  const [turmas, setTurmas] = useState([]);
  const [esportes, setEsportes] = useState([]);
  const [carregandoEsportes, setCarregandoEsportes] = useState(false);
  const [erroCarga, setErroCarga] = useState("");
  const [form, setForm] = useState({ nome: "", matricula: "", sexo: "", turmaId: "", esportes: [], provasAtletismo: [] });
  const [errors, setErrors] = useState({});
  const [erroApi, setErroApi] = useState("");
  const [loading, setLoading] = useState(false);
  const [resultado, setResultado] = useState(null);
  const [configuracoes, setConfiguracoes] = useState(null);

  useEffect(() => {
    Promise.all([api.getTurmas(), api.getConfiguracoes().catch(() => null)]).then(([lista, config]) => { setTurmas(lista); setConfiguracoes(config); }).catch(() => setErroCarga("Não foi possível carregar as turmas. Verifique a conexão e atualize a página."));
  }, []);

  // Busca os esportes disponiveis so depois que a turma foi escolhida,
  // porque cada ano joga um conjunto diferente de esportes.
  useEffect(() => {
    if (!form.turmaId) { setEsportes([]); return; }
    setCarregandoEsportes(true);
    api
      .getEsportesDaTurma(form.turmaId, form.sexo)
      .then(setEsportes)
      .finally(() => setCarregandoEsportes(false));
  }, [form.turmaId, form.sexo]);

  const turmaSelecionada = turmas.find((t) => String(t.id) === String(form.turmaId));

  function validarStep1() {
    const e = {};
    if (!form.nome.trim()) e.nome = "Nome obrigatorio";
    if (!/^\d{5}$/.test(form.matricula)) e.matricula = "A matrícula deve ter exatamente 5 números";
    if (!form.sexo) e.sexo = "Selecione seu sexo";
    if (!form.turmaId) e.turmaId = "Selecione sua turma";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function validarStep2() {
    const e = {};
    if (form.esportes.length === 0) e.esportes = "Selecione ao menos um esporte";
    const atletismo = esportes.find((s) => s.nome === "Atletismo");
    if (atletismo && form.esportes.includes(atletismo.id) && form.provasAtletismo.length === 0) {
      e.esportes = "Selecione ao menos uma prova de Atletismo ou retire o Atletismo da inscrição";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function toggleEsporte(id) {
    setForm((f) => ({
      ...f,
      esportes: f.esportes.includes(id) ? f.esportes.filter((s) => s !== id) : [...f.esportes, id],
      ...(esportes.find((s) => s.id === id)?.nome === "Atletismo" && f.esportes.includes(id) ? { provasAtletismo: [] } : {}),
    }));
  }

  function toggleProva(id) {
    setForm((f) => ({
      ...f,
      provasAtletismo: f.provasAtletismo.includes(id)
        ? f.provasAtletismo.filter((provaId) => provaId !== id)
        : [...f.provasAtletismo, id],
    }));
  }

  async function enviar() {
    setLoading(true);
    setErroApi("");
    try {
      const r = await api.inscrever({
        nome: form.nome.trim(),
        matricula: form.matricula.trim(),
        sexo: form.sexo,
        turmaId: Number(form.turmaId),
        esportes: form.esportes.map(Number),
        provasAtletismo: form.provasAtletismo.map(Number),
      });
      setResultado(r);
      setStep(4);
    } catch (e) {
      setErroApi(e.message);
    } finally {
      setLoading(false);
    }
  }

  const activeGroups = turmas.filter((t) => t.ativo && t.inscritos < t.vagas);
  const periodoBloqueado = configuracoes && configuracoes.status !== "abertas";

  return (
    <div className="pt-14 max-w-2xl mx-auto px-4 py-12">
      {erroCarga && <div className="mb-6 border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-300">{erroCarga}</div>}
      {periodoBloqueado && step < 4 && <div className="mb-8 border border-amber-400/40 bg-amber-500/10 p-5"><p className="font-black uppercase text-amber-200">{configuracoes.status === "em_breve" ? "Inscrições ainda não foram abertas" : configuracoes.status === "bloqueadas" ? "Inscrições bloqueadas pela organização" : "Inscrições encerradas"}</p><p className="text-sm text-slate-300 mt-1">{configuracoes.status === "bloqueadas" ? "O administrador desativou temporariamente novas inscrições. Tente novamente quando a organização liberar o acesso." : "Consulte a página inicial para ver o período definido pela organização."}</p></div>}
      {step < 4 && !periodoBloqueado && (
        <div className="flex items-center gap-0 mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center flex-1">
              <div
                className={`w-8 h-8 rounded-sm flex items-center justify-center font-black text-sm font-display ${
                  step >= s ? "bg-green-500 text-black" : "bg-line text-slate-500"
                }`}
              >
                {s}
              </div>
              {s < 3 && <div className={`flex-1 h-0.5 ${step > s ? "bg-green-500" : "bg-line"}`} />}
            </div>
          ))}
        </div>
      )}

      <ErrorBox message={erroApi} />

      {step === 1 && !periodoBloqueado && (
        <>
          <h1 className="font-black text-5xl uppercase mb-8 font-display">DADOS PESSOAIS</h1>
          <div className="space-y-5">
            <Field label="Nome completo" error={errors.nome}>
              <input
                className="input"
                value={form.nome}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
                placeholder="Seu nome completo"
              />
            </Field>
            <Field label="Matricula" error={errors.matricula}>
              <input
                className="input"
                value={form.matricula}
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={5}
                autoComplete="off"
                onChange={(e) => setForm({ ...form, matricula: e.target.value.replace(/\D/g, "").slice(0, 5) })}
                placeholder="5 números da matrícula"
              />
            </Field>
            <Field label="Sexo" error={errors.sexo}>
              <select
                className="input"
                value={form.sexo}
                onChange={(e) => setForm({ ...form, sexo: e.target.value, esportes: [] })}
              >
                <option value="">Selecione seu sexo</option>
                <option value="masculino">Masculino</option>
                <option value="feminino">Feminino</option>
              </select>
            </Field>
            <Field label="Turma" error={errors.turmaId}>
              <select
                className="input"
                value={form.turmaId}
                onChange={(e) => setForm({ ...form, turmaId: e.target.value, esportes: [] })}
              >
                <option value="">Selecione sua turma</option>
                {activeGroups.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.label} - R$ {Number(t.taxa ?? 0).toFixed(2)} ({Number(t.vagas ?? 0) - Number(t.inscritos ?? 0)} vagas)
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <button
            onClick={() => validarStep1() && setStep(2)}
            className="mt-8 w-full py-4 bg-green-500 text-black font-black text-lg uppercase tracking-wider hover:bg-green-300 transition-colors shadow-[0_0_0_2px_rgba(132,204,22,0.25)]"
          >
            Continuar
          </button>
        </>
      )}

      {step === 2 && !periodoBloqueado && (
        <>
          <h1 className="font-black text-5xl uppercase mb-2 font-display">ESPORTES</h1>
          <p className="text-slate-500 text-sm mb-6">
            Esportes disponíveis para {turmaSelecionada?.label} e para alunos do sexo {form.sexo === "masculino" ? "masculino" : "feminino"}. Modalidades mistas aparecem para ambos.
          </p>
          {errors.esportes && <p className="text-red-400 text-sm mb-4">{errors.esportes}</p>}
          {carregandoEsportes ? (
            <p className="text-slate-500 font-mono text-sm py-6 text-center">Carregando esportes...</p>
          ) : esportes.length === 0 ? (
            <p className="text-slate-500 font-mono text-sm py-6 text-center border border-line">
              Nenhum esporte disponivel para esta turma ainda.
            </p>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {esportes.map((s) => {
                const selecionado = form.esportes.includes(s.id);
                return (
                  <div key={s.id} className={`border-2 p-5 transition-all ${selecionado ? "border-green-400 bg-green-500/10 shadow-[0_0_18px_rgba(34,197,94,0.12)]" : "border-line hover:border-slate-400"}`}>
                    <button
                      type="button"
                      onClick={() => toggleEsporte(s.id)}
                      className="w-full text-left"
                    >
                      <span className="text-2xl mr-2">{s.icone}</span>
                      <span className="font-bold uppercase font-display text-lg">{s.nome}</span>
                      {s.descricao && <p className="text-xs text-slate-500 mt-1">{s.descricao}</p>}
                      {s.nome === "Atletismo" && <p className="text-xs text-green-400 mt-1 font-mono uppercase">Categoria {form.sexo === "masculino" ? "masculina" : "feminina"} · provas do seu ano</p>}
                    </button>
                    {s.nome === "Atletismo" && selecionado && Array.isArray(s.provas) && (
                      <div className="mt-4 pt-4 border-t border-line">
                        <p className="text-xs text-green-400 font-mono uppercase tracking-widest mb-3">Escolha as provas que deseja disputar</p>
                        <div className="space-y-2">
                          {s.provas.map((prova) => (
                            <label key={prova.id} className="flex items-center gap-3 text-sm text-slate-300 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={form.provasAtletismo.includes(prova.id)}
                                onChange={() => toggleProva(prova.id)}
                                className="accent-green-500 w-4 h-4"
                              />
                              {prova.nome}
                            </label>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <div className="flex gap-3 mt-8">
            <button
              onClick={() => setStep(1)}
              className="flex-1 py-4 border border-slate-500 text-slate-200 font-bold uppercase tracking-wider hover:border-white"
            >
              Voltar
            </button>
            <button
              onClick={() => validarStep2() && setStep(3)}
              className="flex-1 py-4 bg-green-500 text-black font-black uppercase tracking-wider hover:bg-green-400"
            >
              Continuar
            </button>
          </div>
        </>
      )}

      {step === 3 && !periodoBloqueado && (
        <>
          <h1 className="font-black text-5xl uppercase mb-8 font-display">CONFIRMACAO</h1>
          <div className="border border-line p-6 space-y-3 text-sm">
            <Row label="Nome" value={form.nome} />
            <Row label="Matricula" value={form.matricula} />
            <Row label="Sexo" value={form.sexo === "masculino" ? "Masculino" : "Feminino"} />
            <Row label="Turma" value={turmaSelecionada?.label} />
            <Row label="Esportes" value={esportes.filter((s) => form.esportes.includes(s.id)).map((s) => s.nome).join(", ")} />
            {form.provasAtletismo.length > 0 && (
              <Row label="Provas de Atletismo" value={esportes.find((s) => s.nome === "Atletismo")?.provas?.filter((p) => form.provasAtletismo.includes(p.id)).map((p) => p.nome).join(", ")} />
            )}
            <Row label="Valor" value={`R$ ${Number(turmaSelecionada?.taxa ?? 0).toFixed(2)}`} highlight />
          </div>
          <div className="flex gap-3 mt-8">
            <button
              onClick={() => setStep(2)}
              className="flex-1 py-4 border border-slate-500 text-slate-200 font-bold uppercase tracking-wider hover:border-white"
            >
              Voltar
            </button>
            <button
              onClick={enviar}
              disabled={loading}
              className="flex-1 py-4 bg-green-500 text-black font-black uppercase tracking-wider hover:bg-green-400 disabled:opacity-50"
            >
              {loading ? "Enviando..." : "Confirmar inscricao"}
            </button>
          </div>
        </>
      )}

      {step === 4 && resultado && (
        <div>
          <div className="w-14 h-14 rounded-full bg-green-500/15 border border-green-500/40 flex items-center justify-center mb-6">
            <span className="text-green-400 text-2xl">&#10003;</span>
          </div>
          <h1 className="font-black text-4xl sm:text-5xl uppercase mb-2 font-display">SÓ FALTA MAIS UM PASSO, EFETUE O PAGAMENTO PARA CONFIRMAR SUA INSCRIÇÃO</h1>
          <p className="text-slate-400 mb-8">
            Guarde seu codigo para consultar o status do pagamento depois.
          </p>
          <div className="border border-line p-6 space-y-4">
            <div>
              <div className="font-mono text-xs text-slate-500 uppercase tracking-widest mb-1">Codigo da inscricao</div>
              <div className="font-black text-3xl text-green-400 font-display">{resultado.codigo}</div>
            </div>
            <div>
              <div className="font-mono text-xs text-slate-500 uppercase tracking-widest mb-2">QR Code para pagamento · {turmaSelecionada?.label || "sua turma"}</div>
              {resultado.qr_code_url ? (
                <div className="bg-white border border-green-500/50 p-4 rounded flex justify-center">
                  <img src={resultado.qr_code_url} alt={`QR Code para pagamento da turma ${turmaSelecionada?.label || "selecionada"}`} className="w-64 h-64 max-w-full object-contain" />
                </div>
              ) : (
                <div className="text-sm text-amber-200 bg-amber-500/10 border border-amber-400/30 p-4 rounded">
                  O QR Code desta turma ainda não foi disponibilizado pela administração. Procure a secretaria para concluir o pagamento.
                </div>
              )}
            </div>
            <p className="text-xs text-slate-500">
              Escaneie o QR Code e envie o comprovante para a secretaria. O status muda para "confirmado" depois
              da conferencia.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, error, children }) {
  return (
    <div>
      <label className="block font-mono text-xs text-slate-400 uppercase tracking-widest mb-2">{label}</label>
      {children}
      {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
    </div>
  );
}

function Row({ label, value, highlight }) {
  return (
    <div className="flex justify-between border-b border-line pb-2 last:border-0 last:pb-0">
      <span className="text-slate-500 font-mono text-xs uppercase tracking-widest">{label}</span>
      <span className={highlight ? "text-green-400 font-black text-xl font-display" : "text-slate-200 font-semibold"}>
        {value || "-"}
      </span>
    </div>
  );
}
