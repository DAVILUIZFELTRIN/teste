import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import AdminOverview from "./admin/AdminOverview.jsx";
import AdminTurmas from "./admin/AdminTurmas.jsx";
import AdminEsportes from "./admin/AdminEsportes.jsx";
import AdminInscricoes from "./admin/AdminInscricoes.jsx";
import AdminJogos from "./admin/AdminJogos.jsx";
import AdminTabelas from "./admin/AdminTabelas.jsx";

const TABS = [
  { id: "overview", label: "Visao Geral", Component: AdminOverview },
  { id: "inscricoes", label: "Inscricoes", Component: AdminInscricoes },
  { id: "jogos", label: "Jogos e Sumulas", Component: AdminJogos },
  { id: "tabelas", label: "Gerar Tabelas", Component: AdminTabelas },
  { id: "turmas", label: "Turmas", Component: AdminTurmas },
  { id: "esportes", label: "Esportes", Component: AdminEsportes },
];

export default function AdminDashboardPage() {
  const [tab, setTab] = useState("overview");
  const { admin } = useAuth();
  const Active = TABS.find((t) => t.id === tab)?.Component;

  return (
    <div className="pt-14 max-w-7xl mx-auto px-4 py-10">
      <div className="flex items-baseline gap-4 mb-2">
        <span className="font-mono text-green-400 text-xs tracking-[0.2em]">ADMIN</span>
        <h1 className="font-black text-4xl uppercase font-display">PAINEL DO CAMPEONATO</h1>
      </div>
      <p className="text-slate-500 text-sm mb-8">Logado como {admin?.nome}</p>

      <div className="flex flex-wrap gap-2 mb-8">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`admin-tab ${tab === t.id ? "admin-tab-active" : ""}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {Active && <Active />}
    </div>
  );
}
