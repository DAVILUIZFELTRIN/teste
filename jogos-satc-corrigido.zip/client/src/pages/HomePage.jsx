import { useEffect, useState } from "react";
import { dataHojeBrasilia } from "../utils/data.js";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { Loading, JogoStatusBadge } from "../components/UI.jsx";

function listOrEmpty(value, keys = []) {
  if (Array.isArray(value)) return value;
  for (const key of keys) if (Array.isArray(value?.[key])) return value[key];
  return [];
}

export default function HomePage() {
  const [turmas, setTurmas] = useState(null);
  const [esportes, setEsportes] = useState(null);
  const [jogosHoje, setJogosHoje] = useState(null);
  const [configuracoes, setConfiguracoes] = useState(null);
  const [erro, setErro] = useState("");

  useEffect(() => {
    const hoje = dataHojeBrasilia();
    Promise.all([api.getTurmas(), api.getEsportes(), api.getJogos({ data: hoje }), api.getConfiguracoes()])
      .then(([t, e, j, c]) => {
        setTurmas(listOrEmpty(t, ["turmas", "items"]));
        setEsportes(listOrEmpty(e, ["esportes", "items"]));
        setJogosHoje(listOrEmpty(j, ["jogos", "items"]));
        setConfiguracoes(c);
      })
      .catch((e) => setErro(e.message));
  }, []);

  const totalInscritos = (Array.isArray(turmas) ? turmas : []).reduce((s, t) => s + Number(t.inscritos || 0), 0);

  return (
    <div className="pt-14">
      {configuracoes?.status === "bloqueadas" && <div className="relative z-10 border-b-2 border-red-300 bg-red-600 px-4 py-4 text-white shadow-lg"><div className="mx-auto flex max-w-7xl items-center gap-4"><div className="flex h-10 w-10 shrink-0 items-center justify-center border-2 border-white font-black text-xl">!</div><div><p className="font-black uppercase tracking-wide">Inscrições temporariamente bloqueadas</p><p className="text-sm text-red-100">A organização desativou novas inscrições no momento. As inscrições já realizadas continuam válidas.</p></div></div></div>}
      <section className="home-hero relative min-h-[80vh] flex items-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage:
              "url('https://files.manuscdn.com/user_upload_by_module/session_file/310519663953785839/JYPlxkqXQfstYfxD.webp')",
            backgroundPosition: "center 100%",
            backgroundSize: "auto 170%",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-bg via-bg/85 to-bg/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-4 py-24">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-1 h-8 bg-green-400" />
              <span className="font-mono text-xs text-green-400 tracking-[0.25em] uppercase">
                {configuracoes?.status === "em_breve" ? "Inscrições em breve" : configuracoes?.status === "encerradas" ? "Inscrições encerradas" : configuracoes?.status === "bloqueadas" ? "Inscrições bloqueadas" : "Inscrições abertas"}
              </span>
            </div>
            <h1 className="text-7xl sm:text-8xl md:text-9xl font-black uppercase leading-none text-white mb-4 font-display">
              JOGOS
              <br />
              <span className="text-green-400">SATC</span>
            </h1>
          {configuracoes && <div className="mb-6 inline-block border border-green-400/40 bg-black/40 px-4 py-3 text-sm text-slate-200">
            <strong className="text-green-400">Período de inscrições:</strong>{" "}
            {configuracoes.inscricoesAbertasEm ? new Date(configuracoes.inscricoesAbertasEm).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "imediato"}
            {configuracoes.inscricoesFechaEm ? ` até ${new Date(configuracoes.inscricoesFechaEm).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}` : ""}
          </div>}
            <p className="text-lg text-slate-300 max-w-xl mb-8 leading-relaxed">
              O campeonato interturmas da escola. Varios esportes, varias turmas. Inscreva-se e
              acompanhe os jogos em tempo real.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                to="/inscricao"
                className={`px-8 py-4 font-black text-lg uppercase tracking-wider transition-colors ${configuracoes?.status === "abertas" || !configuracoes ? "bg-green-500 text-black hover:bg-green-400" : "bg-slate-700 text-slate-300"}`}
              >
                {configuracoes?.status === "em_breve" ? "Inscrições em breve" : configuracoes?.status === "encerradas" ? "Inscrições encerradas" : configuracoes?.status === "bloqueadas" ? "Inscrições bloqueadas" : "Inscrever agora"}
              </Link>
              <Link
                to="/jogos"
                className="px-8 py-4 border border-slate-500 text-slate-200 font-bold text-lg uppercase tracking-wider hover:border-white hover:text-white transition-colors"
              >
                Ver jogos
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 border-t border-line bg-bg/80 backdrop-blur">
          <div className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-2 md:grid-cols-4 divide-x divide-line">
            {[
              { value: esportes ? String(esportes.length) : "-", label: "Esportes" },
              { value: turmas ? String((Array.isArray(turmas) ? turmas : []).filter((t) => t.ativo).length) : "-", label: "Turmas Ativas" },
              { value: String(totalInscritos), label: "Inscritos" },
              { value: jogosHoje ? String(jogosHoje.length) : "-", label: "Jogos Hoje" },
            ].map((s) => (
              <div key={s.label} className="text-center px-4 py-2">
                <div className="font-black text-3xl text-green-400 font-display">{s.value}</div>
                <div className="text-xs text-slate-500 uppercase tracking-widest font-mono">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="home-games-section max-w-7xl mx-auto px-4 py-20">
        <div className="flex items-baseline gap-4 mb-12">
          <span className="font-mono text-green-400 text-xs tracking-[0.2em]">01</span>
          <h2 className="font-black text-5xl uppercase font-display">JOGOS DE HOJE</h2>
        </div>
        {erro && <p className="text-red-400 text-sm">{erro}</p>}
        {!jogosHoje ? (
          <Loading />
        ) : jogosHoje.length === 0 ? (
          <div className="border border-line p-10 text-center text-slate-500 font-mono text-sm">
            Nenhum jogo agendado para hoje.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {jogosHoje.map((j) => (
              <div key={j.id} className="border border-line p-5">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-xl">{j.esporte.icone} {j.esporte.nome}</span>
                  <JogoStatusBadge status={j.status} />
                </div>
                <div className="font-black text-xl font-display uppercase mb-1">
                  {j.timeA.label} <span className="text-slate-500">vs</span> {j.timeB.label}
                </div>
                <div className="text-xs text-slate-500 font-mono">
                  {j.hora} - {j.local}
                </div>
                {j.status === "finalizado" && (
                  <div className="mt-2 text-green-400 font-black text-2xl font-display">
                    {j.placarA} - {j.placarB}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 text-center">
          <Link
            to="/inscricao"
            className="inline-block px-10 py-4 bg-green-500 text-black font-black text-lg uppercase tracking-wider hover:bg-green-400 transition-colors"
          >
            Garantir minha vaga
          </Link>
        </div>
      </section>
    </div>
  );
}
