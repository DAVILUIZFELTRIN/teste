import { useEffect, useMemo, useState } from "react";
import { dataHojeBrasilia } from "../utils/data.js";
import { useSearchParams } from "react-router-dom";
import { api } from "../api.js";
import { SectionHeader, Loading, ErrorBox, JogoStatusBadge } from "../components/UI.jsx";

const TABS = [
  { id: "hoje", label: "Hoje" },
  { id: "proximos", label: "Proximos" },
  { id: "realizados", label: "Realizados" },
  { id: "classificacao", label: "Classificacao" },
];

export default function JogosPage() {
  const [params, setParams] = useSearchParams();
  const esporteId = params.get("esporteId") || "";
  const [esportes, setEsportes] = useState([]);
  const [tab, setTab] = useState("hoje");
  const [jogos, setJogos] = useState(null);
  const [classificacao, setClassificacao] = useState(null);
  const [erro, setErro] = useState("");

  useEffect(() => {
    api.getEsportes().then(setEsportes).catch(() => {});
  }, []);

  useEffect(() => {
    setErro("");
    if (tab === "classificacao") {
      if (!esporteId) { setClassificacao(null); return; }
      api.getClassificacao(esporteId).then(setClassificacao).catch((e) => setErro(e.message));
      return;
    }
    const query = esporteId ? { esporteId } : {};
    if (tab === "hoje") query.data = dataHojeBrasilia();
    if (tab === "realizados") query.status = "finalizado";
    api.getJogos(query).then((all) => {
      let filtered = all;
      if (tab === "proximos") {
        filtered = all.filter((j) => j.status === "agendado");
      }
      setJogos(filtered);
    }).catch((e) => setErro(e.message));
  }, [tab, esporteId]);

  const esporteAtual = useMemo(() => esportes.find((e) => String(e.id) === esporteId), [esportes, esporteId]);

  return (
    <div className="pt-14 max-w-7xl mx-auto px-4 py-12">
      <SectionHeader eyebrow="02" title="JOGOS" />

      <div className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setParams(esporteId ? {} : {})}
          className={`px-3 py-1.5 text-xs font-mono uppercase tracking-widest rounded-sm border ${
            !esporteId ? "border-green-500 text-green-400 bg-green-500/10" : "border-line text-slate-400 hover:text-white"
          }`}
        >
          Todos
        </button>
        {esportes.map((e) => (
          <button
            key={e.id}
            onClick={() => setParams({ esporteId: String(e.id) })}
            className={`px-3 py-1.5 text-xs font-mono uppercase tracking-widest rounded-sm border ${
              esporteId === String(e.id)
                ? "border-green-500 text-green-400 bg-green-500/10"
                : "border-line text-slate-400 hover:text-white"
            }`}
          >
            {e.icone} {e.nome}
          </button>
        ))}
      </div>

      <div className="flex gap-1 mb-8 border-b border-line">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm font-semibold uppercase tracking-widest border-b-2 -mb-px transition-colors ${
              tab === t.id ? "border-green-400 text-green-400" : "border-transparent text-slate-500 hover:text-slate-200"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <ErrorBox message={erro} />

      {tab === "classificacao" ? (
        !esporteId ? (
          <div className="border border-line p-10 text-center text-slate-500 font-mono text-sm">
            Selecione um esporte acima para ver a tabela de pontos.
          </div>
        ) : !classificacao ? (
          <Loading />
        ) : classificacao?.tipo === "individual" ? (
          <div className="border border-line p-5">
            <p className="text-green-400 text-xs font-mono uppercase tracking-widest mb-3">
              Resultados individuais · {classificacao.esporte}
            </p>
            <div className="space-y-2">
              {(classificacao.resultados || []).map((r, i) => (
                <div key={`${r.participante}-${i}`} className="flex items-center gap-4 border-b border-line py-3">
                  <strong className="text-green-400 font-display text-xl w-10">{r.colocacao}º</strong>
                  <span className="font-bold uppercase">{r.participante}</span>
                  <span className="text-slate-500 text-sm">{r.turma}</span>
                  <span className="ml-auto text-slate-300 text-sm">{r.resultado}</span>
                </div>
              ))}
              {!classificacao.resultados?.length && <p className="text-slate-500">Ainda não há resultados individuais finalizados.</p>}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto border border-line">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-slate-500 font-mono uppercase text-xs">
                  <th className="text-left px-4 py-3">#</th>
                  <th className="text-left px-4 py-3">Turma</th>
                  <th className="px-3 py-3">P</th>
                  <th className="px-3 py-3">J</th>
                  <th className="px-3 py-3">V</th>
                  <th className="px-3 py-3">E</th>
                  <th className="px-3 py-3">D</th>
                  <th className="px-3 py-3">SG</th>
                </tr>
              </thead>
              <tbody>
                {classificacao.map((r, i) => (
                  <tr key={r.timeId} className="border-b border-line last:border-0">
                    <td className="px-4 py-3 text-slate-500 font-mono">{i + 1}</td>
                    <td className="px-4 py-3 font-bold uppercase font-display text-lg">{r.turma}</td>
                    <td className="px-3 py-3 text-center text-green-400 font-black">{r.pontos}</td>
                    <td className="px-3 py-3 text-center text-slate-400">{r.jogos}</td>
                    <td className="px-3 py-3 text-center text-slate-400">{r.vitorias}</td>
                    <td className="px-3 py-3 text-center text-slate-400">{r.empates}</td>
                    <td className="px-3 py-3 text-center text-slate-400">{r.derrotas}</td>
                    <td className="px-3 py-3 text-center text-slate-400">{r.saldoGols}</td>
                  </tr>
                ))}
                {classificacao.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-10 text-center text-slate-500 font-mono text-sm">
                      Ainda nao ha times cadastrados neste esporte.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )
      ) : !jogos ? (
        <Loading />
      ) : jogos.length === 0 ? (
        <div className="border border-line p-10 text-center text-slate-500 font-mono text-sm">
          Nenhum jogo encontrado.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {jogos.map((j) => (
            <div key={j.id} className="border border-line p-5">
              <div className="flex justify-between items-center mb-3">
                <span className="text-lg">{j.esporte.icone} {j.esporte.nome}</span>
                <JogoStatusBadge status={j.status} />
              </div>
              <div className="font-black text-xl font-display uppercase mb-1">
                {j.timeA.label} <span className="text-slate-500">vs</span> {j.timeB.label}
              </div>
              <div className="text-xs text-slate-500 font-mono mb-2">
                {j.data} - {j.hora} - {j.local} - {j.fase}
              </div>
              {j.status === "finalizado" && (
                <div className="text-green-400 font-black text-2xl font-display">
                  {j.placarA} - {j.placarB}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
