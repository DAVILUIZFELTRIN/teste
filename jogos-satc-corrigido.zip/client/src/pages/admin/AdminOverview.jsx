import { useEffect, useState } from "react";
import { api } from "../../api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { Loading, ErrorBox } from "../../components/UI.jsx";

function localInputValue(value) {
  if (!value) return "";
  const date = new Date(value);
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function isoValue(value) { return value ? new Date(value).toISOString() : null; }

export default function AdminOverview() {
  const { token } = useAuth();
  const [stats, setStats] = useState(null);
  const [config, setConfig] = useState(null);
  const [relatorio, setRelatorio] = useState(null);
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [mensagem, setMensagem] = useState("");
  const [confirmacaoBloqueio, setConfirmacaoBloqueio] = useState(false);

  async function carregar() {
    try {
      const [dashboard, configuracoes] = await Promise.all([api.getDashboard(token), api.getConfiguracoes()]);
      setStats(dashboard);
      setConfig({ abertura: localInputValue(configuracoes.inscricoesAbertasEm), encerramento: localInputValue(configuracoes.inscricoesFechaEm), status: configuracoes.status, bloqueada: configuracoes.inscricoesBloqueadas });
    } catch (e) { setErro(e.message); }
  }
  useEffect(() => { carregar(); }, [token]);

  async function salvarPeriodo(e) {
    e.preventDefault(); setSalvando(true); setErro(""); setMensagem("");
    try {
      const atual = await api.salvarConfiguracoes(token, { inscricoesAbertasEm: isoValue(config.abertura), inscricoesFechaEm: isoValue(config.encerramento), inscricoesBloqueadas: config.bloqueada });
      setConfig({ abertura: localInputValue(atual.inscricoesAbertasEm), encerramento: localInputValue(atual.inscricoesFechaEm), status: atual.status, bloqueada: atual.inscricoesBloqueadas });
      setMensagem("Período de inscrições atualizado.");
    } catch (e) { setErro(e.message); } finally { setSalvando(false); }
  }
  async function alternarBloqueio() {
    setSalvando(true); setErro(""); setMensagem("");
    try {
      const atual = await api.salvarConfiguracoes(token, { inscricoesAbertasEm: isoValue(config.abertura), inscricoesFechaEm: isoValue(config.encerramento), inscricoesBloqueadas: !config.bloqueada });
      setConfig({ abertura: localInputValue(atual.inscricoesAbertasEm), encerramento: localInputValue(atual.inscricoesFechaEm), status: atual.status, bloqueada: atual.inscricoesBloqueadas });
      setMensagem(atual.inscricoesBloqueadas ? "Inscrições bloqueadas manualmente." : "Inscrições liberadas novamente.");
    } catch (e) { setErro(e.message); } finally { setSalvando(false); }
  }
  function solicitarAlteracaoBloqueio() {
    setErro("");
    setConfirmacaoBloqueio(true);
  }
  function imprimirRelatorio() {
    document.body.classList.add("printing-report");
    const fim = () => { document.body.classList.remove("printing-report"); window.removeEventListener("afterprint", fim); };
    window.addEventListener("afterprint", fim);
    window.print();
  }

  async function abrirRelatorio() {
    try { setRelatorio(await api.getRelatorio(token)); } catch (e) { setErro(e.message); }
  }

  if (erro && !stats) return <ErrorBox message={erro} />;
  if (!stats || !config) return <Loading />;
  const inscricoesPorStatus = Array.isArray(stats.inscricoesPorStatus) ? stats.inscricoesPorStatus : [];
  const cards = [
    ["Inscritos", stats.totalInscritos], ["Pagamentos confirmados", inscricoesPorStatus.find((s) => s.status === "confirmado")?.n || 0],
    ["Pagamentos pendentes", inscricoesPorStatus.find((s) => s.status === "pendente")?.n || 0], ["Arrecadado", `R$ ${Number(stats.arrecadado ?? 0).toFixed(2)}`],
    ["Jogos hoje", stats.jogosHoje], ["Jogos finalizados", `${stats.jogosFinalizados}/${stats.jogosTotal}`], ["Turmas ativas", stats.turmasAtivas], ["Esportes ativos", stats.esportesAtivos],
  ];
  return <div className="space-y-6">
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">{cards.map(([label, value]) => <div key={label} className="border border-line p-5"><div className="font-black text-3xl text-green-400 font-display">{value}</div><div className="text-xs text-slate-500 uppercase tracking-widest font-mono mt-1">{label}</div></div>)}</div>
    <section className="border border-line p-5">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4"><div><p className="text-green-400 text-xs font-mono uppercase tracking-widest">Controle de inscrições</p><h2 className="font-black text-2xl uppercase font-display">Período e acesso público</h2><p className="text-sm text-slate-500 mt-1">Fora do período ou com o bloqueio manual ativo, o formulário e o servidor recusam novas inscrições.</p></div><span className={`px-3 py-2 text-xs font-mono uppercase ${config.bloqueada ? "bg-red-500/15 text-red-300" : "bg-green-500/10 text-green-400"}`}>{config.bloqueada ? "bloqueadas manualmente" : config.status.replace("_", " ")}</span></div>
      <form onSubmit={salvarPeriodo} className="grid md:grid-cols-3 gap-3 items-end"><label className="label">Abertura<input type="datetime-local" className="input mt-2" value={config.abertura} onChange={(e) => setConfig({ ...config, abertura: e.target.value })} /></label><label className="label">Encerramento<input type="datetime-local" className="input mt-2" value={config.encerramento} onChange={(e) => setConfig({ ...config, encerramento: e.target.value })} /></label><button disabled={salvando} className="py-3 bg-green-500 text-black font-black uppercase disabled:opacity-50">{salvando ? "Salvando..." : "Salvar período"}</button></form>
      <button type="button" onClick={solicitarAlteracaoBloqueio} disabled={salvando} className={`mt-4 w-full md:w-auto px-5 py-3 font-black uppercase border-2 disabled:opacity-50 ${config.bloqueada ? "border-green-400 text-green-300 hover:bg-green-500/10" : "border-red-400 text-red-300 hover:bg-red-500/10"}`}>{config.bloqueada ? "Liberar novas inscrições" : "Bloquear novas inscrições agora"}</button>
      {mensagem && <p className="text-green-400 text-sm mt-3">{mensagem}</p>}{erro && <ErrorBox message={erro} />}
    </section>
    <section className="report-print border border-line p-5"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-green-400 text-xs font-mono uppercase tracking-widest">Etapa 4</p><h2 className="font-black text-2xl uppercase font-display">Relatório final</h2><p className="text-sm text-slate-500 mt-1">Resumo de campeões, inscrições, modalidades e jogos para conferência.</p></div><div className="no-print flex flex-wrap gap-2"><button onClick={abrirRelatorio} className="px-5 py-3 border border-green-500 text-green-400 font-black uppercase">{relatorio ? "Atualizar relatório" : "Gerar relatório"}</button>{relatorio && <button onClick={imprimirRelatorio} className="px-5 py-3 border border-line font-black uppercase">Imprimir / salvar PDF</button>}</div></div>{relatorio && <div className="grid md:grid-cols-2 gap-5 mt-5"><ReportList title="Inscrições por status" rows={relatorio.status} label="status" value="total" /><ReportList title="Inscritos por esporte" rows={relatorio.esportes} label="nome" value="inscritos" /><div className="md:col-span-2"><h3 className="font-bold uppercase font-display mb-2">Campeões / líderes por esporte</h3>{(relatorio.campeoes || []).length === 0 && <p className="text-sm text-slate-500">Nenhum jogo de equipe com resultado ainda.</p>}<div className="space-y-1">{(relatorio.campeoes || []).map((c) => <div key={c.esporte} className="flex justify-between gap-3 border-b border-line py-2 text-sm"><span className="text-slate-400">{c.esporte}</span><strong className="text-green-400 text-right">{c.turma} · {c.pontos} pts · {c.definitivo ? "campeã" : `líder (faltam ${c.jogosRestantes} jogo(s))`}</strong></div>)}</div></div><ReportList title="Arrecadação" rows={relatorio.arrecadacao ? [{ nome: `Confirmado (${relatorio.arrecadacao.inscricoesConfirmadas} inscrições)`, total: `R$ ${Number(relatorio.arrecadacao.confirmado).toFixed(2)}` }, { nome: `Pendente (${relatorio.arrecadacao.inscricoesPendentes} inscrições)`, total: `R$ ${Number(relatorio.arrecadacao.pendente).toFixed(2)}` }] : []} label="nome" value="total" /><ReportList title="Artilharia" rows={(relatorio.artilharia || []).map((r) => ({ nome: `${r.nome} (${r.esporte})`, total: r.total }))} label="nome" value="total" /><ReportList title="Cartões" rows={(relatorio.cartoes || []).map((r) => ({ nome: `${r.nome} — ${r.detalhe}`, total: r.total }))} label="nome" value="total" /></div>}</section>
    {confirmacaoBloqueio && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && setConfirmacaoBloqueio(false)}>
      <div className="w-full max-w-lg border border-line bg-bg p-6 shadow-2xl" role="dialog" aria-modal="true" aria-labelledby="confirmacao-bloqueio-titulo">
        <p className="text-green-400 text-xs font-mono uppercase tracking-widest">Confirmação necessária</p>
        <h2 id="confirmacao-bloqueio-titulo" className="font-black text-3xl uppercase font-display mt-2">{config.bloqueada ? "Liberar inscrições?" : "Bloquear inscrições?"}</h2>
        <p className="text-slate-300 mt-3 leading-relaxed">{config.bloqueada ? "Os alunos poderão enviar novas inscrições novamente assim que você confirmar." : "Novos alunos não conseguirão concluir inscrições enquanto o bloqueio estiver ativo. O período e as inscrições já existentes não serão alterados."}</p>
        <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 mt-6">
          <button type="button" onClick={() => setConfirmacaoBloqueio(false)} className="px-5 py-3 border border-slate-500 text-slate-200 font-black uppercase hover:border-white">Cancelar</button>
          <button type="button" onClick={() => { setConfirmacaoBloqueio(false); alternarBloqueio(); }} className={`px-5 py-3 font-black uppercase ${config.bloqueada ? "bg-green-500 text-black hover:bg-green-400" : "bg-red-500 text-white hover:bg-red-400"}`}>{config.bloqueada ? "Sim, liberar inscrições" : "Sim, bloquear inscrições"}</button>
        </div>
      </div>
    </div>}
  </div>;
}
function ReportList({ title, rows, label, value }) { return <div><h3 className="font-bold uppercase font-display mb-2">{title}</h3><div className="space-y-1">{rows.map((row, i) => <div key={`${row[label]}-${i}`} className="flex justify-between border-b border-line py-2 text-sm"><span className="text-slate-400 capitalize">{row[label]}</span><strong className="text-green-400">{row[value]}</strong></div>)}</div></div>; }
