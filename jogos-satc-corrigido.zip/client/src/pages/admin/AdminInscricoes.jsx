import { useEffect, useMemo, useState } from "react";
import { api } from "../../api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { Loading, ErrorBox, StatusBadge } from "../../components/UI.jsx";

function anoDaTurma(label = "") {
  const match = String(label).match(/^(\d+)/);
  return match ? Number(match[1]) : 99;
}

function tituloAno(ano) {
  return ano >= 1 && ano <= 3 ? `${ano}º ano do Ensino Médio` : `${ano}º ano`;
}

export default function AdminInscricoes() {
  const { token } = useAuth();
  const [inscricoes, setInscricoes] = useState(null);
  const [turmas, setTurmas] = useState(null);
  const [filtro, setFiltro] = useState("");
  const [busca, setBusca] = useState("");
  const [categoriaSelecionada, setCategoriaSelecionada] = useState(null);
  const [anoSelecionado, setAnoSelecionado] = useState(null);
  const [turmaSelecionada, setTurmaSelecionada] = useState(null);
  const [tabelaGeral, setTabelaGeral] = useState(false);
  const [modoEsportes, setModoEsportes] = useState(false);
  const [esporteSelecionado, setEsporteSelecionado] = useState("");
  const [erro, setErro] = useState("");

  function carregar() {
    setErro("");
    Promise.all([api.listarInscricoes(token, filtro || undefined), api.getTurmas(true)])
      .then(([lista, listaTurmas]) => { setInscricoes(Array.isArray(lista) ? lista : []); setTurmas(Array.isArray(listaTurmas) ? listaTurmas : []); })
      .catch((e) => setErro(e.message));
  }
  useEffect(carregar, [filtro]);

  async function mudarStatus(id, status) {
    try { await api.atualizarPagamento(token, id, status); carregar(); } catch (err) { setErro(err.message); }
  }

  function voltarPara(nivel) {
    if (nivel === "categorias") { setCategoriaSelecionada(null); setAnoSelecionado(null); setTurmaSelecionada(null); setTabelaGeral(false); setModoEsportes(false); setEsporteSelecionado(""); }
    if (nivel === "anos") { setAnoSelecionado(null); setTurmaSelecionada(null); }
    if (nivel === "turmas") setTurmaSelecionada(null);
  }

  const porBusca = (i) => {
    const q = busca.trim().toLowerCase();
    return !q || String(i.nome || "").toLowerCase().includes(q) || String(i.matricula || "").toLowerCase().includes(q) || String(i.codigo || "").toLowerCase().includes(q);
  };

  const turmasAtivas = useMemo(() => (turmas || []).filter((t) => t.ativo !== false), [turmas]);
  const inscricoesVisiveis = useMemo(() => (inscricoes || []).filter(porBusca), [inscricoes, busca]);
  const categorias = useMemo(() => {
    const map = new Map();
    turmasAtivas.forEach((turma) => {
      const cat = turma.categoria || { id: turma.categoria_id, nome: "Sem categoria" };
      if (!map.has(cat.id)) map.set(cat.id, { ...cat, turmas: [] });
      map.get(cat.id).turmas.push(turma);
    });
    return [...map.values()].sort((a, b) => a.id - b.id);
  }, [turmasAtivas]);
  const categoria = categorias.find((item) => String(item.id) === String(categoriaSelecionada));
  const anos = useMemo(() => {
    if (!categoria) return [];
    const map = new Map();
    categoria.turmas.forEach((turma) => { const ano = anoDaTurma(turma.label); if (!map.has(ano)) map.set(ano, []); map.get(ano).push(turma); });
    return [...map.entries()].sort((a, b) => a[0] - b[0]).map(([ano, lista]) => ({ ano, turmas: lista.sort((a, b) => a.label.localeCompare(b.label, "pt-BR")) }));
  }, [categoria]);
  const ano = anos.find((item) => item.ano === anoSelecionado);
  const turma = ano?.turmas.find((item) => String(item.id) === String(turmaSelecionada));
  const inscricoesPorEsporte = (lista) => esporteSelecionado ? lista.filter((i) => (i.esportes || []).some((esporte) => String(esporte.id) === String(esporteSelecionado))) : lista;
  const listaDaTurma = turma ? inscricoesVisiveis.filter((i) => Number(i.turma_id) === Number(turma.id)) : [];
  const esportesDaTurma = useMemo(() => { const map = new Map(); listaDaTurma.forEach((i) => (i.esportes || []).forEach((esporte) => { if (!map.has(String(esporte.id))) map.set(String(esporte.id), { id: esporte.id, nome: esporte.nome, icone: esporte.icone }); })); return [...map.values()].sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR")); }, [listaDaTurma]);
  const listaDaTurmaPorEsporte = inscricoesPorEsporte(listaDaTurma);
  const inscricoesDaCategoria = categoria ? inscricoesVisiveis.filter((i) => categoria.turmas.some((item) => Number(item.id) === Number(i.turma_id))) : inscricoesVisiveis;
  const esportesDisponiveis = useMemo(() => { const map = new Map(); inscricoesDaCategoria.forEach((i) => (i.esportes || []).forEach((esporte) => { if (!map.has(String(esporte.id))) map.set(String(esporte.id), { id: esporte.id, nome: esporte.nome, icone: esporte.icone }); })); return [...map.values()].sort((a,b) => a.nome.localeCompare(b.nome, "pt-BR")); }, [inscricoesDaCategoria]);
  const listaPorEsporte = inscricoesPorEsporte(inscricoesDaCategoria);
  const listaGeral = inscricoesVisiveis.map((i) => ({ ...i, turmaLabel: turmasAtivas.find((item) => Number(item.id) === Number(i.turma_id))?.label || "Turma não identificada" }));
  const countTurma = (id) => inscricoesVisiveis.filter((i) => Number(i.turma_id) === Number(id)).length;

  return <div>
    <ErrorBox message={erro} />
    <div className="flex flex-wrap gap-3 mb-5">
      <input className="input max-w-xs" placeholder="Buscar por nome, matrícula ou código" value={busca} onChange={(e) => setBusca(e.target.value)} />
      <div className="flex gap-2 text-xs font-mono uppercase tracking-widest flex-wrap">
        {["", "pendente", "confirmado", "cancelado"].map((s) => <button key={s} onClick={() => setFiltro(s)} className={`px-3 py-1.5 rounded-sm border ${filtro === s ? "border-green-500 text-green-400 bg-green-500/10" : "border-line text-slate-400"}`}>{s || "Todos"}</button>)}
      </div>
    </div>

    {!inscricoes || !turmas ? <Loading /> : <>
      <div className="registration-breadcrumb mb-5">
        {(categoria || tabelaGeral) && <button onClick={() => voltarPara("categorias")} className="registration-back-home" aria-label="Voltar para a página inicial das inscrições">← <span>Voltar para inscrições</span></button>}
        {tabelaGeral && <><span>/</span><strong>Todas as inscrições</strong></>}
        {categoria && !tabelaGeral && <><span>/</span><button onClick={() => voltarPara("anos")} className={!ano ? "current" : ""}>{categoria.nome}</button></>}
        {ano && <><span>/</span><button onClick={() => voltarPara("turmas")} className={!turma ? "current" : ""}>{tituloAno(ano.ano)}</button></>}
        {turma && <><span>/</span><strong>{turma.label}</strong></>}
      </div>

      {!categoria && !tabelaGeral && <section><div className="registration-section-heading"><div><span className="eyebrow">01 · Organização</span><h3>Escolha a categoria</h3><p>Selecione o grupo de anos para visualizar as turmas.</p></div><span className="registration-total">{inscricoesVisiveis.length} inscrições</span></div><button className="registration-all-button mb-4" onClick={() => { setTabelaGeral(true); setModoEsportes(false); setEsporteSelecionado(""); }}><span>☷</span><span><b>Ver todas as inscrições</b><small>Lista geral de todas as turmas e categorias</small></span><strong>→</strong></button><div className="registration-card-grid">{categorias.map((cat) => <button key={cat.id} className="registration-nav-card" onClick={() => { setCategoriaSelecionada(cat.id); setAnoSelecionado(null); setTurmaSelecionada(null); setModoEsportes(false); setEsporteSelecionado(""); }}><span className="registration-card-icon">▦</span><span><b>{cat.nome}</b><small>{cat.turmas.length} turmas · {cat.turmas.reduce((total, item) => total + countTurma(item.id), 0)} inscrições</small></span><strong>→</strong></button>)}</div>{!categorias.length && <Empty text="Nenhuma categoria de turma encontrada." />}</section>}

      {tabelaGeral && !modoEsportes && <section><div className="registration-section-heading"><div><span className="eyebrow">01 · Visão geral</span><h3>Todas as inscrições</h3><p>Lista consolidada de todas as turmas, com a sala identificada em cada linha.</p></div><span className="registration-total">{listaGeral.length} registros</span></div><button className="registration-filter-link" onClick={() => { setModoEsportes(true); setEsporteSelecionado(""); }}>⚽ Ver inscrições por esporte</button><InscriptionTable rows={listaGeral} mudarStatus={mudarStatus} showTurma /></section>}

      {tabelaGeral && modoEsportes && <section><div className="registration-section-heading"><div><span className="eyebrow">01 · Filtro geral</span><h3>Inscrições por esporte</h3><p>Escolha uma modalidade para ver somente seus alunos inscritos.</p></div><span className="registration-total">{listaPorEsporte.length} registros</span></div>{esporteSelecionado ? <InscriptionTable rows={listaPorEsporte.map((i) => ({ ...i, turmaLabel: turmasAtivas.find((item) => Number(item.id) === Number(i.turma_id))?.label || "Turma não identificada" }))} mudarStatus={mudarStatus} showTurma /> : <SportChooser esportes={esportesDisponiveis} onSelect={setEsporteSelecionado} />}</section>}

      {categoria && !ano && !modoEsportes && <section><div className="registration-section-heading"><div><span className="eyebrow">02 · Categoria selecionada</span><h3>Escolha o ano</h3><p>Agora selecione o ano para abrir suas turmas.</p></div><span className="registration-total">{categoria.turmas.length} turmas</span></div><button className="registration-filter-link" onClick={() => { setModoEsportes(true); setEsporteSelecionado(""); }}>⚽ Ver inscrições desta categoria por esporte</button><div className="registration-card-grid">{anos.map((item) => <button key={item.ano} className="registration-nav-card" onClick={() => { setAnoSelecionado(item.ano); setTurmaSelecionada(null); }}><span className="registration-card-icon">{item.ano}</span><span><b>{tituloAno(item.ano)}</b><small>{item.turmas.length} turmas · {item.turmas.reduce((total, t) => total + countTurma(t.id), 0)} inscrições</small></span><strong>→</strong></button>)}</div></section>}

      {categoria && !ano && modoEsportes && <section><div className="registration-section-heading"><div><span className="eyebrow">02 · Filtro da categoria</span><h3>Inscrições por esporte</h3><p>Veja os alunos inscritos em uma modalidade dentro de {categoria.nome}.</p></div><span className="registration-total">{listaPorEsporte.length} registros</span></div>{esporteSelecionado ? <InscriptionTable rows={listaPorEsporte} mudarStatus={mudarStatus} /> : <SportChooser esportes={esportesDisponiveis} onSelect={setEsporteSelecionado} />}</section>}

      {categoria && ano && !turma && <section><div className="registration-section-heading"><div><span className="eyebrow">03 · {tituloAno(ano.ano)}</span><h3>Escolha a turma</h3><p>Clique na sala para abrir a lista de inscrições.</p></div><span className="registration-total">{ano.turmas.length} turmas</span></div><div className="registration-class-grid">{ano.turmas.map((item) => <button key={item.id} className="registration-class-card" onClick={() => { setTurmaSelecionada(item.id); setModoEsportes(false); setEsporteSelecionado(""); }}><span className="class-room">{item.label.match(/[A-Z]$/)?.[0] || "•"}</span><span><b>{item.label}</b><small>{countTurma(item.id)} inscrição(ões)</small></span><strong>→</strong></button>)}</div></section>}

      {turma && !modoEsportes && <section><div className="registration-section-heading"><div><span className="eyebrow">04 · Lista da sala</span><h3>Inscrições — {turma.label}</h3><p>Todos os alunos exibidos pertencem a esta turma.</p></div><span className="registration-total">{listaDaTurma.length} registros</span></div><button className="registration-filter-link" onClick={() => { setModoEsportes(true); setEsporteSelecionado(""); }}>⚽ Ver inscrições desta turma por esporte</button><InscriptionTable rows={listaDaTurma} mudarStatus={mudarStatus} /></section>}
      {turma && modoEsportes && <section><div className="registration-section-heading"><div><span className="eyebrow">04 · Filtro da sala</span><h3>Inscrições por esporte — {turma.label}</h3><p>Escolha uma modalidade para ver somente os alunos inscritos desta turma.</p></div><span className="registration-total">{listaDaTurmaPorEsporte.length} registros</span></div>{esporteSelecionado ? <InscriptionTable rows={listaDaTurmaPorEsporte} mudarStatus={mudarStatus} /> : <SportChooser esportes={esportesDaTurma} onSelect={setEsporteSelecionado} />}</section>}
    </>}
  </div>;
}

function SportChooser({ esportes, onSelect }) {
  if (!esportes.length) return <Empty text="Nenhum esporte encontrado nas inscrições deste grupo." />;
  return <div className="registration-sport-grid">{esportes.map((esporte) => <button key={esporte.id} className="registration-sport-card" onClick={() => onSelect(String(esporte.id))}><span>{esporte.icone || "🏆"}</span><b>{esporte.nome}</b><strong>→</strong></button>)}</div>;
}

function Empty({ text }) { return <div className="border border-line p-10 text-center text-slate-500 font-mono text-sm">{text}</div>; }

function InscriptionTable({ rows, mudarStatus, showTurma = false }) {
  return <div className="registration-table-wrap overflow-x-auto border border-line"><table className={`registration-table w-full text-sm ${showTurma ? "registration-table-general" : ""}`}><thead><tr className="border-b border-line text-slate-500 font-mono uppercase text-xs"><th className="text-left px-4 py-3">Código</th><th className="text-left px-4 py-3">Aluno</th>{showTurma && <th className="text-left px-4 py-3">Turma</th>}<th className="text-left px-4 py-3">Matrícula</th><th className="text-left px-4 py-3">Esportes</th><th className="px-3 py-3">Valor</th><th className="px-3 py-3">Status</th><th className="px-3 py-3">Ações</th></tr></thead><tbody>{rows.map((i) => <tr key={i.id} className={`border-b border-line last:border-0 ${i.status_pagamento === "pendente" ? "registration-row-pending" : ""}`}><td className="px-4 py-3 font-mono text-xs text-slate-400">{i.codigo}</td><td className="px-4 py-3 font-semibold">{i.nome}</td>{showTurma && <td className="px-4 py-3 text-slate-400">{i.turmaLabel}</td>}<td className="px-4 py-3 text-slate-400">{i.matricula}</td><td className="px-4 py-3 text-slate-400 text-xs">{(i.esportes || []).map((s) => s.nome).join(", ")}</td><td className="px-3 py-3 text-center">R$ {Number(i.valor ?? 0).toFixed(2)}</td><td className="px-3 py-3 text-center registration-status-cell"><StatusBadge status={i.status_pagamento} /></td><td className="px-3 py-3 text-center whitespace-nowrap">{i.status_pagamento !== "confirmado" && <button onClick={() => mudarStatus(i.id, "confirmado")} className="text-green-400 hover:text-green-300 text-xs font-mono uppercase mr-2">Confirmar</button>}{i.status_pagamento !== "cancelado" && <button onClick={() => mudarStatus(i.id, "cancelado")} className="text-red-400 hover:text-red-300 text-xs font-mono uppercase">Cancelar</button>}</td></tr>)}{rows.length === 0 && <tr><td colSpan={showTurma ? 8 : 7} className="px-4 py-10 text-center text-slate-500 font-mono text-sm">Nenhuma inscrição encontrada nesta turma.</td></tr>}</tbody></table></div>;
}
