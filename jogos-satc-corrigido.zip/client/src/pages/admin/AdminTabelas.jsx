import { useEffect, useMemo, useState } from "react";
import { api } from "../../api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { ErrorBox, Loading } from "../../components/UI.jsx";
import { dataHojeBrasilia } from "../../utils/data.js";

// ---------- Regras de montagem da tabela ----------

// Embaralha com uma "semente" (a mesma semente sempre dá a mesma ordem; trocar a semente sorteia de novo).
function embaralhar(lista, semente) {
  let estado = semente || 1;
  const aleatorio = () => { estado = (estado * 1664525 + 1013904223) % 4294967296; return estado / 4294967296; };
  const copia = [...lista];
  for (let i = copia.length - 1; i > 0; i -= 1) {
    const j = Math.floor(aleatorio() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

// Todos contra todos (método do círculo). Cada rodada tem times diferentes em cada jogo.
function rodizio(times) {
  const lista = [...times];
  if (lista.length % 2) lista.push(null); // folga
  const rodadas = [];
  for (let r = 0; r < lista.length - 1; r += 1) {
    const jogos = Array.from({ length: lista.length / 2 }, (_, i) => ({ a: lista[i], b: lista[lista.length - 1 - i] })).filter((j) => j.a && j.b);
    rodadas.push({ fase: `Rodada ${r + 1}`, jogos });
    const fixo = lista[0];
    const resto = lista.slice(1);
    resto.unshift(resto.pop());
    lista.splice(0, lista.length, fixo, ...resto);
  }
  return rodadas;
}

const ORDEM_FASES = ["Fase preliminar", "Oitavas de final", "Quartas de final", "Semifinal", "Final"];

// Nome da fase conforme a quantidade de times que ainda disputam.
function nomeDaFase(qtdTimes) {
  if (qtdTimes <= 2) return "Final";
  if (qtdTimes <= 4) return "Semifinal";
  if (qtdTimes <= 8) return "Quartas de final";
  if (qtdTimes <= 16) return "Oitavas de final";
  return `Fase de ${qtdTimes}`;
}

// Mata-mata. Se a quantidade não for potência de 2, faz uma fase preliminar só com os times necessários
// e os demais ficam com "bye" (avançam direto). Ninguém é descartado.
function chave(times) {
  const n = times.length;
  const potencia = 2 ** Math.floor(Math.log2(n));
  if (n === potencia) {
    return { rodadas: [{ fase: nomeDaFase(n), jogos: Array.from({ length: n / 2 }, (_, i) => ({ a: times[i * 2], b: times[i * 2 + 1] })) }], byes: [] };
  }
  const extras = n - potencia; // jogos da fase preliminar
  const jogando = times.slice(0, extras * 2);
  const byes = times.slice(extras * 2);
  return { rodadas: [{ fase: "Fase preliminar", jogos: Array.from({ length: extras }, (_, i) => ({ a: jogando[i * 2], b: jogando[i * 2 + 1] })) }], byes };
}

function minutos(hora) { const [h, m] = String(hora || "08:00").split(":").map(Number); return h * 60 + m; }
function formatarHora(total) { return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`; }

// Distribui os jogos em horários e quadras. Cada rodada começa num horário novo,
// então um time nunca joga duas vezes ao mesmo tempo. Várias quadras = jogos em paralelo.
function distribuir(rodadas, { hora, locais, duracao }) {
  const resultado = [];
  let slot = 0;
  for (const rodada of rodadas) {
    for (let i = 0; i < rodada.jogos.length; i += locais.length) {
      rodada.jogos.slice(i, i + locais.length).forEach((jogo, k) => {
        resultado.push({ ...jogo, fase: rodada.fase, hora: formatarHora(minutos(hora) + slot * duracao), local: locais[k] });
      });
      slot += 1;
    }
  }
  return resultado;
}

export default function AdminTabelas() {
  const { token } = useAuth();
  const [esportes, setEsportes] = useState([]);
  const [turmas, setTurmas] = useState([]);
  const [times, setTimes] = useState([]);
  const [categoriaId, setCategoriaId] = useState("");
  const [esporteId, setEsporteId] = useState("");
  const [modo, setModo] = useState("rodizio");
  const [data, setData] = useState(dataHojeBrasilia());
  const [hora, setHora] = useState("08:00");
  const [local, setLocal] = useState("Quadra 1");
  const [duracao, setDuracao] = useState(40);
  const [sortear, setSortear] = useState(true);
  const [semente, setSemente] = useState(() => Math.floor(Math.random() * 1e9) + 1);
  const [gerados, setGerados] = useState(null);
  const [byes, setByes] = useState([]);
  const [erro, setErro] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [ok, setOk] = useState("");

  useEffect(() => {
    Promise.all([api.getEsportes({ all: "1" }), api.getTurmas(true)])
      .then(([e, t]) => { setEsportes(e); setTurmas(t); if (t[0]) setCategoriaId(String(t[0].categoria_id)); })
      .catch((e) => setErro(e.message));
  }, []);

  const categorias = useMemo(() => [...new Map(turmas.map((t) => [t.categoria_id, { id: t.categoria_id, nome: t.categoria_nome }])).values()], [turmas]);
  const esportesCategoria = useMemo(() => esportes.filter((e) => e.categorias?.some((c) => String(c.id) === String(categoriaId)) && e.modalidade !== "individual"), [esportes, categoriaId]);
  const turmasCategoria = useMemo(() => turmas.filter((t) => String(t.categoria_id) === String(categoriaId)), [turmas, categoriaId]);

  useEffect(() => {
    setGerados(null); setOk("");
    if (!esporteId) { setTimes([]); return; }
    api.getTimesDoEsporte(token, esporteId)
      .then((list) => setTimes(list.filter((t) => turmasCategoria.some((turma) => String(turma.id) === String(t.turma_id)))))
      .catch((e) => setErro(e.message));
  }, [esporteId, token, categoriaId]);

  const locais = useMemo(() => local.split(",").map((l) => l.trim()).filter(Boolean), [local]);
  const parametros = { hora, locais: locais.length ? locais : ["Quadra 1"], duracao: Math.max(5, Number(duracao) || 40) };

  function finalizarPrevia(rodadas, folgas = []) {
    const lista = distribuir(rodadas, parametros);
    if (lista.length && minutos(lista[lista.length - 1].hora) >= 24 * 60 - 1) {
      setErro("Os jogos passariam da meia-noite. Reduza o intervalo, adicione quadras ou comece mais cedo.");
      return;
    }
    setByes(folgas);
    setGerados(lista);
  }

  function gerar(novaSemente) {
    if (!esporteId || times.length < 2) { setErro("Selecione um esporte com pelo menos dois times."); return; }
    if (!data) { setErro("Informe a data."); return; }
    setErro(""); setOk("");
    const ordem = sortear ? embaralhar(times, novaSemente ?? semente) : times;
    if (modo === "mata-mata") { const c = chave(ordem); finalizarPrevia(c.rodadas, c.byes); }
    else finalizarPrevia(rodizio(ordem));
  }

  function sortearDeNovo() {
    const nova = Math.floor(Math.random() * 1e9) + 1;
    setSemente(nova);
    gerar(nova);
  }

  // Próxima fase do mata-mata a partir dos vencedores da fase anterior (já finalizada).
  async function gerarProximaFase() {
    if (!esporteId) { setErro("Selecione um esporte."); return; }
    setErro(""); setOk("");
    try {
      const todos = await api.getJogos({ esporteId }, token);
      const idsDaCategoria = new Set(times.map((t) => t.id));
      const mata = todos.filter((j) => ORDEM_FASES.includes(j.fase) && idsDaCategoria.has(j.timeA?.id));
      if (!mata.length) { setErro("Ainda não há jogos de mata-mata para este esporte. Gere a primeira fase antes."); return; }
      const maisAvancada = ORDEM_FASES[Math.max(...mata.map((j) => ORDEM_FASES.indexOf(j.fase)))];
      if (maisAvancada === "Final") { setErro("A final já foi criada. Não há próxima fase."); return; }
      const daFase = mata.filter((j) => j.fase === maisAvancada);
      if (daFase.some((j) => j.status !== "finalizado")) { setErro(`Finalize todos os jogos da fase "${maisAvancada}" antes de gerar a próxima.`); return; }
      const empates = daFase.filter((j) => j.placarA === j.placarB);
      if (empates.length) { setErro(`Há empate em ${empates.map((j) => `${j.timeA.label} x ${j.timeB.label}`).join(", ")}. Defina o vencedor (pênaltis/desempate) na súmula antes de continuar.`); return; }
      const vencedores = daFase.map((j) => (j.placarA > j.placarB ? j.timeA : j.timeB));
      // Depois da fase preliminar, entram também os times que tiveram "bye".
      const jaJogaram = new Set(daFase.flatMap((j) => [j.timeA.id, j.timeB.id]));
      const folgados = maisAvancada === "Fase preliminar" ? times.filter((t) => !jaJogaram.has(t.id)).map((t) => ({ id: t.id, label: t.turma_label })) : [];
      const classificados = [...folgados, ...vencedores].map((t) => ({ id: t.id, turma_label: t.label || t.turma_label }));
      if (classificados.length < 2) { setErro("Não há times suficientes para a próxima fase."); return; }
      const fase = nomeDaFase(classificados.length);
      const ordem = sortear ? embaralhar(classificados, semente) : classificados;
      const jogos = Array.from({ length: Math.floor(ordem.length / 2) }, (_, i) => ({ a: ordem[i * 2], b: ordem[i * 2 + 1] }));
      finalizarPrevia([{ fase, jogos }], ordem.length % 2 ? [ordem[ordem.length - 1]] : []);
    } catch (e) { setErro(e.message); }
  }

  async function salvar() {
    if (!gerados?.length || salvando) return;
    setSalvando(true); setErro("");
    try {
      const resposta = await api.criarJogosLote(token, {
        esporteId: Number(esporteId),
        jogos: gerados.map((j) => ({ timeAId: j.a.id, timeBId: j.b.id, data, hora: j.hora, local: j.local, fase: j.fase })),
      });
      setOk(`${resposta.criados} jogos criados com sucesso. Veja em "Jogos / Súmulas".`);
      setGerados(null); // evita criar de novo com um segundo clique
      setByes([]);
    } catch (e) {
      setErro(e.message); // o servidor cria tudo ou nada; é seguro tentar de novo depois de corrigir
    } finally {
      setSalvando(false);
    }
  }

  const nomeTime = (t) => t.turma_label || t.label;

  return (
    <div className="space-y-6">
      <section className="border border-line p-5">
        <p className="games-kicker">04 · Automação do campeonato</p>
        <h2 className="font-black text-3xl uppercase font-display">Gerador visual de tabelas</h2>
        <p className="text-sm text-slate-500 mt-1">Monte rodízio ou mata-mata, revise a chave e distribua horários antes de criar os jogos. O sistema recusa conflitos de quadra, horário e jogos repetidos.</p>
        <div className="grid md:grid-cols-3 gap-3 mt-5">
          <label className="label">Categoria
            <select className="input mt-2" value={categoriaId} onChange={(e) => { setCategoriaId(e.target.value); setEsporteId(""); }}>
              <option value="">Selecione</option>
              {categorias.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
            </select>
          </label>
          <label className="label">Esporte
            <select className="input mt-2" value={esporteId} onChange={(e) => setEsporteId(e.target.value)}>
              <option value="">Selecione</option>
              {esportesCategoria.map((e) => <option key={e.id} value={e.id}>{e.icone} {e.nome}</option>)}
            </select>
          </label>
          <label className="label">Formato
            <select className="input mt-2" value={modo} onChange={(e) => { setModo(e.target.value); setGerados(null); }}>
              <option value="rodizio">Rodízio / pontos corridos</option>
              <option value="mata-mata">Mata-mata / chave</option>
            </select>
          </label>
          <label className="label">Data<input type="date" className="input mt-2" value={data} onChange={(e) => setData(e.target.value)} /></label>
          <label className="label">Primeiro horário<input type="time" className="input mt-2" value={hora} onChange={(e) => setHora(e.target.value)} /></label>
          <label className="label">Quadra(s) <span className="normal-case opacity-70">(separe por vírgula)</span>
            <input className="input mt-2" value={local} onChange={(e) => setLocal(e.target.value)} placeholder="Quadra 1, Quadra 2" />
          </label>
          <label className="label">Intervalo por jogo (min)<input type="number" min="5" step="5" className="input mt-2" value={duracao} onChange={(e) => setDuracao(Number(e.target.value))} /></label>
          <label className="label flex items-center gap-2 md:col-span-2 mt-6 normal-case">
            <input type="checkbox" checked={sortear} onChange={(e) => setSortear(e.target.checked)} />
            Sortear a ordem dos times (evita turmas do mesmo ano sempre se enfrentarem primeiro)
          </label>
        </div>
        <div className="flex flex-wrap gap-3 mt-5">
          <button onClick={() => gerar()} className="px-6 py-3 bg-green-500 text-black font-black uppercase">Gerar prévia</button>
          {sortear && gerados && <button onClick={sortearDeNovo} className="px-6 py-3 border border-line font-black uppercase">Sortear de novo</button>}
          {modo === "mata-mata" && <button onClick={gerarProximaFase} className="px-6 py-3 border border-line font-black uppercase">Próxima fase (vencedores)</button>}
          {gerados && <button onClick={salvar} disabled={salvando} className="px-6 py-3 border border-green-400 text-green-400 font-black uppercase disabled:opacity-50">{salvando ? "Criando..." : `Criar ${gerados.length} jogos`}</button>}
        </div>
        {erro && <ErrorBox message={erro} />}
        {ok && <p className="text-green-400 text-sm mt-3">{ok}</p>}
      </section>

      {!times.length && esporteId && <Loading />}

      {gerados && (
        <section className="border border-line p-5">
          <div className="flex justify-between items-center mb-5">
            <div>
              <p className="games-kicker">Prévia da competição</p>
              <h3 className="font-black text-2xl uppercase font-display">{modo === "mata-mata" ? "Chave eliminatória" : "Rodízio"}</h3>
            </div>
            <span className="text-green-400 font-mono text-sm">{gerados.length} confrontos</span>
          </div>
          {byes.length > 0 && <p className="text-sm text-amber-300 mb-4">Avançam direto (sem jogar esta fase): {byes.map(nomeTime).join(", ")}.</p>}
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
            {gerados.map((jogo, i) => (
              <div key={`${jogo.a.id}-${jogo.b.id}-${i}`} className="border border-line bg-panel p-4">
                <div className="flex justify-between text-xs text-green-400 font-mono uppercase"><span>{jogo.fase}</span><span>{jogo.hora}</span></div>
                <div className="font-black font-display text-xl uppercase mt-3">{nomeTime(jogo.a)}<span className="text-slate-500 mx-2">vs</span>{nomeTime(jogo.b)}</div>
                <div className="text-xs text-slate-500 mt-2">{data} · {jogo.local}</div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
