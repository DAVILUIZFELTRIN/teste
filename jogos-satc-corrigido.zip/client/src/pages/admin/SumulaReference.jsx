import { useEffect, useMemo, useState } from "react";
import { api } from "../../api.js";
import { ErrorBox } from "../../components/UI.jsx";

const sportKey = (name = "") => name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const settingsFor = (name = "") => {
  const key = sportKey(name);
  if (key.includes("handebol")) return { label: "Handebol", minutes: 30, kind: "handebol", actions: ["gol", "amarelo", "vermelho", "exclusao"] };
  if (key.includes("futsal")) return { label: "Futsal", minutes: 20, kind: "futsal", actions: ["gol", "amarelo", "azul", "vermelho"] };
  return { label: "Futebol", minutes: 20, kind: "futebol", actions: ["gol", "amarelo", "vermelho"] };
};
const actionLabels = { gol: "GOLS", amarelo: "AMARELOS", azul: "AZUIS", vermelho: "VERMELHOS", exclusao: "2 MIN" };
const actionIcons = { gol: "⚽", amarelo: "🟨", azul: "🟦", vermelho: "🟥", exclusao: "⏱" };

export default function SumulaReference({ jogo, token, onSaved }) {
  const cfg = settingsFor(jogo.esporte?.nome);
  const saved = jogo.sumula?.detalhes || {};
  const draftKey = `satc-sumula-draft-${jogo.id}`;
  let draft = {};
  try { draft = JSON.parse(localStorage.getItem(draftKey) || "{}"); } catch { draft = {}; }
  const initial = { ...saved, ...draft };
  const [left, setLeft] = useState([]);
  const [right, setRight] = useState([]);
  const [data, setData] = useState(initial);
  const [status, setStatus] = useState(jogo.status === "ao_vivo" ? "EM ANDAMENTO" : "NÃO REALIZADO");
  const [score, setScore] = useState([Number(jogo.placarA || 0), Number(jogo.placarB || 0)]);
  const [clock, setClock] = useState(Number(saved.segundos ?? cfg.minutes * 60));
  const [period, setPeriod] = useState(Number(saved.periodoAtual || 1));
  const [running, setRunning] = useState(false);
  const [events, setEvents] = useState(initial.eventos || []);
  const [fouls, setFouls] = useState(initial.faltas || [0, 0]);
  const [shirts, setShirts] = useState(initial.camisas || {});
  const [players, setPlayers] = useState(initial.atletas || {});
  const [notes, setNotes] = useState(initial.arbitragem || "");
  const [referee, setReferee] = useState(jogo.sumula?.arbitro || "");
  const [sub, setSub] = useState({ side: "A", out: "", in: "" });
  const [substitutions, setSubstitutions] = useState(initial.substituicoes || []);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [motivoReabertura, setMotivoReabertura] = useState("");
  const [reabrindo, setReabrindo] = useState(jogo.status !== "finalizado");

  useEffect(() => {
    Promise.all([
      api.getAlunosDaTurma(token, jogo.timeA.turmaId, jogo.esporte.id),
      api.getAlunosDaTurma(token, jogo.timeB.turmaId, jogo.esporte.id),
    ]).then(([a, b]) => { setLeft(a.alunos || []); setRight(b.alunos || []); }).catch(e => setError(e.message));
  }, [token, jogo.timeA.turmaId, jogo.timeB.turmaId, jogo.esporte.id]);

  useEffect(() => {
    try { localStorage.setItem(draftKey, JSON.stringify({ ...data, eventos: events, segundos: clock, periodoAtual: period, faltas: fouls, camisas: shirts, atletas: players, arbitragem: notes, substituicoes })); } catch {}
  }, [data, events, clock, period, fouls, shirts, players, notes, substitutions, draftKey]);

  useEffect(() => {
    if (!running) return undefined;
    const timer = setInterval(() => setClock(v => Math.max(0, v - 1)), 1000);
    return () => clearInterval(timer);
  }, [running]);

  const displayClock = `${String(Math.floor(clock / 60)).padStart(2, "0")}:${String(clock % 60).padStart(2, "0")}`;
  const addEvent = (text, side = "") => { setStatus("EM ANDAMENTO"); setEvents(old => [{ time: displayClock, text, side }, ...old]); };
  const listFor = side => side === "A" ? left : right;
  const teamFor = side => side === "A" ? jogo.timeA.label : jogo.timeB.label;
  const playerState = (side, player) => players[`${side}-${player.id}`] || {};

  const action = (side, player, type) => {
    const key = `${side}-${player.id}`;
    setPlayers(old => ({ ...old, [key]: { ...(old[key] || {}), [type]: Number(old[key]?.[type] || 0) + 1, presente: true } }));
    if (type === "gol") {
      setScore(old => { const next = [...old]; next[side === "A" ? 0 : 1] += 1; return next; });
      addEvent(`GOL · ${player.nome}`, teamFor(side));
    } else addEvent(`${actionLabels[type]} · ${player.nome}`, teamFor(side));
  };

  const toggle = (side, player, field) => {
    const key = `${side}-${player.id}`;
    setPlayers(old => ({ ...old, [key]: { ...(old[key] || {}), [field]: !old[key]?.[field] } }));
  };
  const changeShirt = (player, e) => setShirts(old => ({ ...old, [player.id]: e.target.value.replace(/\D/g, "").slice(0, 2) }));

  const registerSubstitution = () => {
    const roster = listFor(sub.side);
    const out = roster.find(player => String(shirts[player.id] || "") === String(sub.out));
    const incoming = roster.find(player => String(shirts[player.id] || "") === String(sub.in));
    if (!out || !incoming || out.id === incoming.id) { setError("Selecione números de camisa diferentes para quem sai e quem entra."); return; }
    const outName = `${sub.out} · ${out.nome}`;
    const inName = `${sub.in} · ${incoming.nome}`;
    setPlayers(old => ({
      ...old,
      [`${sub.side}-${out.id}`]: { ...(old[`${sub.side}-${out.id}`] || {}), titular: false },
      [`${sub.side}-${incoming.id}`]: { ...(old[`${sub.side}-${incoming.id}`] || {}), titular: true, presente: true },
    }));
    setSubstitutions(old => [...old, { equipe: teamFor(sub.side), sai: outName, entra: inName, time: displayClock }]);
    addEvent(`SUBSTITUIÇÃO · sai ${outName}, entra ${inName}`, teamFor(sub.side));
    setSub({ ...sub, out: "", in: "" });
    setError("");
  };

  const save = async (finish = false) => {
    setSaving(true);
    try {
      await api.preencherSumula(token, jogo.id, {
        placarA: score[0], placarB: score[1], arbitro: referee, finalizar: finish,
        ...(jogo.status === "finalizado" ? { reabrir: reabrindo, motivoReabertura } : {}),
        detalhes: { ...data, eventos: events, segundos: clock, periodoAtual: period, faltas: fouls, camisas: shirts, atletas: players, arbitragem: notes, substituicoes: substitutions, status },
      });
      try { localStorage.removeItem(draftKey); } catch {}
      onSaved();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  const roster = (side, list, team) => <section className="sumula-team">
    <header><span>{team}</span><small>{list.length} atletas inscritos</small></header>
    <div className="sumula-table-head"><span>Pres.</span><span>Tit.</span><span>Nº</span><span>Jogador</span><span>Ações</span></div>
    {list.map(player => {
      const state = playerState(side, player);
      return <div className="sumula-player" key={player.id}>
        <input type="checkbox" checked={!!state.presente} onChange={() => toggle(side, player, "presente")} aria-label={`Presença de ${player.nome}`} />
        <button className={`sumula-toggle ${state.titular ? "on" : ""}`} onClick={() => toggle(side, player, "titular")} aria-label={`Titular de ${player.nome}`} />
        <input className="sumula-shirt" value={shirts[player.id] || ""} onChange={e => changeShirt(player, e)} placeholder="#" aria-label={`Número da camisa de ${player.nome}`} />
        <span className="sumula-player-name">{player.nome}</span>
        <div className="sumula-actions">{cfg.actions.map(type => <button key={type} title={actionLabels[type]} className={`action-${type}`} onClick={() => action(side, player, type)}><span>{actionIcons[type]} {actionLabels[type]}</span><b>{state[type] || 0}</b></button>)}</div>
      </div>;
    })}
    <div className="sumula-staff"><b>Equipe técnica</b><input placeholder="Treinador / auxiliar" /></div>
  </section>;

  const substitutionOptions = useMemo(() => listFor(sub.side).filter(player => shirts[player.id]), [sub.side, left, right, shirts]);
  return <div className="sumula-shell">
    <div className="sumula-topbar"><div><b>SÚMULA DIGITAL</b><span>{cfg.label} · {jogo.data} · {jogo.hora} · {jogo.local}</span></div><select value={status} onChange={e => setStatus(e.target.value)}><option>NÃO REALIZADO</option><option>EM ANDAMENTO</option><option>ENCERRADO</option></select><div className="sumula-top-actions"><button type="button" onClick={() => window.print()} title="Imprimir ou salvar como PDF">PDF</button><button type="button">⚙</button><button type="button" onClick={() => onSaved()}>×</button></div></div>
    <ErrorBox message={error} />
    <div className="sumula-main">{roster("A", left, jogo.timeA.label)}<div className="sumula-center">
      <div className="sumula-score-card"><small>{jogo.esporte?.icone} {cfg.label} · {period}º período</small><div className="sumula-score"><b>{score[0]}</b><span>x</span><b>{score[1]}</b></div><div className="score-buttons"><button onClick={() => setScore(s => [s[0] + 1, s[1]])}>+ Equipe A</button><button onClick={() => setScore(s => [s[0], s[1] + 1])}>+ Equipe B</button></div></div>
      <div className="sumula-clock-card"><small>{period}º tempo</small><strong>{displayClock}</strong><div><button onClick={() => setClock(v => v + 60)}>+1</button><button className="play" onClick={() => setRunning(v => !v)}>{running ? "Ⅱ" : "▶"}</button><button onClick={() => setClock(cfg.minutes * 60)}>↻</button><button onClick={() => setClock(Math.max(0, clock - 60))}>-1</button></div><div className="period-controls"><button onClick={() => setPeriod(Math.max(1, period - 1))}>‹</button><span>PERÍODO</span><button onClick={() => setPeriod(period + 1)}>›</button></div></div>
      {cfg.kind === "futsal" && <div className="sumula-fouls"><b>FALTAS ACUMULADAS</b><div>{[0, 1].map(i => <div key={i}><span>Equipe {i === 0 ? "A" : "B"}</span>{[1, 2, 3, 4, 5].map(n => <button key={n} className={fouls[i] >= n ? "marked" : ""} onClick={() => setFouls(old => old.map((v, j) => j === i ? Math.max(0, v === n ? n - 1 : n) : v))} />)}</div>)}</div></div>}
      <div className="sumula-field"><label>Árbitro / responsável</label><input value={referee} onChange={e => setReferee(e.target.value)} placeholder="Nome completo" /></div>
    </div>{roster("B", right, jogo.timeB.label)}</div>
    <div className="sumula-bottom"><div className="sumula-log"><h3>LANCES DA PARTIDA</h3>{events.length ? events.map((event, i) => <div key={i}><time>{event.time}</time><span>{event.text}</span></div>) : <p>Nenhum lance registrado.</p>}</div>
      <div className="sumula-sub"><h3>SUBSTITUIÇÕES · POR NÚMERO DE CAMISA</h3><div className="sub-form"><select value={sub.side} onChange={e => setSub({ side: e.target.value, out: "", in: "" })}><option value="A">Equipe A · {jogo.timeA.label}</option><option value="B">Equipe B · {jogo.timeB.label}</option></select><select value={sub.out} onChange={e => setSub({ ...sub, out: e.target.value })}><option value="">Sai · camisa</option>{substitutionOptions.map(player => <option key={player.id} value={shirts[player.id]}>Nº {shirts[player.id]} · {player.nome}</option>)}</select><select value={sub.in} onChange={e => setSub({ ...sub, in: e.target.value })}><option value="">Entra · camisa</option>{substitutionOptions.map(player => <option key={player.id} value={shirts[player.id]}>Nº {shirts[player.id]} · {player.nome}</option>)}</select><button onClick={registerSubstitution}>Registrar substituição</button></div>{substitutions.length > 0 && <div className="sub-list">{substitutions.slice(-4).map((item, i) => <p key={i}><b>{item.time}</b> {item.sai} → {item.entra}</p>)}</div>}</div>
      <div className="sumula-notes"><h3>REGISTROS DA ARBITRAGEM</h3><textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Observações oficiais da partida" /></div>
    </div>{jogo.status === "finalizado" && !reabrindo && <div className="sumula-reopen"><strong>Súmula finalizada e protegida.</strong><input value={motivoReabertura} onChange={e => setMotivoReabertura(e.target.value)} placeholder="Motivo obrigatório para reabrir" /><button onClick={() => setReabrindo(true)}>Reabrir súmula</button></div>}<div className="sumula-footer">{jogo.status === "finalizado" && reabrindo && <span className="text-amber-300 text-xs">Modo reabertura: {motivoReabertura || "informe o motivo acima"}</span>}<button disabled={saving || (jogo.status === "finalizado" && !reabrindo)} onClick={() => save(false)}>Salvar andamento</button><button disabled={saving || (jogo.status === "finalizado" && (!reabrindo || !motivoReabertura.trim()))} className="finish" onClick={() => { setStatus("ENCERRADO"); save(true); }}>{jogo.status === "finalizado" ? "Salvar reabertura" : "Encerrar súmula"}</button></div>
  </div>;
}

export { settingsFor };
