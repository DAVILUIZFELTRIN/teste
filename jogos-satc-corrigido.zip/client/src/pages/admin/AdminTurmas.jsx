import { Fragment, useEffect, useState } from "react";
import { api } from "../../api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { Loading, ErrorBox } from "../../components/UI.jsx";

const EMPTY = { label: "", categoriaId: "", taxa: 25, vagas: 40, qrCodeDataUrl: "", qrCodeUrl: "", removerQrCode: false };

export default function AdminTurmas() {
  const { token } = useAuth();
  const [turmas, setTurmas] = useState(null);
  const [categorias, setCategorias] = useState([]);
  const [erro, setErro] = useState("");
  const [form, setForm] = useState(EMPTY);
  const [editandoId, setEditandoId] = useState(null);
  const [turmaAbertaId, setTurmaAbertaId] = useState(null);
  const [alunosPorTurma, setAlunosPorTurma] = useState({});
  const [carregandoAlunosId, setCarregandoAlunosId] = useState(null);

  function carregar() {
    api.getTurmas(true).then(setTurmas).catch((e) => setErro(e.message));
  }

  useEffect(() => {
    carregar();
    api.getCategorias().then((cats) => {
      setCategorias(cats);
      setForm((f) => (f.categoriaId ? f : { ...f, categoriaId: cats[0]?.id ?? "" }));
    });
  }, []);

  function selecionarQrCode(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setErro("Selecione uma imagem PNG, JPG ou WEBP para o QR Code.");
      e.target.value = "";
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setErro("A imagem do QR Code deve ter até 5 MB.");
      e.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setForm((atual) => ({ ...atual, qrCodeDataUrl: String(reader.result || ""), removerQrCode: false }));
    reader.onerror = () => setErro("Não foi possível ler a imagem do QR Code.");
    reader.readAsDataURL(file);
  }

  function limparFormulario() {
    setEditandoId(null);
    setForm({ ...EMPTY, categoriaId: categorias[0]?.id ?? "" });
  }

  async function salvar(e) {
    e.preventDefault();
    setErro("");
    try {
      const payload = { ...form, categoriaId: Number(form.categoriaId), taxa: Number(form.taxa), vagas: Number(form.vagas) };
      if (editandoId) {
        await api.editarTurma(token, editandoId, payload);
      } else {
        await api.criarTurma(token, payload);
      }
      limparFormulario();
      setEditandoId(null);
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  function editar(t) {
    setEditandoId(t.id);
    setForm({ label: t.label, categoriaId: t.categoria_id, taxa: t.taxa, vagas: t.vagas, qrCodeDataUrl: "", qrCodeUrl: t.qr_code_url || "", removerQrCode: false });
  }

  function removerQrCode() {
    if (!window.confirm("Remover o QR Code salvo desta turma? A alteração será aplicada ao salvar a turma.")) return;
    setForm((atual) => ({ ...atual, qrCodeDataUrl: "", qrCodeUrl: "", removerQrCode: true }));
  }

  async function alternarAtivo(t) {
    await api.editarTurma(token, t.id, { ativo: !t.ativo });
    carregar();
  }

  async function abrirAlunos(t) {
    if (turmaAbertaId === t.id) {
      setTurmaAbertaId(null);
      return;
    }
    setTurmaAbertaId(t.id);
    if (alunosPorTurma[t.id]) return;
    setCarregandoAlunosId(t.id);
    try {
      const data = await api.getAlunosDaTurma(token, t.id);
      setAlunosPorTurma((atual) => ({ ...atual, [t.id]: data }));
    } catch (err) {
      setErro(err.message);
    } finally {
      setCarregandoAlunosId(null);
    }
  }

  async function excluir(t) {
    if (!confirm(`Excluir a turma ${t.label}? Isso so funciona se nao houver inscricoes vinculadas.`)) return;
    try {
      await api.excluirTurma(token, t.id);
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  return (
    <div>
      <ErrorBox message={erro} />
      <form onSubmit={salvar} className="border border-line p-5 mb-6 grid sm:grid-cols-4 gap-3 items-end">
        <div className="sm:col-span-2">
          <label className="label">Nome da turma</label>
          <input className="input" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Ex: 6&ordm; A" required />
        </div>
        <div>
          <label className="label">Categoria de ano</label>
          <select className="input" value={form.categoriaId} onChange={(e) => setForm({ ...form, categoriaId: e.target.value })} required>
            <option value="">Selecione</option>
            {categorias.map((c) => (
              <option key={c.id} value={c.id}>{c.nome}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label">Taxa (R$)</label>
          <input type="number" step="0.01" className="input opacity-60 cursor-not-allowed" value={form.taxa} disabled readOnly title="O valor da inscrição é o mesmo para todas as turmas." />
        </div>
        <div>
          <label className="label">Vagas</label>
          <input type="number" className="input" value={form.vagas} onChange={(e) => setForm({ ...form, vagas: e.target.value })} />
        </div>
        <div className="sm:col-span-4 grid sm:grid-cols-[1fr_auto] gap-4 items-center border border-dashed border-green-500/40 bg-green-500/5 p-4">
          <div>
            <label className="label">QR Code para pagamento da turma</label>
            <input type="file" accept="image/png,image/jpeg,image/webp" className="input file:mr-3 file:border-0 file:bg-green-500 file:px-3 file:py-1 file:font-bold file:text-black" onChange={selecionarQrCode} />
            <p className="text-[11px] text-slate-500 mt-2">Formato recomendado: <strong className="text-green-400">PNG</strong>, pois mantém os módulos do QR Code nítidos. JPG e WEBP também são aceitos. Máximo de 5 MB.</p>
            {editandoId && form.qrCodeUrl && <button type="button" onClick={removerQrCode} className="mt-3 border border-red-400/70 px-3 py-2 text-xs font-mono uppercase text-red-300 hover:bg-red-500/10">Remover QR Code salvo</button>}
          </div>
          {(form.qrCodeDataUrl || form.qrCodeUrl) && <img src={form.qrCodeDataUrl || form.qrCodeUrl} alt={`QR Code da turma ${form.label || "selecionada"}`} className="w-24 h-24 object-contain bg-white p-1 border border-green-500/50" />}
        </div>
        <div className="sm:col-span-4 flex gap-2">
          <button type="submit" className="px-6 py-2.5 bg-green-500 text-black font-bold uppercase tracking-wider hover:bg-green-400 text-sm">
            {editandoId ? "Salvar alteracoes" : "Adicionar turma"}
          </button>
          {editandoId && (
            <button type="button" onClick={limparFormulario} className="px-6 py-2.5 border border-slate-500 text-slate-300 text-sm uppercase tracking-wider">
              Cancelar
            </button>
          )}
        </div>
      </form>

      {!turmas ? (
        <Loading />
      ) : (
        <div className="overflow-x-auto border border-line">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-slate-500 font-mono uppercase text-xs">
                <th className="text-left px-4 py-3">Turma</th>
                <th className="text-left px-4 py-3">Categoria</th>
                <th className="px-3 py-3">Taxa</th>
                <th className="px-3 py-3">QR pagamento</th><th className="px-3 py-3">Inscritos</th>
                <th className="px-3 py-3">Status</th>
                <th className="px-3 py-3">Acoes</th>
              </tr>
            </thead>
            <tbody>
              {turmas.map((t) => (
                <Fragment key={t.id}>
                <tr className="border-b border-line last:border-0">
                  <td className="px-4 py-3 font-bold">
                    <button type="button" onClick={() => abrirAlunos(t)} className="text-left group">
                      <span className="inline-flex items-center gap-2 group-hover:text-green-400 transition-colors"><span className="text-green-400 text-xs">{turmaAbertaId === t.id ? "−" : "+"}</span>{t.label}</span>
                      <span className="block text-[10px] uppercase tracking-wider text-slate-500 mt-1">{turmaAbertaId === t.id ? "Ocultar alunos" : "Ver alunos cadastrados"}</span>
                    </button>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{t.categoria?.nome}</td>
                  <td className="px-3 py-3 text-center">R$ {Number(t.taxa ?? 0).toFixed(2)}</td>
                  <td className="px-3 py-3 text-center">{t.qr_code_url ? <img src={t.qr_code_url} alt={`QR Code ${t.label}`} className="inline-block w-12 h-12 object-contain bg-white p-0.5" /> : <span className="text-slate-600 text-xs">Não definido</span>}</td><td className="px-3 py-3 text-center">{t.inscritos}/{t.vagas}</td>
                  <td className="px-3 py-3 text-center">
                    <button onClick={() => alternarAtivo(t)} className={`text-xs font-mono uppercase px-2 py-1 rounded ${t.ativo ? "text-green-400 bg-green-500/10" : "text-slate-500 bg-slate-500/10"}`}>
                      {t.ativo ? "Ativa" : "Inativa"}
                    </button>
                  </td>
                  <td className="px-3 py-3 text-center whitespace-nowrap">
                    <button onClick={() => editar(t)} className="text-green-400 hover:text-green-300 text-xs font-mono uppercase mr-3">Editar</button>
                    <button onClick={() => excluir(t)} className="text-red-400 hover:text-red-300 text-xs font-mono uppercase">Excluir</button>
                  </td>
                </tr>
                {turmaAbertaId === t.id && (
                  <tr className="border-b border-line bg-black/20">
                    <td colSpan="7" className="px-4 py-4">
                      {!alunosPorTurma[t.id] || carregandoAlunosId === t.id ? <Loading /> : (
                        <div>
                          <div className="flex items-center justify-between gap-3 mb-3">
                            <div><p className="text-green-400 text-xs font-mono uppercase tracking-wider">Alunos cadastrados</p><p className="text-slate-400 text-xs mt-1">{alunosPorTurma[t.id].turma.categoria.nome} · {alunosPorTurma[t.id].alunos.length} aluno(s) ativo(s)</p></div>
                          </div>
                          {alunosPorTurma[t.id].alunos.length === 0 ? <p className="text-sm text-slate-500 py-3">Nenhum aluno cadastrado nesta turma.</p> : (
                            <div className="overflow-x-auto border border-line">
                              <table className="w-full text-xs"><thead><tr className="border-b border-line text-slate-500 font-mono uppercase"><th className="text-left px-3 py-2">Aluno</th><th className="text-left px-3 py-2">Matrícula</th><th className="text-left px-3 py-2">Sexo</th><th className="text-left px-3 py-2">Esportes</th><th className="text-left px-3 py-2">Pagamento</th></tr></thead><tbody>{alunosPorTurma[t.id].alunos.map((aluno) => <tr key={aluno.id} className="border-b border-line last:border-0"><td className="px-3 py-2 font-semibold">{aluno.nome}</td><td className="px-3 py-2 text-slate-400 font-mono">{aluno.matricula}</td><td className="px-3 py-2 capitalize">{aluno.sexo}</td><td className="px-3 py-2 text-slate-300">{aluno.esportes.join(", ")}{aluno.provasAtletismo?.length ? <span className="block text-[10px] text-green-400 mt-1">Atletismo: {aluno.provasAtletismo.join(", ")}</span> : null}</td><td className="px-3 py-2"><span className={aluno.status_pagamento === "confirmado" ? "text-green-400" : "text-amber-300"}>{aluno.status_pagamento}</span></td></tr>)}</tbody></table>
                            </div>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
