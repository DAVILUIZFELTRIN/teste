import { useEffect, useMemo, useState } from "react";
import { api } from "../../api.js";
import { ErrorBox } from "../../components/UI.jsx";

const yearOf = (label = "") => {
  const match = String(label).match(/\b(6|7|8|9|10|11|12|1|2|3)\b/);
  return match ? Number(match[1]) : null;
};
const normalize = (value = "") => value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const isRelay = (name = "") => /revezamento|4x/i.test(normalize(name));
const isPelota = (name = "") => /pelota/i.test(normalize(name));
const distanceValue = (value) => { const match = String(value || "").replace(",", ".").match(/-?\d+(?:\.\d+)?/); return match ? Number(match[0]) : null; };
const distanceRanking = (participants, results) => participants.map(participant => ({ participant, distancia: distanceValue(results[participant.id]?.marca) })).filter(item => item.distancia !== null && item.distancia >= 0).sort((a, b) => b.distancia - a.distancia);
const resultKind = (name = "") => /corrida|velocidade|m|barreira/i.test(normalize(name)) && !/salto|lancamento|arremesso/i.test(normalize(name)) ? "tempo" : /salto|lancamento|arremesso/i.test(normalize(name)) ? "distancia" : "marca";

function detailsOf(jogo) {
  return jogo?.sumula?.detalhes && typeof jogo.sumula.detalhes === "object" ? jogo.sumula.detalhes : {};
}

export default function SumulaAtletismo({ jogo, token, onSaved }) {
  const saved = detailsOf(jogo);
  const savedCurrent = saved.provas?.[String(saved.provaId)] || saved;
  const [turmas, setTurmas] = useState([]);
  const [provas, setProvas] = useState([]);
  const [participants, setParticipants] = useState([]);
  const [gender, setGender] = useState(saved.sexoCompeticao || "masculino");
  const [provaId, setProvaId] = useState(String(saved.provaId || ""));
  const emptyPlacements = () => Array.from({ length: 5 }, () => "");
  const [results, setResults] = useState(savedCurrent.resultados || {});
  const [placements, setPlacements] = useState(Array.from({ length: 5 }, (_, index) => savedCurrent.colocacoes?.[index]?.participanteId ? String(savedCurrent.colocacoes[index].participanteId) : ""));
  const [drafts, setDrafts] = useState(() => (saved.provas && typeof saved.provas === "object" ? Object.fromEntries(Object.entries(saved.provas).map(([key, value]) => [key, { results: value.resultados || {}, placements: Array.from({ length: 5 }, (_, index) => value.colocacoes?.[index]?.participanteId ? String(value.colocacoes[index].participanteId) : "") }])) : {}));
  const [notes, setNotes] = useState(saved.ocorrencias || "");
  const [arbiter, setArbiter] = useState(jogo.sumula?.arbitro || "");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const currentYear = yearOf(jogo.timeA?.label) || yearOf(jogo.timeB?.label);
  const phaseProofName = String(jogo.fase || "").split("·").slice(2).join("·").trim();
  const draftKey = `${gender}:${provaId}`;
  const selectedProof = provas.find(prova => String(prova.id) === String(provaId));
  const relay = isRelay(selectedProof?.nome);
  const kind = resultKind(selectedProof?.nome);
  const participationOnly = /corrida\s*(75|100)\s*m|revezamento/i.test(selectedProof?.nome || "");
  const isRanked = participationOnly;
  const pelota = isPelota(selectedProof?.nome);
  const [showDistanceRanking, setShowDistanceRanking] = useState(false);
  const rankedDistances = useMemo(() => distanceRanking(participants, results), [participants, results]);
  const savedDistanceRanking = Array.isArray(savedCurrent.classificacaoDistancia) ? savedCurrent.classificacaoDistancia : [];
  const displayedDistanceRanking = rankedDistances.length ? rankedDistances : savedDistanceRanking.map(item => ({ participant: { id: item.participanteId, nome: item.nome, turmaLabel: item.turmaLabel }, distancia: item.distancia }));

  useEffect(() => {
    api.getTurmas(true).then(setTurmas).catch(e => setError(e.message));
  }, []);

  const eligibleClasses = useMemo(() => turmas.filter(turma => yearOf(turma.label) === currentYear), [turmas, currentYear]);

  useEffect(() => {
    if (!jogo.timeA?.turmaId) return;
    api.getEsportesDaTurma(jogo.timeA.turmaId, gender).then(list => {
      const athletics = list.find(esporte => normalize(esporte.nome) === "atletismo");
      setProvas(athletics?.provas || []);
      if (!provaId && athletics?.provas?.length) {
        const phaseProof = athletics.provas.find(prova => normalize(prova.nome) === normalize(phaseProofName));
        setProvaId(String((phaseProof || athletics.provas[0]).id));
      }
    }).catch(e => setError(e.message));
  }, [jogo.timeA?.turmaId, gender, phaseProofName, provaId]);

  useEffect(() => {
    if (!eligibleClasses.length || !jogo.esporte?.id) return;
    Promise.all(eligibleClasses.map(turma => api.getAlunosDaTurma(token, turma.id, jogo.esporte.id, gender).then(response => ({ turma, alunos: response.alunos || [] })))).then(groups => {
      const rows = groups.flatMap(({ turma, alunos }) => alunos.filter(aluno => !provaId || (aluno.provasAtletismo || []).some(nome => String(nome) === String(selectedProof?.nome))).map(aluno => ({ ...aluno, turmaLabel: turma.label, turmaId: turma.id })));
      setParticipants(rows);
    }).catch(e => setError(e.message));
  }, [eligibleClasses, token, jogo.esporte?.id, gender, provaId, selectedProof?.nome]);

  const groups = useMemo(() => participants.reduce((map, participant) => { (map[participant.turmaId] ||= { label: participant.turmaLabel, players: [] }).players.push(participant); return map; }, {}), [participants]);
  const selectedIds = Object.entries(results).filter(([, value]) => value?.participante).map(([id]) => Number(id));
  const toggleParticipant = (participant) => {
    if (relay) {
      const group = groups[participant.turmaId]?.players || [];
      const chosen = group.filter(item => selectedIds.includes(item.id));
      if (!results[participant.id]?.participante && chosen.length >= 4) { setError("No revezamento, cada equipe deve ter exatamente 4 alunos da mesma turma."); return; }
    }
    setResults(old => ({ ...old, [participant.id]: { ...(old[participant.id] || {}), participante: !old[participant.id]?.participante } }));
    setError("");
  };
  const updateResult = (participant, value) => setResults(old => ({ ...old, [participant.id]: { ...(old[participant.id] || {}), marca: value, participante: true } }));
  const switchDraft = (nextGender, nextProofId) => {
    setDrafts(old => ({ ...old, [draftKey]: { results, placements } }));
    const next = drafts[`${nextGender}:${nextProofId}`];
    setResults(next?.results || {});
    setPlacements(next?.placements || emptyPlacements());
    setGender(nextGender);
    setProvaId(nextProofId);
  };

  const save = async (finalizar = false) => {
    const selected = participants.filter(participant => results[participant.id]?.participante);
    if (!provaId) { setError("Selecione a prova antes de salvar."); return; }
    if (isRanked && new Set(placements.filter(Boolean)).size !== placements.filter(Boolean).length) { setError("Cada atleta só pode ocupar uma posição na classificação."); return; }
    if (relay) {
      const invalid = Object.values(groups).some(group => {
        const count = group.players.filter(player => results[player.id]?.participante).length;
        return count > 0 && count !== 4;
      });
      if (invalid) { setError("No revezamento, a equipe precisa ter exatamente 4 alunos da mesma turma."); return; }
    }
    if (finalizar && !selected.length) { setError("Selecione ao menos um participante e registre sua marca."); return; }
    setSaving(true);
    try {
      const allDrafts = { ...drafts, [draftKey]: { results, placements } };
      const provasSalvas = Object.fromEntries(Object.entries(allDrafts).filter(([key]) => key.endsWith(":") || key.split(":")[1]).map(([key, value]) => {
        const savedProofId = key.split(":")[1];
        const proof = provas.find(item => String(item.id) === String(savedProofId));
        return [String(savedProofId), { provaId: Number(savedProofId), prova: proof?.nome || "", resultados: value.results || {}, colocacoes: (value.placements || []).map((participanteId, index) => ({ posicao: index + 1, participanteId: participanteId ? Number(participanteId) : null, nome: participants.find(participant => String(participant.id) === participanteId)?.nome || "" })).filter(item => item.participanteId) }];
      }).filter(([key]) => key !== ""));
      const resultSummary = selected.map(participant => `${participant.nome} (${participant.turmaLabel}): ${results[participant.id]?.marca || "pendente"}`).join("; ");
      const savedDistanceResults = pelota ? rankedDistances.slice(0, 3).map((item, index) => ({ posicao: index + 1, participanteId: item.participant.id, nome: item.participant.nome, turmaLabel: item.participant.turmaLabel, distancia: item.distancia })) : (savedCurrent.classificacaoDistancia || []);
      await api.preencherSumula(token, jogo.id, {
        placarA: 0, placarB: 0, arbitro: arbiter, finalizar,
        detalhes: {
          modelo: "atletismo", provaId: Number(provaId), prova: selectedProof?.nome || "", sexoCompeticao: gender, ano: currentYear,
          participantesA: selected.map(participant => participant.nome).join(", "), participantesB: "", resultados: results,
          resultado: resultSummary, colocacoes: isRanked ? placements.map((participanteId, index) => ({ posicao: index + 1, participanteId: participanteId ? Number(participanteId) : null, nome: participants.find(participant => String(participant.id) === participanteId)?.nome || "" })).filter(item => item.participanteId) : [], provas: { ...(saved.provas || {}), ...provasSalvas }, ocorrencias: notes, tipoResultado: kind, revezamento: relay, classificacaoDistancia: savedDistanceResults,
        },
      });
      onSaved();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  };

  return <div className="athletics-sheet mt-5 pt-5 border-t border-line">
    <div className="athletics-heading"><div><span className="eyebrow">Súmula individual · Atletismo</span><h4>Resultados por prova</h4><p>{currentYear ? `${currentYear}º ano` : "Categoria por ano"} · participantes inscritos · competições separadas por sexo</p></div><div className="chess-metric"><strong>{participants.length}</strong><span>elegíveis</span></div></div>
    <ErrorBox message={error} />
    <div className="athletics-controls"><div><label className="label">Sexo da competição</label><select className="input" value={gender} onChange={e => setGender(e.target.value)}><option value="masculino">Masculino</option><option value="feminino">Feminino</option></select></div><div><label className="label">Prova desta súmula</label><div className="athletics-proof-fixed">{selectedProof?.nome || phaseProofName || "Carregando prova..."}</div><small className="athletics-proof-help">Cada prova possui uma súmula independente.</small></div><div className="athletics-rule"><b>{relay ? "REVEZAMENTO" : "PROVA INDIVIDUAL"}</b><span>{relay ? "Selecione 4 alunos da mesma turma." : participationOnly ? "Marque somente quem participou." : kind === "distancia" ? "Registre a melhor distância." : "Registre a marca da prova."}</span></div></div>
    <div className="athletics-top-record"><div className="athletics-top-fields"><div><label className="label">Árbitro / responsável</label><input className="input" value={arbiter} onChange={e => setArbiter(e.target.value)} placeholder="Nome completo" /></div><div><label className="label">Observações da arbitragem</label><textarea className="input" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Desclassificações ou observações" /></div></div>{isRanked && <section className="athletics-placements"><div><span className="eyebrow">Classificação · {selectedProof?.nome}</span><h5>Cinco primeiros colocados</h5><p>Selecione os participantes classificados na súmula.</p></div><div className="athletics-placement-grid">{placements.map((participantId, index) => <label key={index} className="athletics-placement"><b>{index + 1}º</b><select className="input" value={participantId} onChange={event => setPlacements(old => old.map((value, position) => position === index ? event.target.value : value))}><option value="">Selecionar atleta</option>{participants.filter(participant => !placements.includes(String(participant.id)) || String(participant.id) === participantId).map(participant => <option key={participant.id} value={participant.id}>{participant.nome} · {participant.turmaLabel}</option>)}</select></label>)}</div></section>}</div>
    {jogo.status === "finalizado" && pelota && <section className="athletics-ranking-panel"><div><span className="eyebrow">Resultado oficial</span><h5>Classificação por distância</h5><p>Veja as maiores marcas do lançamento de pelota.</p></div><button type="button" className="button-secondary" onClick={() => setShowDistanceRanking(old => !old)}>{showDistanceRanking ? "Ocultar classificação" : "Ver classificação completa"}</button>{showDistanceRanking && <div className="athletics-ranking-list">{displayedDistanceRanking.length ? displayedDistanceRanking.map((item, index) => <div className="athletics-ranking-row" key={`${item.participant.id}-${index}`}><b>{index + 1}º</b><span>{item.participant.nome}<small>{item.participant.turmaLabel || ""}</small></span><strong>{Number(item.distancia).toFixed(2).replace(".", ",")} m</strong></div>) : <p className="athletics-empty">Nenhuma distância válida foi registrada.</p>}</div>}</section>}
    <div className="athletics-groups">{Object.values(groups).map(group => <section className="athletics-group" key={group.label}><header><b>{group.label}</b><span>{group.players.filter(player => results[player.id]?.participante).length}{relay ? " / 4" : " selecionados"}</span></header><div className="athletics-table-head"><span>Participa</span><span>Aluno</span><span>Sexo</span><span>{participationOnly ? "Presença" : kind === "tempo" ? "Tempo" : kind === "distancia" ? "Distância" : "Marca"}</span></div>{group.players.map(participant => <div className="athletics-row" key={participant.id}><input type="checkbox" checked={!!results[participant.id]?.participante} onChange={() => toggleParticipant(participant)} /><span>{participant.nome}</span><small>{participant.sexo}</small>{participationOnly ? <strong className="athletics-presence">{results[participant.id]?.participante ? "Participou" : "—"}</strong> : <input className="input" value={results[participant.id]?.marca || ""} onChange={e => updateResult(participant, e.target.value)} placeholder={kind === "tempo" ? "00:00.00" : kind === "distancia" ? "0,00 m" : "Registrar marca"} />}</div>)}</section>)}{!Object.keys(groups).length && <p className="athletics-empty">Nenhum aluno inscrito nesta prova para o {currentYear}º ano e sexo selecionado.</p>}</div>
    <div className="chess-actions"><button disabled={saving} onClick={() => save(false)} className="button-secondary">Salvar em andamento</button><button disabled={saving} onClick={() => save(true)} className="button-primary">Finalizar súmula</button></div>
  </div>;
}

export { yearOf, isRelay };
