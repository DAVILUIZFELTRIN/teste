import { useEffect, useMemo, useState } from "react";
import { api } from "../../api.js";
import { ErrorBox } from "../../components/UI.jsx";

const yearOf = (label = "") => {
  const match = String(label).match(/\b(6|7|8|9|10|11|12|1|2|3)\b/);
  return match ? Number(match[1]) : null;
};
const yearFromGame = jogo => yearOf(jogo?.timeA?.label) || yearOf(jogo?.timeB?.label) || Number(String(jogo?.fase || "").match(/\b(6|7|8|9|10|11|12)\s*[º°]?\s*ano\b/i)?.[1] || 0) || null;
const genderFromGame = jogo => /feminino/i.test(String(jogo?.fase || "")) ? "feminino" : /masculino/i.test(String(jogo?.fase || "")) ? "masculino" : "masculino";
const detailsOf = jogo => jogo?.sumula?.detalhes && typeof jogo.sumula.detalhes === "object" ? jogo.sumula.detalhes : {};
const roundsOf = value => Array.isArray(value) ? value : [];

export default function SumulaXadrez({ jogo, token, onSaved }) {
  const details = detailsOf(jogo);
  const currentYear = yearFromGame(jogo);
  const [turmas, setTurmas] = useState([]);
  const [players, setPlayers] = useState([]);
  const [gender, setGender] = useState(details.sexoCompeticao || genderFromGame(jogo));
  const [selectedA, setSelectedA] = useState("");
  const [selectedB, setSelectedB] = useState("");
  const [rounds, setRounds] = useState(roundsOf(details.rodadas));
  const [result, setResult] = useState(String(details.resultado || ""));
  const [notes, setNotes] = useState(String(details.ocorrencias || ""));
  const [arbiter, setArbiter] = useState(jogo.sumula?.arbitro || "");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => { api.getTurmas(true).then(setTurmas).catch(e => setError(e.message)); }, []);
  const eligibleClasses = useMemo(() => turmas.filter(turma => yearOf(turma.label) === currentYear), [turmas, currentYear]);

  useEffect(() => {
    if (!eligibleClasses.length || !jogo.esporte?.id) return;
    Promise.all(eligibleClasses.map(turma => api.getAlunosDaTurma(token, turma.id, jogo.esporte.id, gender).then(response => ({ turma, alunos: response.alunos || [] })))).then(groups => {
      setPlayers(groups.flatMap(({ turma, alunos }) => alunos.map(aluno => ({ ...aluno, turmaLabel: turma.label, turmaId: turma.id }))));
    }).catch(e => setError(e.message));
  }, [eligibleClasses, token, jogo.esporte?.id, gender]);

  const playerById = id => players.find(player => Number(player.id) === Number(id));
  const addRound = () => {
    const a = playerById(selectedA); const b = playerById(selectedB);
    if (!a || !b || a.id === b.id) return;
    if (rounds.some(round => (round.jogadorA === a.id && round.jogadorB === b.id) || (round.jogadorA === b.id && round.jogadorB === a.id))) { setError("Este confronto já foi adicionado."); return; }
    setRounds(old => [...old, { numero: old.length + 1, jogadorA: a.id, jogadorB: b.id, nomeA: a.nome, nomeB: b.nome, turmaA: a.turmaLabel, turmaB: b.turmaLabel, resultado: "" }]);
    setSelectedA(""); setSelectedB(""); setError("");
  };
  const generateAllRounds = () => {
    const generated = [];
    for (let i = 0; i < players.length; i += 1) for (let j = i + 1; j < players.length; j += 1) generated.push({ numero: generated.length + 1, jogadorA: players[i].id, jogadorB: players[j].id, nomeA: players[i].nome, nomeB: players[j].nome, turmaA: players[i].turmaLabel, turmaB: players[j].turmaLabel, resultado: "" });
    setRounds(generated); setError("");
  };
  const updateRound = (index, resultado) => setRounds(old => old.map((round, i) => i === index ? { ...round, resultado } : round));
  async function save(finalizar = false) {
    if (finalizar && (!players.length || !rounds.length)) { setError("Gere os confrontos antes de finalizar a súmula."); return; }
    setSaving(true); setError("");
    try {
      await api.preencherSumula(token, jogo.id, { placarA: 0, placarB: 0, arbitro: arbiter, finalizar, detalhes: { modelo: "xadrez", ano: currentYear, sexoCompeticao: gender, participantes: players.map(player => `${player.nome} (${player.turmaLabel})`).join(", "), participantesA: players.map(player => player.nome).join(", "), participantesB: "", rodadas: rounds, resultado: result, ocorrencias: notes } });
      onSaved();
    } catch (e) { setError(e.message); } finally { setSaving(false); }
  }

  return <div className="chess-sheet mt-5 pt-5 border-t border-line"><div className="chess-heading"><div><span className="eyebrow">Súmula individual · Xadrez</span><h4>Todos contra todos</h4><p>{currentYear ? `${currentYear}º ano` : "Ano da competição"} · somente inscritos do mesmo ano e sexo</p></div><div className="chess-metric"><strong>{players.length}</strong><span>participantes elegíveis</span></div></div><ErrorBox message={error} />
    <div className="athletics-controls"><div><label className="label">Sexo da competição</label><select className="input" value={gender} onChange={e => { setGender(e.target.value); setRounds([]); }}><option value="masculino">Masculino</option><option value="feminino">Feminino</option></select></div><div className="athletics-rule"><b>REGRA DA CATEGORIA</b><span>Alunos do {currentYear}º ano competem somente contra inscritos do xadrez do mesmo ano e sexo, independentemente da turma.</span></div></div>
    <div className="chess-grid"><div className="chess-card chess-players"><div className="chess-card-head"><div><span className="eyebrow">01 · Participantes</span><h5>Monte os confrontos</h5></div><span className="chess-count">{players.length} alunos</span></div><p className="chess-help">As turmas {eligibleClasses.map(turma => turma.label).join(", ")} formam uma única categoria para este sexo.</p><div className="grid md:grid-cols-2 gap-3"><div><label className="label">Jogador 1</label><select className="input" value={selectedA} onChange={e => setSelectedA(e.target.value)}><option value="">Selecionar aluno</option>{players.map(player => <option key={`a-${player.id}`} value={player.id}>{player.nome} · {player.turmaLabel}</option>)}</select></div><div><label className="label">Jogador 2</label><select className="input" value={selectedB} onChange={e => setSelectedB(e.target.value)}><option value="">Selecionar aluno</option>{players.filter(player => String(player.id) !== String(selectedA)).map(player => <option key={`b-${player.id}`} value={player.id}>{player.nome} · {player.turmaLabel}</option>)}</select></div></div><div className="flex flex-wrap gap-2 mt-4"><button className="button-primary" onClick={addRound}>Adicionar confronto</button><button className="button-secondary" onClick={generateAllRounds}>Gerar todos</button></div></div><div className="chess-card chess-rounds"><div className="chess-card-head"><div><span className="eyebrow">02 · Partidas</span><h5>Rodadas e confrontos</h5></div><span className="chess-count">{rounds.length} registrados</span></div>{rounds.length === 0 ? <p className="chess-empty">Nenhum confronto adicionado. Gere todos para montar o campeonato completo.</p> : <div className="chess-round-list">{rounds.map((round, index) => <div className="chess-round" key={`${round.numero}-${index}`}><span className="chess-round-no">{round.numero}ª</span><span className="chess-match">{round.nomeA} <small>({round.turmaA})</small> <b>×</b> {round.nomeB} <small>({round.turmaB})</small></span><select className="input" value={round.resultado || ""} onChange={e => updateRound(index, e.target.value)}><option value="">Pendente</option><option value="1-0">1–0 · Jogador 1</option><option value="0-1">0–1 · Jogador 2</option><option value="½-½">½–½ · Empate</option></select></div>)}</div>}</div></div>
    <div className="chess-bottom"><div className="chess-card"><span className="eyebrow">03 · Fechamento</span><label className="label">Resultado geral</label><input className="input" value={result} onChange={e => setResult(e.target.value)} placeholder="Ex.: campeão: Ana Duarte" /><label className="label mt-3">Árbitro / responsável</label><input className="input" value={arbiter} onChange={e => setArbiter(e.target.value)} /></div><div className="chess-card"><span className="eyebrow">04 · Registro</span><label className="label">Ocorrências</label><textarea className="input min-h-24" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Observações da arbitragem" /></div></div><div className="chess-actions"><button disabled={saving} onClick={() => save(false)} className="button-secondary">Salvar em andamento</button><button disabled={saving} onClick={() => save(true)} className="button-primary">Finalizar súmula</button></div></div>;
}

export { yearOf };
