import { useEffect, useState } from "react";
import { api } from "../../api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { Loading, ErrorBox } from "../../components/UI.jsx";

const emptySport = { nome: "", icone: "🏆", descricao: "", modalidade: "equipe", categoriaIds: [] };
const emptySubcategory = { nome: "", ordem: 0, categoriaIds: [] };

export default function AdminEsportes() {
  const { token } = useAuth();
  const [esportes, setEsportes] = useState(null);
  const [categorias, setCategorias] = useState([]);
  const [erro, setErro] = useState("");
  const [form, setForm] = useState(emptySport);
  const [editandoId, setEditandoId] = useState(null);
  const [subAberta, setSubAberta] = useState(null);
  const [subcategorias, setSubcategorias] = useState({});
  const [subForm, setSubForm] = useState(emptySubcategory);
  const [subEditandoId, setSubEditandoId] = useState(null);

  function carregar() {
    api.getEsportes({ all: "1" }).then(setEsportes).catch((e) => setErro(e.message));
  }
  useEffect(() => {
    carregar();
    api.getCategorias().then(setCategorias).catch((e) => setErro(e.message));
  }, []);

  function resetForm() {
    setForm(emptySport);
    setEditandoId(null);
  }

  function toggleCategoria(id) {
    setForm((current) => ({
      ...current,
      categoriaIds: current.categoriaIds.includes(id) ? current.categoriaIds.filter((c) => c !== id) : [...current.categoriaIds, id],
    }));
  }

  function toggleSubCategoria(id) {
    setSubForm((current) => ({
      ...current,
      categoriaIds: current.categoriaIds.includes(id) ? current.categoriaIds.filter((c) => c !== id) : [...current.categoriaIds, id],
    }));
  }

  async function salvar(e) {
    e.preventDefault();
    setErro("");
    try {
      if (editandoId) await api.editarEsporte(token, editandoId, form);
      else await api.criarEsporte(token, form);
      resetForm();
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  function editar(esp) {
    setEditandoId(esp.id);
    setForm({
      nome: esp.nome,
      icone: esp.icone,
      descricao: esp.descricao || "",
      modalidade: esp.modalidade || "equipe",
      categoriaIds: (Array.isArray(esp.categorias) ? esp.categorias : []).map((c) => c.id),
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function alternarAtivo(esp) {
    try {
      await api.editarEsporte(token, esp.id, { ativo: !esp.ativo });
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  async function excluir(esp) {
    if (!confirm(`Excluir o esporte ${esp.nome}?`)) return;
    try {
      await api.excluirEsporte(token, esp.id);
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  async function abrirSubcategorias(esp) {
    setSubAberta(subAberta === esp.id ? null : esp.id);
    setSubEditandoId(null);
    setSubForm(emptySubcategory);
    if (subAberta === esp.id) return;
    try {
      const rows = await api.listarSubcategorias(token, esp.id);
      setSubcategorias((current) => ({ ...current, [esp.id]: rows }));
    } catch (err) {
      setErro(err.message);
    }
  }

  function editarSubcategoria(sub) {
    setSubEditandoId(sub.id);
    setSubForm({ nome: sub.nome, ordem: sub.ordem || 0, categoriaIds: sub.categoria_id ? [sub.categoria_id] : [] });
  }

  function cancelarSubcategoria() {
    setSubEditandoId(null);
    setSubForm(emptySubcategory);
  }

  async function salvarSubcategoria(e, esporteId) {
    e.preventDefault();
    setErro("");
    try {
      if (subEditandoId) {
        await api.editarSubcategoria(token, esporteId, subEditandoId, { nome: subForm.nome, ordem: Number(subForm.ordem) || 0, categoriaId: subForm.categoriaIds[0] || null });
      } else {
        await api.criarSubcategoria(token, esporteId, subForm);
      }
      const rows = await api.listarSubcategorias(token, esporteId);
      setSubcategorias((current) => ({ ...current, [esporteId]: rows }));
      cancelarSubcategoria();
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  async function excluirSubcategoria(esp, sub) {
    if (!confirm(`Excluir a subcategoria ${sub.nome}?`)) return;
    try {
      const response = await api.excluirSubcategoria(token, esp.id, sub.id);
      const rows = await api.listarSubcategorias(token, esp.id);
      setSubcategorias((current) => ({ ...current, [esp.id]: rows }));
      if (response.desativada) setErro(response.mensagem);
      carregar();
    } catch (err) {
      setErro(err.message);
    }
  }

  return (
    <div>
      <ErrorBox message={erro} />
      <form onSubmit={salvar} className="border border-line p-5 mb-6 space-y-3">
        <div className="flex flex-wrap gap-3 items-end">
          <div className="w-24">
            <label className="label">Ícone</label>
            <input className="input text-center" value={form.icone} onChange={(e) => setForm({ ...form, icone: e.target.value })} />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="label">Nome do esporte</label>
            <input className="input" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex: Futsal Masculino" required />
          </div>
          <div className="min-w-[220px]">
            <label className="label">Formato da modalidade</label>
            <select className="input" value={form.modalidade} onChange={(e) => setForm({ ...form, modalidade: e.target.value })}>
              <option value="individual">Individual · todos contra todos</option>
              <option value="dupla">Dupla · dois contra dois</option>
              <option value="equipe">Equipe · time contra time</option>
            </select>
          </div>
        </div>
        <div>
          <label className="label">Descrição (regras, número mínimo de jogadores etc.)</label>
          <textarea className="input" rows={2} value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} />
        </div>
        <div>
          <label className="label">Disponível para quais categorias de ano</label>
          <div className="flex flex-wrap gap-2">
            {categorias.map((c) => <button key={c.id} type="button" onClick={() => toggleCategoria(c.id)} className={`px-3 py-1.5 text-xs font-mono uppercase tracking-widest rounded-sm border ${form.categoriaIds.includes(c.id) ? "border-green-500 text-green-400 bg-green-500/10" : "border-line text-slate-400"}`}>{c.nome}</button>)}
          </div>
        </div>
        <div className="flex gap-2">
          <button type="submit" className="px-6 py-2.5 bg-green-500 text-black font-bold uppercase tracking-wider hover:bg-green-400 text-sm">{editandoId ? "Salvar esporte" : "Adicionar esporte"}</button>
          {editandoId && <button type="button" onClick={resetForm} className="px-6 py-2.5 border border-slate-500 text-slate-300 text-sm uppercase tracking-wider">Cancelar</button>}
        </div>
      </form>

      {!esportes ? <Loading /> : <div className="space-y-3">
        {esportes.map((esp) => {
          const subs = subcategorias[esp.id] || (Array.isArray(esp.subcategorias) ? esp.subcategorias : []);
          return <div key={esp.id} className="admin-sport-card border border-line p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-[220px]">
                <span className="text-2xl">{esp.icone}</span>
                <div>
                  <div className="font-bold uppercase font-display text-lg leading-tight">{esp.nome}</div>
                  <div className="flex flex-wrap gap-1 mt-1"><span className="text-[10px] font-mono uppercase tracking-widest text-lime-300 bg-lime-500/10 px-1.5 py-0.5 rounded">{esp.modalidade === "individual" ? "Individual" : esp.modalidade === "dupla" ? "Dupla" : "Equipe"}</span>{(Array.isArray(esp.categorias) ? esp.categorias : []).map((c) => <span key={c.id} className="text-[10px] font-mono uppercase tracking-widest text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded">{c.nome}</span>)}{(!esp.categorias || esp.categorias.length === 0) && <span className="text-[10px] font-mono uppercase tracking-widest text-amber-400">Sem categoria vinculada</span>}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono uppercase flex-wrap">
                <button onClick={() => alternarAtivo(esp)} className={esp.ativo ? "text-green-400" : "text-slate-500"}>{esp.ativo ? "Ativo" : "Inativo"}</button>
                <button onClick={() => abrirSubcategorias(esp)} className="text-lime-300 hover:text-lime-200">{subAberta === esp.id ? "Fechar subcategorias" : `Subcategorias (${subs.length})`}</button>
                <button onClick={() => editar(esp)} className="text-green-400 hover:text-green-300">Editar</button>
                <button onClick={() => excluir(esp)} className="text-red-400 hover:text-red-300">Excluir</button>
              </div>
            </div>
            {subAberta === esp.id && <div className="sport-subcategories mt-4 pt-4 border-t border-line">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3"><div><span className="eyebrow">Estrutura da modalidade</span><h4 className="font-display text-xl font-black uppercase">Subcategorias e provas</h4><p className="text-xs text-slate-400">Use para Atletismo ou para dividir qualquer novo esporte em provas, categorias ou etapas.</p></div><span className="text-xs font-mono text-slate-400">{subs.length} item(ns)</span></div>
              <form onSubmit={(e) => salvarSubcategoria(e, esp.id)} className="subcat-form grid sm:grid-cols-[1fr_7rem_auto] gap-2 items-end mb-4">
                <div><label className="label">Nome da subcategoria</label><input className="input" required value={subForm.nome} onChange={(e) => setSubForm({ ...subForm, nome: e.target.value })} placeholder="Ex: Corrida 75m ou Fase final" /></div>
                <div><label className="label">Ordem</label><input className="input" type="number" min="0" value={subForm.ordem} onChange={(e) => setSubForm({ ...subForm, ordem: e.target.value })} /></div>
                <button className="px-4 py-2.5 bg-green-500 text-black font-bold uppercase text-xs">{subEditandoId ? "Salvar" : "Adicionar"}</button>
              </form>
              <div className="flex flex-wrap gap-2 mb-4">{categorias.map((c) => <button key={c.id} type="button" onClick={() => toggleSubCategoria(c.id)} className={`px-2.5 py-1 text-[10px] font-mono uppercase border rounded-sm ${subForm.categoriaIds.includes(c.id) ? "border-green-500 text-green-300 bg-green-500/15" : "border-line text-slate-500"}`}>{c.nome}</button>)}{subEditandoId && <button type="button" onClick={cancelarSubcategoria} className="px-2.5 py-1 text-[10px] uppercase border border-slate-500 text-slate-400">Cancelar edição</button>}</div>
              {!subs.length ? <p className="text-xs text-slate-500">Nenhuma subcategoria cadastrada. Adicione a primeira acima.</p> : <div className="subcat-list">{subs.map((sub) => <div key={sub.id} className={`subcat-row ${sub.ativo ? "" : "opacity-60"}`}><div><b>{sub.nome}</b><small>Ordem {sub.ordem} · {(sub.categoria_id ? categorias.find((c) => String(c.id) === String(sub.categoria_id))?.nome : "Todas as categorias") || "Categoria não identificada"}{!sub.ativo ? " · Inativa" : ""}</small></div><div className="flex gap-3 text-xs font-mono uppercase"><button type="button" onClick={() => editarSubcategoria(sub)} className="text-green-400">Editar</button><button type="button" onClick={() => excluirSubcategoria(esp, sub)} className="text-red-400">Excluir</button></div></div>)}</div>}
            </div>}
          </div>;
        })}
      </div>}
    </div>
  );
}
