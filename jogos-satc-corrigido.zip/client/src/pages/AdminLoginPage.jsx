import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { ErrorBox } from "../components/UI.jsx";

export default function AdminLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  async function onSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setErro("");
    try {
      const r = await api.login(username, password);
      login(r.token, r.admin);
      navigate("/admin");
    } catch (err) {
      setErro(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="pt-14 min-h-screen flex items-center justify-center px-4">
      <form onSubmit={onSubmit} className="w-full max-w-sm border border-line p-8">
        <h1 className="font-black text-4xl uppercase mb-1 font-display">
          ADMIN <span className="text-green-400">SATC</span>
        </h1>
        <p className="text-slate-500 text-sm mb-6">Acesso restrito a organizacao do campeonato.</p>
        <ErrorBox message={erro} />
        <div className="space-y-4">
          <div>
            <label className="block font-mono text-xs text-slate-400 uppercase tracking-widest mb-2">Usuario</label>
            <input className="input" value={username} onChange={(e) => setUsername(e.target.value)} autoFocus />
          </div>
          <div>
            <label className="block font-mono text-xs text-slate-400 uppercase tracking-widest mb-2">Senha</label>
            <input
              className="input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="mt-6 w-full py-4 bg-green-500 text-black font-black uppercase tracking-wider hover:bg-green-400 disabled:opacity-50"
        >
          {loading ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </div>
  );
}
