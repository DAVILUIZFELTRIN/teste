import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import { SectionHeader, Loading, ErrorBox } from "../components/UI.jsx";

export default function EsportesPage() {
  const [esportes, setEsportes] = useState(null);
  const [erro, setErro] = useState("");

  useEffect(() => {
    api.getEsportes().then(setEsportes).catch((e) => setErro(e.message));
  }, []);

  return (
    <div className="pt-14 max-w-7xl mx-auto px-4 py-12">
      <SectionHeader eyebrow="01" title="ESPORTES" />
      <ErrorBox message={erro} />
      {!esportes ? (
        <Loading />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {esportes.map((s) => (
            <Link
              key={s.id}
              to={`/jogos?esporteId=${s.id}`}
              className="text-left border border-line p-6 hover:border-green-500/40 transition-all block"
            >
              <div className="text-4xl mb-3">{s.icone}</div>
              <div className="font-black text-3xl uppercase mb-2 font-display">{s.nome}</div>
              {s.descricao && <p className="text-xs text-slate-500 mb-3">{s.descricao}</p>}
              <div className="flex flex-wrap gap-1 mb-3">
                {s.categorias?.map((c) => (
                  <span key={c.id} className="text-[10px] font-mono uppercase tracking-widest text-slate-400 border border-line px-1.5 py-0.5 rounded">
                    {c.nome}
                  </span>
                ))}
              </div>
              <div className="text-sm text-green-400 font-mono uppercase tracking-widest">
                Ver jogos e classificacao &rarr;
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
