import { createContext, useContext, useEffect, useState } from "react";
import { api } from "../api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem("satc_token"));
  const [admin, setAdmin] = useState(() => {
    const raw = localStorage.getItem("satc_admin");
    try { return raw ? JSON.parse(raw) : null; } catch { return null; }
  });

  useEffect(() => {
    if (token) localStorage.setItem("satc_token", token);
    else localStorage.removeItem("satc_token");
  }, [token]);

  useEffect(() => {
    if (admin) localStorage.setItem("satc_admin", JSON.stringify(admin));
    else localStorage.removeItem("satc_admin");
  }, [admin]);

  // Renova o login a cada 30 minutos enquanto o painel está aberto, para não cair no meio de uma partida.
  useEffect(() => {
    if (!token) return undefined;
    let cancelado = false;
    const id = setInterval(() => {
      api.renovarToken(token)
        .then((r) => { if (!cancelado && r?.token) setToken(r.token); })
        .catch((e) => { if (!cancelado && /expirado|invalido|fornecido/i.test(e.message)) { setToken(null); setAdmin(null); } });
    }, 30 * 60 * 1000);
    return () => { cancelado = true; clearInterval(id); };
  }, [token]);

  function login(newToken, newAdmin) {
    setToken(newToken);
    setAdmin(newAdmin);
  }

  function logout() {
    setToken(null);
    setAdmin(null);
  }

  return (
    <AuthContext.Provider value={{ token, admin, login, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
