import { Component } from "react";
import { Routes, Route } from "react-router-dom";
import NavBar from "./components/NavBar.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import HomePage from "./pages/HomePage.jsx";
import EsportesPage from "./pages/EsportesPage.jsx";
import JogosPage from "./pages/JogosPage.jsx";
import InscricaoPage from "./pages/InscricaoPage.jsx";
import ConsultaPage from "./pages/ConsultaPage.jsx";
import TVJogosPage from "./pages/TVJogosPage.jsx";
import AdminLoginPage from "./pages/AdminLoginPage.jsx";
import AdminDashboardPage from "./pages/AdminDashboardPage.jsx";

export default function App() {
  return (
    <div className="min-h-screen bg-bg">
      <NavBar />
      <RouteErrorBoundary>
        <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/esportes" element={<EsportesPage />} />
        <Route path="/jogos" element={<JogosPage />} />
        <Route path="/inscricao" element={<InscricaoPage />} />
        <Route path="/consultar" element={<ConsultaPage />} />
        <Route path="/tv" element={<TVJogosPage />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminDashboardPage />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<NotFound />} />
        </Routes>
      </RouteErrorBoundary>
    </div>
  );
}

class RouteErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="pt-24 min-h-screen flex items-center justify-center px-4 text-center">
          <div>
            <p className="font-mono text-green-400 text-xs uppercase tracking-widest mb-3">Erro de carregamento</p>
            <h1 className="font-black text-4xl uppercase font-display mb-3">Não foi possível abrir esta tela</h1>
            <p className="text-slate-400 text-sm">Atualize a página ou volte ao início para continuar.</p>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function NotFound() {
  return (
    <div className="pt-14 min-h-screen flex items-center justify-center text-center px-4">
      <div>
        <h1 className="font-black text-6xl uppercase font-display text-slate-700 mb-4">404</h1>
        <p className="text-slate-500">Pagina nao encontrada.</p>
      </div>
    </div>
  );
}
