import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

const LINKS = [
  { to: "/", label: "Inicio" },
  { to: "/esportes", label: "Esportes" },
  { to: "/jogos", label: "Jogos" },
  { to: "/inscricao", label: "Inscricao" },
  { to: "/consultar", label: "Consultar" },
];

export default function NavBar() {
  const [open, setOpen] = useState(false);
  const { isAuthenticated, logout, admin } = useAuth();
  const navigate = useNavigate();

  function linkClass({ isActive }) {
    return `nav-tab px-4 py-1.5 text-sm uppercase tracking-widest transition-colors rounded-sm ${isActive ? "nav-tab-active" : ""}`;
  }

  return (
    <header className="site-nav fixed top-0 left-0 right-0 z-50 border-b border-line bg-bg/95 backdrop-blur">
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-14">
        <NavLink to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-green-500 flex items-center justify-center">
            <span className="text-black font-black text-sm font-display">JOS</span>
          </div>
          <span className="font-black text-xl tracking-tight hidden sm:block font-display">
            JOGOS <span className="text-green-400">SATC</span>
          </span>
        </NavLink>

        <nav className="hidden md:flex items-center gap-1">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.to === "/"} className={linkClass}>
              {l.label}
            </NavLink>
          ))}
          {isAuthenticated ? (
            <>
              <NavLink to="/admin" className={linkClass}>
                Admin{admin?.nome ? ` (${admin.nome.split(" ")[0]})` : ""}
              </NavLink>
              <button
                onClick={() => { logout(); navigate("/"); }}
                className="px-4 py-1.5 text-sm font-semibold uppercase tracking-widest text-slate-500 hover:text-red-400"
              >
                Sair
              </button>
            </>
          ) : (
            <NavLink to="/admin/login" className={linkClass}>
              Admin
            </NavLink>
          )}
        </nav>

        <button className="md:hidden text-slate-400 hover:text-white p-2" onClick={() => setOpen(!open)}>
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {open ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-line bg-panel px-4 py-3 flex flex-col gap-1">
          {LINKS.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `px-3 py-2 text-left text-sm font-semibold uppercase tracking-widest rounded transition-colors ${
                  isActive ? "text-green-400 bg-green-500/10" : "text-slate-400 hover:text-white"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
          <NavLink
            to={isAuthenticated ? "/admin" : "/admin/login"}
            onClick={() => setOpen(false)}
            className="px-3 py-2 text-left text-sm font-semibold uppercase tracking-widest rounded text-slate-400 hover:text-white"
          >
            Admin
          </NavLink>
        </div>
      )}
    </header>
  );
}
