export function StatusBadge({ status }) {
  const cfg = {
    confirmado: "bg-green-500/15 text-green-400 border border-green-500/30",
    pendente: "bg-amber-500/15 text-amber-400 border border-amber-500/30",
    cancelado: "bg-red-500/15 text-red-400 border border-red-500/30",
  }[status] || "bg-slate-500/15 text-slate-400 border border-slate-500/30";
  const label = { confirmado: "CONFIRMADO", pendente: "PENDENTE", cancelado: "CANCELADO" }[status] || status;
  return (
    <span className={`font-mono text-xs px-2 py-0.5 rounded uppercase tracking-widest ${cfg}`}>{label}</span>
  );
}

export function JogoStatusBadge({ status }) {
  const cfg = {
    agendado: "bg-blue-500/15 text-blue-400 border border-blue-500/30",
    em_andamento: "bg-amber-500/15 text-amber-400 border border-amber-500/30 animate-pulse",
    finalizado: "bg-green-500/15 text-green-400 border border-green-500/30",
    adiado: "bg-slate-500/15 text-slate-400 border border-slate-500/30",
  }[status] || "bg-slate-500/15 text-slate-400";
  const label = { agendado: "AGENDADO", em_andamento: "AO VIVO", finalizado: "FINALIZADO", adiado: "ADIADO" }[status] || status;
  return (
    <span className={`font-mono text-xs px-2 py-0.5 rounded uppercase tracking-widest ${cfg}`}>{label}</span>
  );
}

export function SectionHeader({ eyebrow, title }) {
  return (
    <div className="flex items-baseline gap-4 mb-10">
      {eyebrow && <span className="font-mono text-green-400 text-xs tracking-[0.2em]">{eyebrow}</span>}
      <h2 className="font-black text-5xl uppercase font-display">{title}</h2>
    </div>
  );
}

export function ErrorBox({ message }) {
  if (!message) return null;
  return (
    <div className="border border-red-500/30 bg-red-500/10 text-red-300 text-sm px-4 py-3 rounded mb-4">
      {message}
    </div>
  );
}

export function Loading() {
  return <div className="text-slate-500 font-mono text-sm py-10 text-center">Carregando...</div>;
}
