// Data de hoje (AAAA-MM-DD) no horário de Brasília, independente do fuso do computador.
// (toISOString usa UTC e, depois das 21h, passaria para o dia seguinte.)
export function dataHojeBrasilia() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "America/Sao_Paulo" }).format(new Date());
}
