const BASE = import.meta.env.VITE_API_URL || "/api";

async function request(path, { method = "GET", body, token } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const isJson = res.headers.get("content-type")?.includes("application/json");
  const data = isJson ? await res.json() : null;
  if (!res.ok) {
    throw new Error(data?.erro || `Erro ${res.status} ao chamar ${path}`);
  }
  return data;
}

function asArray(value, keys = []) {
  if (Array.isArray(value)) return value;
  for (const key of keys) if (Array.isArray(value?.[key])) return value[key];
  return [];
}

function normalizeEsportes(value) {
  return asArray(value, ["esportes", "items"]).map((esporte) => ({
    ...esporte,
    categorias: Array.isArray(esporte?.categorias) ? esporte.categorias : [],
    provas: Array.isArray(esporte?.provas) ? esporte.provas : [],
  }));
}

export const api = {
  // Auth
  login: (username, password) => request("/auth/login", { method: "POST", body: { username, password } }),
  trocarSenha: (token, senhaAtual, novaSenha) =>
    request("/auth/trocar-senha", { method: "POST", token, body: { senhaAtual, novaSenha } }),

  // Publico
  getEsportes: async (params = {}) => normalizeEsportes(await request(`/esportes?${new URLSearchParams(params)}`)),
  getEsportesDaTurma: (turmaId, sexo) => request(`/esportes?${new URLSearchParams({ turmaId, ...(sexo ? { sexo } : {}) })}`),
  getTurmas: async (all = false) => asArray(await request(`/turmas${all ? "?all=1" : ""}`), ["turmas", "items"]),
  getCategorias: async () => asArray(await request("/categorias"), ["categorias", "items"]),
  getConfiguracoes: () => request("/configuracoes"),
  inscrever: (payload) => request("/inscricoes", { method: "POST", body: payload }),
  consultarInscricao: (params) => request(`/inscricoes/status?${new URLSearchParams(params)}`),
  getJogos: async (params = {}, token) => asArray(await request(`/jogos?${new URLSearchParams(params)}`, { token }), ["jogos", "items"]),
  getClassificacao: (esporteId) => request(`/classificacao?esporteId=${esporteId}`),

  // Admin
  criarEsporte: (token, payload) => request("/esportes", { method: "POST", token, body: payload }),
  editarEsporte: (token, id, payload) => request(`/esportes/${id}`, { method: "PUT", token, body: payload }),
  excluirEsporte: (token, id) => request(`/esportes/${id}`, { method: "DELETE", token }),
  getTimesDoEsporte: (token, esporteId) => request(`/esportes/${esporteId}/times`, { token }),
  listarSubcategorias: (token, esporteId) => request(`/esportes/${esporteId}/subcategorias`, { token }),
  criarSubcategoria: (token, esporteId, payload) => request(`/esportes/${esporteId}/subcategorias`, { method: "POST", token, body: payload }),
  editarSubcategoria: (token, esporteId, subcategoriaId, payload) => request(`/esportes/${esporteId}/subcategorias/${subcategoriaId}`, { method: "PUT", token, body: payload }),
  excluirSubcategoria: (token, esporteId, subcategoriaId) => request(`/esportes/${esporteId}/subcategorias/${subcategoriaId}`, { method: "DELETE", token }),

  criarTurma: (token, payload) => request("/turmas", { method: "POST", token, body: payload }),
  editarTurma: (token, id, payload) => request(`/turmas/${id}`, { method: "PUT", token, body: payload }),
  excluirTurma: (token, id) => request(`/turmas/${id}`, { method: "DELETE", token }),
  getAlunosDaTurma: (token, id, esporteId, sexo) => request(`/turmas/${id}/alunos?${new URLSearchParams({ ...(esporteId ? { esporteId } : {}), ...(sexo ? { sexo } : {}) })}`, { token }),

  listarInscricoes: (token, status) => request(`/inscricoes${status ? `?status=${status}` : ""}`, { token }),
  atualizarPagamento: (token, id, status) =>
    request(`/inscricoes/${id}/pagamento`, { method: "PUT", token, body: { status } }),

  criarJogosLote: (token, payload) => request("/jogos/lote", { method: "POST", token, body: payload }),
  renovarToken: (token) => request("/auth/renovar", { method: "POST", token }),
  criarJogo: (token, payload) => request("/jogos", { method: "POST", token, body: payload }),
  editarJogo: (token, id, payload) => request(`/jogos/${id}`, { method: "PUT", token, body: payload }),
  preencherSumula: (token, id, payload) => request(`/jogos/${id}/sumula`, { method: "PUT", token, body: payload }),
  excluirJogo: (token, id, body = {}) => request(`/jogos/${id}`, { method: "DELETE", token, body }),

  getDashboard: (token) => request("/admin/dashboard", { token }),
  salvarConfiguracoes: (token, payload) => request("/configuracoes", { method: "PUT", token, body: payload }),
  getRelatorio: (token) => request("/admin/relatorio", { token }),
};
